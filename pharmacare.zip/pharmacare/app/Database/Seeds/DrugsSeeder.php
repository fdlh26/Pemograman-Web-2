<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DrugsSeeder extends Seeder
{
    public function run(): void
    {
        $this->call('CategoriesSeeder');

        $cat = fn (string $name): int => (int) $this->db->table('categories')
            ->where('name', $name)->get()->getRow()->id;

        $drugs = [
            ['code' => 'OBT-001', 'name' => 'Paracetamol 500mg', 'unit' => 'tablet', 'buy_price' => 300, 'sell_price' => 500, 'dosage' => '500 mg', 'stock' => 1000, 'min_stock' => 100, 'category' => 'Analgesik & Antipiretik'],
            ['code' => 'OBT-002', 'name' => 'Ibuprofen 400mg', 'unit' => 'tablet', 'buy_price' => 500, 'sell_price' => 800, 'dosage' => '400 mg', 'stock' => 500, 'min_stock' => 80, 'category' => 'Analgesik & Antipiretik'],
            ['code' => 'OBT-003', 'name' => 'Amoxicillin 500mg', 'unit' => 'kaplet', 'buy_price' => 700, 'sell_price' => 1200, 'dosage' => '500 mg', 'stock' => 400, 'min_stock' => 50, 'category' => 'Antibiotik'],
            ['code' => 'OBT-004', 'name' => 'Cetirizine 10mg', 'unit' => 'tablet', 'buy_price' => 400, 'sell_price' => 700, 'dosage' => '10 mg', 'stock' => 300, 'min_stock' => 40, 'category' => 'Antihistamin'],
            ['code' => 'OBT-005', 'name' => 'Antasida Doen', 'unit' => 'strip', 'buy_price' => 2000, 'sell_price' => 3500, 'dosage' => '—', 'stock' => 120, 'min_stock' => 20, 'category' => 'Antasida & Gastro'],
            ['code' => 'OBT-006', 'name' => 'Vitamin C 1000mg', 'unit' => 'tablet', 'buy_price' => 600, 'sell_price' => 1000, 'dosage' => '1000 mg', 'stock' => 800, 'min_stock' => 100, 'category' => 'Vitamin & Suplemen'],
            ['code' => 'OBT-007', 'name' => 'Betamethasone Salep 0,1%', 'unit' => 'tube', 'buy_price' => 8000, 'sell_price' => 12500, 'dosage' => '—', 'stock' => 45, 'min_stock' => 10, 'category' => 'Obat Luar'],
            ['code' => 'OBT-008', 'name' => 'Masker Medis 3 Ply', 'unit' => 'box', 'buy_price' => 15000, 'sell_price' => 22000, 'dosage' => '—', 'stock' => 60, 'min_stock' => 15, 'category' => 'Alat Kesehatan & Masker'],
        ];

        foreach ($drugs as $drug) {
            $exists = $this->db->table('drugs')->where('code', $drug['code'])->get()->getRow();
            if (! $exists) {
                $this->db->table('drugs')->insert([
                    'category_id'   => $cat($drug['category']),
                    'code'          => $drug['code'],
                    'name'          => $drug['name'],
                    'unit'          => $drug['unit'],
                    'buy_price'     => $drug['buy_price'],
                    'sell_price'    => $drug['sell_price'],
                    'dosage'        => $drug['dosage'],
                    'current_stock' => $drug['stock'],
                    'min_stock'     => $drug['min_stock'],
                    'is_active'     => 1,
                    'created_at'    => date('Y-m-d H:i:s'),
                ]);
            }
        }
    }
}
