<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        $adminRole = $this->db->table('roles')->where('name', 'admin')->get()->getRow();

        if (! $adminRole) {
            $this->call('RolesSeeder');
            $adminRole = $this->db->table('roles')->where('name', 'admin')->get()->getRow();
        }

        $exists = $this->db->table('users')->where('email', 'admin@pharmacare.test')->get()->getRow();
        if (! $exists) {
            $this->db->table('users')->insert([
                'username'   => 'admin',
                'role_id'    => $adminRole->id,
                'name'       => 'Administrator',
                'email'      => 'admin@pharmacare.test',
                'password'   => password_hash('Admin123!', PASSWORD_BCRYPT),
                'is_active'  => 1,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }
    }
}
