<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserAccountsSeeder extends Seeder
{
    public function run(): void
    {
        $this->call('RolesSeeder');

        $users = [
            ['role' => 'apoteker', 'username' => 'apoteker', 'name' => 'Apoteker Utama', 'email' => 'apoteker@pharmacare.test', 'password' => 'Apoteker123!'],
            ['role' => 'dokter', 'username' => 'dokter', 'name' => 'dr. Andi Pratama', 'email' => 'dokter@pharmacare.test', 'password' => 'Dokter123!'],
            ['role' => 'ttk', 'username' => 'ttk', 'name' => 'TTK Ruang Farmasi', 'email' => 'ttk@pharmacare.test', 'password' => 'TTK12345!'],
            ['role' => 'gudang', 'username' => 'gudang', 'name' => 'Petugas Gudang', 'email' => 'gudang@pharmacare.test', 'password' => 'Gudang123!'],
            ['role' => 'pendaftaran', 'username' => 'pendaftaran', 'name' => 'Petugas Pendaftaran', 'email' => 'pendaftaran@pharmacare.test', 'password' => 'Daftar123!'],
            ['role' => 'kasir', 'username' => 'kasir', 'name' => 'Kasir Utama', 'email' => 'kasir@pharmacare.test', 'password' => 'Kasir1234!'],
            ['role' => 'kepala_farmasi', 'username' => 'kepala', 'name' => 'Kepala Instalasi Farmasi', 'email' => 'kepala@pharmacare.test', 'password' => 'Kepala123!'],
            ['role' => 'manajemen', 'username' => 'manajemen', 'name' => 'Manajemen Klinik', 'email' => 'manajemen@pharmacare.test', 'password' => 'Manajer123!'],
        ];

        foreach ($users as $user) {
            $exists = $this->db->table('users')->where('email', $user['email'])->get()->getRow();
            if ($exists) {
                continue;
            }

            $role = $this->db->table('roles')->where('name', $user['role'])->get()->getRow();
            if (! $role) {
                continue;
            }

            $this->db->table('users')->insert([
                'username'   => $user['username'],
                'role_id'    => $role->id,
                'name'       => $user['name'],
                'email'      => $user['email'],
                'password'   => password_hash($user['password'], PASSWORD_BCRYPT),
                'is_active'  => 1,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }
    }
}
