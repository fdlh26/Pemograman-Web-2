<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class CategoriesSeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name' => 'Analgesik & Antipiretik', 'description' => 'Obat pereda nyeri dan penurun demam'],
            ['name' => 'Antibiotik', 'description' => 'Obat antibakteri'],
            ['name' => 'Antihistamin', 'description' => 'Obat alergi'],
            ['name' => 'Antasida & Gastro', 'description' => 'Obat gangguan lambung dan pencernaan'],
            ['name' => 'Vitamin & Suplemen', 'description' => 'Vitamin dan suplemen kesehatan'],
            ['name' => 'Obat Luar', 'description' => 'Salep, krim, dan obat pemakaian luar'],
            ['name' => 'Resep Tidur & Saraf', 'description' => 'Obat sistem saraf'],
            ['name' => 'Alat Kesehatan & Masker', 'description' => 'Alkes dan masker'],
        ];

        foreach ($categories as $category) {
            $exists = $this->db->table('categories')->where('name', $category['name'])->get()->getRow();
            if (! $exists) {
                $this->db->table('categories')->insert($category + ['created_at' => date('Y-m-d H:i:s')]);
            }
        }
    }
}
