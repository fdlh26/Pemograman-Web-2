<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PurchasesSeeder extends Seeder
{
    public function run(): void
    {
        $this->call('SuppliersSeeder');
        $this->call('DrugsSeeder');

        $exists = $this->db->table('purchases')->where('purchase_number', 'PO-20261019-001')->get()->getRow();
        if ($exists) {
            return;
        }

        $supplier = $this->db->table('suppliers')->where('name', 'PT Kimia Farma Trading')->get()->getRow();
        $admin    = $this->db->table('users')->where('email', 'admin@pharmacare.test')->get()->getRow();

        $items = [
            // Kedaluwarsa normal
            ['code' => 'OBT-001', 'qty' => 500, 'price' => 300, 'batch' => 'PCM-2601', 'expiry' => '2027-06-30'],
            // Mendekati kedaluwarsa (<=30 hari dari 19 Okt 2026)
            ['code' => 'OBT-003', 'qty' => 200, 'price' => 700, 'batch' => 'AMX-2510', 'expiry' => '2026-11-10'],
            // Sudah kedaluwarsa
            ['code' => 'OBT-004', 'qty' => 100, 'price' => 400, 'batch' => 'CTZ-2408', 'expiry' => '2026-08-31'],
        ];

        $total = 0.0;
        foreach ($items as $item) {
            $total += $item['qty'] * $item['price'];
        }

        $this->db->table('purchases')->insert([
            'supplier_id'     => $supplier->id,
            'user_id'         => $admin->id ?? null,
            'purchase_number' => 'PO-20261019-001',
            'order_date'      => '2026-10-19',
            'received_at'     => date('Y-m-d H:i:s'),
            'status'          => 'received',
            'total_amount'    => $total,
            'note'            => 'Pembelian contoh (seeder)',
            'created_at'      => date('Y-m-d H:i:s'),
        ]);

        $purchaseId = (int) $this->db->insertID();

        foreach ($items as $item) {
            $drug = $this->db->table('drugs')->where('code', $item['code'])->get()->getRow();
            if (! $drug) {
                continue;
            }

            $this->db->table('purchase_items')->insert([
                'purchase_id'  => $purchaseId,
                'drug_id'      => $drug->id,
                'quantity'     => $item['qty'],
                'unit_price'   => $item['price'],
                'batch_number' => $item['batch'],
                'expiry_date'  => $item['expiry'],
                'created_at'   => date('Y-m-d H:i:s'),
            ]);
            $itemId = (int) $this->db->insertID();

            $this->db->table('drug_batches')->insert([
                'drug_id'          => $drug->id,
                'purchase_item_id' => $itemId,
                'batch_number'     => $item['batch'],
                'expiry_date'      => $item['expiry'],
                'initial_qty'      => $item['qty'],
                'remaining_qty'    => $item['qty'],
                'created_at'       => date('Y-m-d H:i:s'),
            ]);

            $before = (float) $drug->current_stock;
            $after  = $before + $item['qty'];

            $this->db->table('drugs')->where('id', $drug->id)->update(['current_stock' => $after]);

            $this->db->table('stock_movements')->insert([
                'drug_id'      => $drug->id,
                'user_id'      => $admin->id ?? null,
                'type'         => 'in',
                'quantity'     => $item['qty'],
                'stock_before' => $before,
                'stock_after'  => $after,
                'note'         => 'Penerimaan PO-20261019-001 (Batch: ' . $item['batch'] . ')',
                'created_at'   => date('Y-m-d H:i:s'),
            ]);
        }
    }
}
