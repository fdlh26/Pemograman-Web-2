<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class SuppliersSeeder extends Seeder
{
    public function run(): void
    {
        $suppliers = [
            ['name' => 'PT Kimia Farma Trading', 'contact_person' => 'Budi Santoso', 'phone' => '021-42881234', 'email' => 'sales@kimiafarma.co.id', 'address' => 'Jl. Budi Kemuliaan No. 1, Jakarta Pusat'],
            ['name' => 'PT Enseval Medika', 'contact_person' => 'Siti Rahma', 'phone' => '021-78891234', 'email' => 'order@enseval.com', 'address' => 'Jl. Kebon Jeruk Raya No. 88, Jakarta Barat'],
            ['name' => 'CV Anugerah Pharmindo', 'contact_person' => 'Andi Wijaya', 'phone' => '022-4201234', 'email' => 'info@anugerahpharmindo.co.id', 'address' => 'Jl. Asia Afrika No. 45, Bandung'],
        ];

        foreach ($suppliers as $supplier) {
            $exists = $this->db->table('suppliers')->where('name', $supplier['name'])->get()->getRow();
            if (! $exists) {
                $this->db->table('suppliers')->insert($supplier + ['is_active' => 1, 'created_at' => date('Y-m-d H:i:s')]);
            }
        }
    }
}
