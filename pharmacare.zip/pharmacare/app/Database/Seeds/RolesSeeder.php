<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class RolesSeeder extends Seeder
{
    public function run(): void
    {
        $roles = [
            ['name' => 'admin', 'description' => 'Mengelola konfigurasi, akun, dan hak akses sistem'],
            ['name' => 'apoteker', 'description' => 'Memverifikasi resep, memeriksa obat, validasi pelayanan farmasi'],
            ['name' => 'ttk', 'description' => 'Tenaga Teknis Kefarmasian - penyiapan obat dan pencatatan'],
            ['name' => 'dokter', 'description' => 'Membuat dan mengelola resep pasien'],
            ['name' => 'gudang', 'description' => 'Petugas Gudang Farmasi - stok, penerimaan, pengeluaran obat'],
            ['name' => 'pendaftaran', 'description' => 'Petugas Pendaftaran - data pasien dan administrasi'],
            ['name' => 'kasir', 'description' => 'Mengelola pembayaran dan transaksi pasien'],
            ['name' => 'kepala_farmasi', 'description' => 'Kepala Instalasi Farmasi - memantau operasional dan laporan'],
            ['name' => 'manajemen', 'description' => 'Manajemen Klinik - memantau kinerja layanan dan laporan'],
        ];

        foreach ($roles as $role) {
            $exists = $this->db->table('roles')->where('name', $role['name'])->get()->getRow();
            if (! $exists) {
                $this->db->table('roles')->insert($role);
            }
        }
    }
}
