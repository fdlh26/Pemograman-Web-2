<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PrescriptionsSeeder extends Seeder
{
    public function run(): void
    {
        $this->call('PatientsSeeder');
        $this->call('UserAccountsSeeder');

        $exists = $this->db->table('prescriptions')->where('prescription_number', 'RX-20261019-001')->get()->getRow();
        if ($exists) {
            return;
        }

        $patient = $this->db->table('patients')->where('rm_number', 'RM-2026-00001')->get()->getRow();
        $doctor  = $this->db->table('users')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('roles.name', 'dokter')
            ->get()->getRow();
        $apoteker = $this->db->table('users')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('roles.name', 'apoteker')
            ->get()->getRow();

        if (! $patient || ! $doctor) {
            return;
        }

        $drugParacetamol = $this->db->table('drugs')->where('code', 'OBT-001')->get()->getRow();
        $drugCetirizine  = $this->db->table('drugs')->where('code', 'OBT-004')->get()->getRow();

        $this->db->table('prescriptions')->insert([
            'patient_id'          => $patient->id,
            'doctor_id'           => $doctor->id,
            'prescription_number' => 'RX-20261019-001',
            'status'              => 'verified',
            'diagnosis'           => 'Demam dan flu',
            'doctor_note'         => 'Resep contoh (seeder)',
            'verified_by'         => $apoteker->id ?? null,
            'verified_at'         => date('Y-m-d H:i:s'),
            'created_at'          => date('Y-m-d H:i:s'),
        ]);

        $rxId = (int) $this->db->insertID();

        if ($drugParacetamol) {
            $this->db->table('prescription_items')->insert([
                'prescription_id'    => $rxId,
                'drug_id'            => $drugParacetamol->id,
                'quantity'           => 12,
                'dosage_instruction' => '3x1 sehari sesudah makan',
                'created_at'         => date('Y-m-d H:i:s'),
            ]);
        }

        if ($drugCetirizine) {
            $this->db->table('prescription_items')->insert([
                'prescription_id'    => $rxId,
                'drug_id'            => $drugCetirizine->id,
                'quantity'           => 10,
                'dosage_instruction' => '1x1 sehari malam hari',
                'created_at'         => date('Y-m-d H:i:s'),
            ]);
        }
    }
}
