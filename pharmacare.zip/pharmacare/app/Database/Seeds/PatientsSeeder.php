<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PatientsSeeder extends Seeder
{
    public function run(): void
    {
        $patients = [
            ['rm_number' => 'RM-2026-00001', 'name' => 'Ahmad Fauzi', 'gender' => 'L', 'birth_date' => '1985-04-12', 'phone' => '081234567801', 'address' => 'Jl. Merdeka No. 10, Jakarta'],
            ['rm_number' => 'RM-2026-00002', 'name' => 'Siti Nurhaliza', 'gender' => 'P', 'birth_date' => '1992-08-25', 'phone' => '081234567802', 'address' => 'Jl. Melati No. 5, Bekasi'],
            ['rm_number' => 'RM-2026-00003', 'name' => 'Budi Hartono', 'gender' => 'L', 'birth_date' => '1978-01-30', 'phone' => '081234567803', 'address' => 'Jl. Anggrek No. 22, Depok'],
        ];

        foreach ($patients as $patient) {
            $exists = $this->db->table('patients')->where('rm_number', $patient['rm_number'])->get()->getRow();
            if (! $exists) {
                $this->db->table('patients')->insert($patient + ['created_at' => date('Y-m-d H:i:s')]);
            }
        }
    }
}
