<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\Schema\Blueprint;

class CreatePrescriptionItemsTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'prescription_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'drug_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'quantity' => [
                'type'       => 'DECIMAL',
                'constraint' => '12,2',
            ],
            'dosage_instruction' => [
                'type'       => 'VARCHAR',
                'constraint' => 150,
                'null'       => true,
            ],
            'note' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addKey('prescription_id');
        $this->forge->addKey('drug_id');
        $this->forge->addForeignKey('prescription_id', 'prescriptions', 'id', 'CASCADE', 'RESTRICT');
        $this->forge->addForeignKey('drug_id', 'drugs', 'id', 'CASCADE', 'RESTRICT');
        $this->forge->createTable('prescription_items', true);
    }

    public function down(): void
    {
        $this->forge->dropTable('prescription_items', true);
    }
}
