<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\Schema\Blueprint;

class CreateTransactionItemsTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'transaction_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'drug_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'quantity' => [
                'type'       => 'DECIMAL',
                'constraint' => '12,2',
            ],
            'unit_price' => [
                'type'       => 'DECIMAL',
                'constraint' => '15,2',
                'default'    => 0,
            ],
            'subtotal' => [
                'type'       => 'DECIMAL',
                'constraint' => '15,2',
                'default'    => 0,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addKey('transaction_id');
        $this->forge->addKey('drug_id');
        $this->forge->addForeignKey('transaction_id', 'transactions', 'id', 'CASCADE', 'RESTRICT');
        $this->forge->addForeignKey('drug_id', 'drugs', 'id', 'CASCADE', 'RESTRICT');
        $this->forge->createTable('transaction_items', true);
    }

    public function down(): void
    {
        $this->forge->dropTable('transaction_items', true);
    }
}
