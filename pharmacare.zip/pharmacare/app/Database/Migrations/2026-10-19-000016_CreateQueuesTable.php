<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\Schema\Blueprint;

class CreateQueuesTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'queue_number' => [
                'type'       => 'VARCHAR',
                'constraint' => 20,
            ],
            'queue_date' => [
                'type' => 'DATE',
            ],
            'prescription_id' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'patient_id' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'status' => [
                'type'       => 'ENUM',
                'constraint' => ['waiting', 'processing', 'ready', 'called', 'done'],
                'default'    => 'waiting',
            ],
            'note' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
            ],
            'called_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'called_by' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'finished_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addKey('queue_number');
        $this->forge->addKey('queue_date');
        $this->forge->addKey('status');
        $this->forge->addUniqueKey(['queue_date', 'queue_number']);
        $this->forge->addForeignKey('prescription_id', 'prescriptions', 'id', 'SET NULL', 'CASCADE');
        $this->forge->addForeignKey('patient_id', 'patients', 'id', 'SET NULL', 'CASCADE');
        $this->forge->addForeignKey('called_by', 'users', 'id', 'SET NULL', 'CASCADE');
        $this->forge->createTable('queues', true);
    }

    public function down(): void
    {
        $this->forge->dropTable('queues', true);
    }
}
