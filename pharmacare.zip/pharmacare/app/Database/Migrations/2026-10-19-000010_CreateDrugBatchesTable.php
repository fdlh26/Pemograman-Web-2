<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\Schema\Blueprint;

class CreateDrugBatchesTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'drug_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'purchase_item_id' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'batch_number' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'null'       => true,
            ],
            'expiry_date' => [
                'type' => 'DATE',
                'null' => true,
            ],
            'initial_qty' => [
                'type'       => 'DECIMAL',
                'constraint' => '12,2',
            ],
            'remaining_qty' => [
                'type'       => 'DECIMAL',
                'constraint' => '12,2',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addKey('drug_id');
        $this->forge->addKey('expiry_date');
        $this->forge->addForeignKey('drug_id', 'drugs', 'id', 'CASCADE', 'RESTRICT');
        $this->forge->addForeignKey('purchase_item_id', 'purchase_items', 'id', 'SET NULL', 'CASCADE');
        $this->forge->createTable('drug_batches', true);
    }

    public function down(): void
    {
        $this->forge->dropTable('drug_batches', true);
    }
}
