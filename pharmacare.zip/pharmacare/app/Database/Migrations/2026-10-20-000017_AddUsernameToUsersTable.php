<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddUsernameToUsersTable extends Migration
{
    public function up(): void
    {
        $this->forge->addColumn('users', [
            'username' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'null'       => true,
                'after'      => 'id',
            ],
        ]);

        // Backfill username dari nama role (kecuali kepala_farmasi -> kepala)
        $db   = $this->db;
        $rows = $db->table('users')
            ->select('users.id, roles.name AS role_name')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('users.deleted_at', null)
            ->get()
            ->getResultArray();

        foreach ($rows as $row) {
            $username = $row['role_name'] === 'kepala_farmasi' ? 'kepala' : $row['role_name'];
            $db->table('users')->where('id', $row['id'])->update(['username' => $username]);
        }

        // User soft-delete (jika ada) username dikosongkan agar tidak bentrok unique
        $db->table('users')->where('deleted_at IS NOT NULL')->update(['username' => null]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('username');
    }

    public function down(): void
    {
        $this->forge->dropColumn('users', 'username');
    }
}
