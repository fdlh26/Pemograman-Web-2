<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\Schema\Blueprint;

class CreatePrescriptionsTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'patient_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'doctor_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'prescription_number' => [
                'type'       => 'VARCHAR',
                'constraint' => 30,
            ],
            'status' => [
                'type'       => 'ENUM',
                'constraint' => ['pending', 'verified', 'prepared', 'completed', 'cancelled'],
                'default'    => 'pending',
            ],
            'diagnosis' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
            ],
            'doctor_note' => [
                'type'       => 'TEXT',
                'null'       => true,
            ],
            'verified_by' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'verified_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'prepared_by' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'prepared_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'completed_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'cancelled_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'cancel_reason' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('prescription_number');
        $this->forge->addKey('patient_id');
        $this->forge->addKey('doctor_id');
        $this->forge->addKey('status');
        $this->forge->addForeignKey('patient_id', 'patients', 'id', 'CASCADE', 'RESTRICT');
        $this->forge->addForeignKey('doctor_id', 'users', 'id', 'CASCADE', 'RESTRICT');
        $this->forge->addForeignKey('verified_by', 'users', 'id', 'SET NULL', 'CASCADE');
        $this->forge->addForeignKey('prepared_by', 'users', 'id', 'SET NULL', 'CASCADE');
        $this->forge->createTable('prescriptions', true);
    }

    public function down(): void
    {
        $this->forge->dropTable('prescriptions', true);
    }
}
