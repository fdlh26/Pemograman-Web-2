<?php

namespace App\Models;

use CodeIgniter\Model;

class TransactionItemModel extends Model
{
    protected $table            = 'transaction_items';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = ['transaction_id', 'drug_id', 'quantity', 'unit_price', 'subtotal'];

    protected $validationRules      = [
        'transaction_id' => 'required|integer',
        'drug_id'        => 'required|integer',
        'quantity'       => 'required|decimal|greater_than[0]',
        'unit_price'     => 'permit_empty|decimal|greater_than_equal_to[0]',
        'subtotal'       => 'permit_empty|decimal',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function getWithDrug(int $transactionId): array
    {
        return $this->select('transaction_items.*, drugs.name AS drug_name, drugs.code AS drug_code, drugs.unit')
            ->join('drugs', 'drugs.id = transaction_items.drug_id', 'left')
            ->where('transaction_items.transaction_id', $transactionId)
            ->orderBy('transaction_items.id', 'ASC')
            ->findAll();
    }
}
