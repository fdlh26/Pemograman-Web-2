<?php

namespace App\Models;

use CodeIgniter\Model;

class PrescriptionModel extends Model
{
    protected $table            = 'prescriptions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = [
        'patient_id', 'doctor_id', 'prescription_number', 'status', 'diagnosis', 'doctor_note',
        'verified_by', 'verified_at', 'prepared_by', 'prepared_at',
        'completed_at', 'cancelled_at', 'cancel_reason',
    ];

    protected $validationRules      = [
        'patient_id'           => 'required|integer',
        'doctor_id'            => 'required|integer',
        'prescription_number'  => 'required|max_length[30]|is_unique[prescriptions.prescription_number,id,{id}]',
        'status'               => 'permit_empty|in_list[pending,verified,prepared,completed,cancelled]',
        'diagnosis'            => 'permit_empty|max_length[255]',
        'doctor_note'          => 'permit_empty',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function generateNumber(): string
    {
        $prefix = 'RX-' . date('Ymd') . '-';
        $last   = $this->like('prescription_number', $prefix, 'after')
            ->orderBy('id', 'DESC')
            ->first();

        $seq = 1;
        if ($last !== null) {
            $seq = (int) substr($last['prescription_number'], -3) + 1;
        }

        return $prefix . str_pad((string) $seq, 3, '0', STR_PAD_LEFT);
    }

    public function getWithRelations(?string $status = null, ?string $search = null, int $perPage = 10)
    {
        $builder = $this->select('prescriptions.*, patients.name AS patient_name, patients.rm_number, users.name AS doctor_name')
            ->join('patients', 'patients.id = prescriptions.patient_id', 'left')
            ->join('users', 'users.id = prescriptions.doctor_id', 'left');

        if ($status !== null && $status !== '') {
            $builder->where('prescriptions.status', $status);
        }

        if ($search !== null && $search !== '') {
            $builder->groupStart()
                ->like('prescriptions.prescription_number', $search)
                ->orLike('patients.name', $search)
                ->orLike('patients.rm_number', $search)
                ->groupEnd();
        }

        return $builder->orderBy('prescriptions.id', 'DESC')
            ->paginate($perPage, 'prescriptions');
    }

    public function getStatusLabel(string $status): array
    {
        return match ($status) {
            'pending'   => ['Menunggu Verifikasi', 'secondary'],
            'verified'  => ['Terverifikasi', 'info'],
            'prepared'  => ['Obat Disiapkan', 'primary'],
            'completed' => ['Selesai', 'success'],
            'cancelled' => ['Dibatalkan', 'danger'],
            default     => [$status, 'secondary'],
        };
    }
}
