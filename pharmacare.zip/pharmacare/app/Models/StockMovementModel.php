<?php

namespace App\Models;

use CodeIgniter\Model;

class StockMovementModel extends Model
{
    protected $table            = 'stock_movements';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = [
        'drug_id', 'user_id', 'type', 'quantity', 'stock_before', 'stock_after', 'note',
    ];

    protected $validationRules      = [
        'drug_id'      => 'required|integer',
        'type'         => 'required|in_list[in,out,adjustment]',
        'quantity'     => 'required|decimal|greater_than[0]',
        'stock_before' => 'permit_empty|decimal',
        'stock_after'  => 'permit_empty|decimal',
        'note'         => 'permit_empty|max_length[255]',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    /**
     * Catat pergerakan stok dalam satu transaksi DB.
     *
     * @return array{success: bool, message: string, stock_after?: float}
     */
    public function record(
        int $drugId,
        string $type,
        float $quantity,
        ?int $userId = null,
        ?string $note = null
    ): array {
        $db = db_connect();
        $db->transBegin();

        $drug = $this->db->table('drugs')
            ->where('id', $drugId)
            ->get()
            ->getRowArray();

        if (! $drug) {
            $db->transRollback();

            return ['success' => false, 'message' => 'Obat tidak ditemukan.'];
        }

        $before = (float) $drug['current_stock'];
        $unit   = $drug['unit'];

        switch ($type) {
            case 'in':
                $this->db->table('drugs')
                    ->where('id', $drugId)
                    ->set('current_stock', 'current_stock + ' . $quantity, false)
                    ->update();
                $after = $before + $quantity;
                break;

            case 'out':
                $this->db->table('drugs')
                    ->where('id', $drugId)
                    ->where('current_stock >=', $quantity)
                    ->set('current_stock', 'current_stock - ' . $quantity, false)
                    ->update();

                if ($this->db->affectedRows() === 0) {
                    $db->transRollback();

                    return [
                        'success' => false,
                        'message' => 'Stok tidak mencukupi. Stok saat ini: ' . number_format($before, 2) . ' ' . $unit . '.',
                    ];
                }
                $after = $before - $quantity;
                $this->deductBatchesFefo($drugId, $quantity);
                break;

            case 'adjustment':
                $newStock = $quantity;
                $this->db->table('drugs')
                    ->where('id', $drugId)
                    ->update(['current_stock' => $newStock]);
                $quantity = abs($newStock - $before);
                $after    = $newStock;
                break;

            default:
                $db->transRollback();

                return ['success' => false, 'message' => 'Jenis pergerakan tidak valid.'];
        }

        $saved = $this->save([
            'drug_id'      => $drugId,
            'user_id'      => $userId,
            'type'         => $type,
            'quantity'     => $quantity,
            'stock_before' => $before,
            'stock_after'  => $after,
            'note'         => $note,
        ]);

        if (! $saved) {
            $db->transRollback();

            return ['success' => false, 'message' => 'Gagal mencatat pergerakan stok: ' . implode(', ', $this->errors())];
        }

        $db->transCommit();

        return [
            'success'     => true,
            'message'     => 'Pergerakan stok berhasil dicatat.',
            'stock_after' => $after,
        ];
    }

    public function getWithDrug(?string $type = null, ?int $drugId = null, int $perPage = 15)
    {
        $builder = $this->select('stock_movements.*, drugs.name AS drug_name, drugs.unit, users.name AS user_name')
            ->join('drugs', 'drugs.id = stock_movements.drug_id', 'left')
            ->join('users', 'users.id = stock_movements.user_id', 'left');

        if ($type !== null && $type !== '') {
            $builder->where('stock_movements.type', $type);
        }

        if ($drugId !== null) {
            $builder->where('stock_movements.drug_id', $drugId);
        }

        return $builder->orderBy('stock_movements.id', 'DESC')
            ->paginate($perPage, 'movements');
    }

    /**
     * Kurangi stok batch dengan metode FEFO (First Expired, First Out).
     */
    protected function deductBatchesFefo(int $drugId, float $quantity): void
    {
        $batches = $this->db->table('drug_batches')
            ->where('drug_id', $drugId)
            ->where('remaining_qty >', 0)
            ->orderBy('expiry_date', 'ASC')
            ->orderBy('id', 'ASC')
            ->get()
            ->getResultArray();

        $remaining = $quantity;

        foreach ($batches as $batch) {
            if ($remaining <= 0) {
                break;
            }

            $take = min($remaining, (float) $batch['remaining_qty']);

            $this->db->table('drug_batches')
                ->where('id', $batch['id'])
                ->set('remaining_qty', 'remaining_qty - ' . $take, false)
                ->update();

            $remaining -= $take;
        }
    }
}
