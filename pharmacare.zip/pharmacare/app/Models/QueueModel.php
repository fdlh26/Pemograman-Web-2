<?php

namespace App\Models;

use CodeIgniter\Model;

class QueueModel extends Model
{
    protected $table            = 'queues';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = [
        'queue_number', 'queue_date', 'prescription_id', 'patient_id', 'status', 'note',
        'called_at', 'called_by', 'finished_at',
    ];

    protected $validationRules      = [
        'queue_number'    => 'required|max_length[20]',
        'queue_date'      => 'required|valid_date',
        'prescription_id' => 'permit_empty|integer',
        'patient_id'      => 'permit_empty|integer',
        'status'          => 'permit_empty|in_list[waiting,processing,ready,called,done]',
        'note'            => 'permit_empty|max_length[255]',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function generateNumber(?string $date = null): string
    {
        $date   = $date ?? date('Y-m-d');
        $prefix = 'A-';
        $last   = $this->where('queue_date', $date)
            ->orderBy('id', 'DESC')
            ->first();

        $seq = 1;
        if ($last !== null) {
            $seq = (int) substr($last['queue_number'], strlen($prefix)) + 1;
        }

        return $prefix . str_pad((string) $seq, 3, '0', STR_PAD_LEFT);
    }

    public function hasActiveForPrescription(int $prescriptionId): bool
    {
        return $this->where('prescription_id', $prescriptionId)
            ->whereIn('status', ['waiting', 'processing', 'ready', 'called'])
            ->countAllResults() > 0;
    }

    /**
     * @return array{success: bool, message: string, queue?: array}
     */
    public function createForPrescription(int $prescriptionId, ?int $patientId = null, ?string $note = null): array
    {
        if ($this->hasActiveForPrescription($prescriptionId)) {
            return ['success' => false, 'message' => 'Resep ini sudah memiliki nomor antrean aktif.'];
        }

        $id = $this->insert([
            'queue_number'    => $this->generateNumber(),
            'queue_date'      => date('Y-m-d'),
            'prescription_id' => $prescriptionId,
            'patient_id'      => $patientId,
            'status'          => 'waiting',
            'note'            => $note,
        ], true);

        if ($id === false) {
            return ['success' => false, 'message' => 'Gagal membuat nomor antrean: ' . implode(', ', $this->errors())];
        }

        return ['success' => true, 'message' => 'Nomor antrean dibuat.', 'queue' => $this->find($id)];
    }

    public function getToday(int $perPage = 20)
    {
        return $this->select('queues.*, patients.name AS patient_name, patients.rm_number, prescriptions.prescription_number')
            ->join('patients', 'patients.id = queues.patient_id', 'left')
            ->join('prescriptions', 'prescriptions.id = queues.prescription_id', 'left')
            ->where('queues.queue_date', date('Y-m-d'))
            ->orderBy('queues.id', 'ASC')
            ->paginate($perPage, 'queues');
    }

    public function getLiveStatus(): array
    {
        $today = date('Y-m-d');

        $called = $this->select('queues.*, patients.name AS patient_name')
            ->join('patients', 'patients.id = queues.patient_id', 'left')
            ->where('queue_date', $today)
            ->where('status', 'called')
            ->orderBy('called_at', 'DESC')
            ->first();

        $waiting = $this->select('queues.queue_number, queues.status, patients.name AS patient_name')
            ->join('patients', 'patients.id = queues.patient_id', 'left')
            ->where('queues.queue_date', $today)
            ->whereIn('queues.status', ['waiting', 'processing', 'ready'])
            ->orderBy('queues.id', 'ASC')
            ->limit(10)
            ->findAll();

        $doneToday = $this->where('queue_date', $today)
            ->where('status', 'done')
            ->countAllResults();

        $totalToday = $this->where('queue_date', $today)
            ->countAllResults();

        return [
            'called'      => $called !== null ? [
                'queue_number' => $called['queue_number'],
                'patient_name' => $called['patient_name'] ?? null,
                'called_at'    => $called['called_at'],
            ] : null,
            'next'        => $waiting,
            'done_today'  => $doneToday,
            'total_today' => $totalToday,
            'updated_at'  => date('c'),
        ];
    }

    public function getStatusLabel(string $status): array
    {
        return match ($status) {
            'waiting'    => ['Menunggu', 'secondary'],
            'processing' => ['Diproses', 'info'],
            'ready'      => ['Siap Diambil', 'primary'],
            'called'     => ['Dipanggil', 'warning'],
            'done'       => ['Selesai', 'success'],
            default      => [$status, 'secondary'],
        };
    }
}
