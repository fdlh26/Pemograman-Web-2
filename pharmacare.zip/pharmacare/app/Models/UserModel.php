<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = [
        'username', 'role_id', 'name', 'email', 'password', 'phone', 'is_active', 'last_login_at',
    ];

    protected $validationRules      = [
        'id'        => 'permit_empty|integer',
        'username' => 'required|min_length[3]|max_length[50]|regex_match[/^[a-z0-9._-]+$/]|is_unique[users.username,id,{id}]',
        'role_id'   => 'required|integer',
        'name'      => 'required|max_length[100]',
        'email'     => 'required|valid_email|is_unique[users.email,id,{id}]|max_length[100]',
        'password'  => 'required|min_length[8]|max_length[255]',
        'phone'     => 'permit_empty|max_length[20]',
        'is_active' => 'permit_empty|integer|in_list[0,1]',
    ];
    protected $validationMessages   = [
        'username' => [
            'regex_match' => 'Username hanya boleh huruf kecil, angka, titik, strip, atau underscore.',
        ],
    ];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    protected $beforeInsert = ['hashPassword'];
    protected $beforeUpdate = ['hashPassword'];

    protected function hashPassword(array $data): array
    {
        if (! isset($data['data']['password']) || $data['data']['password'] === '') {
            unset($data['data']['password']);

            return $data;
        }

        $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_BCRYPT);

        return $data;
    }

    public function findActiveByEmail(string $email): ?array
    {
        return $this->where('email', $email)
            ->where('is_active', 1)
            ->where('deleted_at', null)
            ->first();
    }

    public function findActiveByUsername(string $username): ?array
    {
        return $this->where('username', $username)
            ->where('is_active', 1)
            ->where('deleted_at', null)
            ->first();
    }
}
