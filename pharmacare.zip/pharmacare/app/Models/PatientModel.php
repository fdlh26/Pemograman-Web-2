<?php

namespace App\Models;

use CodeIgniter\Model;

class PatientModel extends Model
{
    protected $table            = 'patients';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = ['rm_number', 'name', 'gender', 'birth_date', 'phone', 'address'];

    protected $validationRules      = [
        'rm_number' => 'required|max_length[20]|is_unique[patients.rm_number,id,{id}]',
        'name'      => 'required|max_length[150]',
        'gender'    => 'required|in_list[L,P]',
        'birth_date' => 'permit_empty|valid_date',
        'phone'     => 'permit_empty|max_length[20]',
        'address'   => 'permit_empty',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function generateRmNumber(): string
    {
        $prefix = 'RM-' . date('Y') . '-';
        $last   = $this->like('rm_number', $prefix, 'after')
            ->orderBy('id', 'DESC')
            ->first();

        $seq = 1;
        if ($last !== null) {
            $seq = (int) substr($last['rm_number'], -5) + 1;
        }

        return $prefix . str_pad((string) $seq, 5, '0', STR_PAD_LEFT);
    }

    public function search(?string $search = null, int $perPage = 10)
    {
        $builder = $this;

        if ($search !== null && $search !== '') {
            $builder = $builder->groupStart()
                ->like('name', $search)
                ->orLike('rm_number', $search)
                ->orLike('phone', $search)
                ->groupEnd();
        }

        return $builder->orderBy('name', 'ASC')->paginate($perPage, 'patients');
    }
}
