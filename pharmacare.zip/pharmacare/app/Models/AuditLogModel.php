<?php

namespace App\Models;

use CodeIgniter\Model;

class AuditLogModel extends Model
{
    protected $table            = 'audit_logs';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = [
        'user_id', 'action', 'table_name', 'record_id', 'description', 'ip_address', 'user_agent',
    ];

    protected $validationRules      = [
        'action'      => 'required|max_length[50]',
        'table_name'  => 'permit_empty|max_length[100]',
        'description' => 'permit_empty',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function log(
        ?int $userId,
        string $action,
        ?string $tableName = null,
        ?int $recordId = null,
        ?string $description = null
    ): void {
        $this->save([
            'user_id'     => $userId,
            'action'      => $action,
            'table_name'  => $tableName,
            'record_id'   => $recordId,
            'description' => $description,
            'ip_address'  => service('request')->getIPAddress(),
            'user_agent'  => substr((string) service('request')->getUserAgent()->getAgentString(), 0, 255),
        ]);
    }
}
