<?php

namespace App\Models;

use CodeIgniter\Model;

class PrescriptionItemModel extends Model
{
    protected $table            = 'prescription_items';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = [
        'prescription_id', 'drug_id', 'quantity', 'dosage_instruction', 'note',
    ];

    protected $validationRules      = [
        'prescription_id'    => 'required|integer',
        'drug_id'            => 'required|integer',
        'quantity'           => 'required|decimal|greater_than[0]',
        'dosage_instruction' => 'permit_empty|max_length[150]',
        'note'               => 'permit_empty|max_length[255]',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function getWithDrug(int $prescriptionId): array
    {
        return $this->select('prescription_items.*, drugs.name AS drug_name, drugs.code AS drug_code, drugs.unit, drugs.current_stock, drugs.sell_price, drugs.is_active AS drug_active')
            ->join('drugs', 'drugs.id = prescription_items.drug_id', 'left')
            ->where('prescription_items.prescription_id', $prescriptionId)
            ->orderBy('prescription_items.id', 'ASC')
            ->findAll();
    }
}
