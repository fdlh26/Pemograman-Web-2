<?php

namespace App\Models;

use CodeIgniter\Model;

class PurchaseItemModel extends Model
{
    protected $table            = 'purchase_items';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = [
        'purchase_id', 'drug_id', 'quantity', 'unit_price', 'batch_number', 'expiry_date',
    ];

    protected $validationRules      = [
        'purchase_id'   => 'required|integer',
        'drug_id'       => 'required|integer',
        'quantity'      => 'required|decimal|greater_than[0]',
        'unit_price'    => 'permit_empty|decimal|greater_than_equal_to[0]',
        'batch_number'  => 'permit_empty|max_length[50]',
        'expiry_date'   => 'permit_empty|valid_date',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function getWithDrug(int $purchaseId): array
    {
        return $this->select('purchase_items.*, drugs.name AS drug_name, drugs.code AS drug_code, drugs.unit')
            ->join('drugs', 'drugs.id = purchase_items.drug_id', 'left')
            ->where('purchase_items.purchase_id', $purchaseId)
            ->orderBy('purchase_items.id', 'ASC')
            ->findAll();
    }
}
