<?php

namespace App\Models;

use CodeIgniter\Model;

class DrugModel extends Model
{
    protected $table            = 'drugs';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = [
        'category_id', 'code', 'name', 'unit', 'buy_price', 'sell_price',
        'dosage', 'description', 'current_stock', 'min_stock', 'is_active',
    ];

    protected $validationRules      = [
        'category_id'   => 'required|integer',
        'code'          => 'required|max_length[50]|is_unique[drugs.code,id,{id}]',
        'name'          => 'required|max_length[150]',
        'unit'          => 'required|max_length[30]',
        'buy_price'     => 'permit_empty|decimal|greater_than_equal_to[0]',
        'sell_price'    => 'permit_empty|decimal|greater_than_equal_to[0]',
        'dosage'        => 'permit_empty|max_length[100]',
        'description'   => 'permit_empty',
        'min_stock'     => 'permit_empty|decimal|greater_than_equal_to[0]',
        'is_active'     => 'permit_empty|integer|in_list[0,1]',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function getWithCategory(?string $search = null, ?int $categoryId = null, int $perPage = 10)
    {
        $builder = $this->select('drugs.*, categories.name AS category_name')
            ->join('categories', 'categories.id = drugs.category_id', 'left');

        if ($search !== null && $search !== '') {
            $builder->groupStart()
                ->like('drugs.name', $search)
                ->orLike('drugs.code', $search)
                ->groupEnd();
        }

        if ($categoryId !== null) {
            $builder->where('drugs.category_id', $categoryId);
        }

        return $builder->orderBy('drugs.name', 'ASC')
            ->paginate($perPage, 'drugs');
    }

    public function getStockStatus(array $drug): string
    {
        $stock = (float) $drug['current_stock'];
        $min   = (float) $drug['min_stock'];

        if ($stock <= 0) {
            return 'habis';
        }

        if ($min > 0 && $stock <= $min) {
            return 'menipis';
        }

        return 'aman';
    }
}
