<?php

namespace App\Models;

use CodeIgniter\Model;

class DrugBatchModel extends Model
{
    protected $table            = 'drug_batches';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = [
        'drug_id', 'purchase_item_id', 'batch_number', 'expiry_date', 'initial_qty', 'remaining_qty',
    ];

    protected $validationRules      = [
        'drug_id'          => 'required|integer',
        'purchase_item_id' => 'permit_empty|integer',
        'batch_number'     => 'permit_empty|max_length[50]',
        'expiry_date'      => 'permit_empty|valid_date',
        'initial_qty'      => 'required|decimal|greater_than[0]',
        'remaining_qty'    => 'required|decimal|greater_than_equal_to[0]',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function getExpiring(int $days = 90, ?string $status = null)
    {
        $builder = $this->select('drug_batches.*, drugs.name AS drug_name, drugs.code AS drug_code, drugs.unit')
            ->join('drugs', 'drugs.id = drug_batches.drug_id', 'left')
            ->where('drug_batches.remaining_qty >', 0);

        $today = date('Y-m-d');

        switch ($status) {
            case 'expired':
                $builder->where('drug_batches.expiry_date <', $today);
                break;

            case 'critical':
                $builder->where('drug_batches.expiry_date >=', $today)
                    ->where('drug_batches.expiry_date <=', date('Y-m-d', strtotime("+{$days} days")));
                break;

            case 'warning':
                $builder->where('drug_batches.expiry_date >', date('Y-m-d', strtotime("+{$days} days")))
                    ->where('drug_batches.expiry_date <=', date('Y-m-d', strtotime('+90 days')));
                break;

            default:
                $builder->where('drug_batches.expiry_date <=', date('Y-m-d', strtotime('+90 days')));
                break;
        }

        return $builder->orderBy('drug_batches.expiry_date', 'ASC')
            ->paginate(15, 'batches');
    }

    public function getExpiryStatus(array $batch): string
    {
        if ($batch['expiry_date'] === null || $batch['expiry_date'] === '') {
            return 'unknown';
        }

        $expiry = strtotime($batch['expiry_date']);
        $today  = strtotime(date('Y-m-d'));

        if ($expiry < $today) {
            return 'expired';
        }

        $daysLeft = (int) floor(($expiry - $today) / 86400);
        if ($daysLeft <= 30) {
            return 'critical';
        }

        if ($daysLeft <= 90) {
            return 'warning';
        }

        return 'safe';
    }
}
