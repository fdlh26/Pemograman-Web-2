<?php

namespace App\Models;

use CodeIgniter\Model;

class PurchaseModel extends Model
{
    protected $table            = 'purchases';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = [
        'supplier_id', 'user_id', 'purchase_number', 'order_date', 'received_at',
        'status', 'total_amount', 'note',
    ];

    protected $validationRules      = [
        'supplier_id'     => 'required|integer',
        'purchase_number' => 'required|max_length[30]|is_unique[purchases.purchase_number,id,{id}]',
        'order_date'      => 'required|valid_date',
        'status'          => 'permit_empty|in_list[ordered,received,cancelled]',
        'note'            => 'permit_empty',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function generateNumber(): string
    {
        $prefix = 'PO-' . date('Ymd') . '-';
        $last   = $this->like('purchase_number', $prefix, 'after')
            ->orderBy('id', 'DESC')
            ->first();

        $seq = 1;
        if ($last !== null) {
            $seq = (int) substr($last['purchase_number'], -3) + 1;
        }

        return $prefix . str_pad((string) $seq, 3, '0', STR_PAD_LEFT);
    }

    public function getWithSupplier(?string $status = null, ?string $search = null, int $perPage = 10)
    {
        $builder = $this->select('purchases.*, suppliers.name AS supplier_name')
            ->join('suppliers', 'suppliers.id = purchases.supplier_id', 'left');

        if ($status !== null && $status !== '') {
            $builder->where('purchases.status', $status);
        }

        if ($search !== null && $search !== '') {
            $builder->groupStart()
                ->like('purchases.purchase_number', $search)
                ->orLike('suppliers.name', $search)
                ->groupEnd();
        }

        return $builder->orderBy('purchases.id', 'DESC')
            ->paginate($perPage, 'purchases');
    }
}
