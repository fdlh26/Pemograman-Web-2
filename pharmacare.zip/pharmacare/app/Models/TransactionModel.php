<?php

namespace App\Models;

use CodeIgniter\Model;

class TransactionModel extends Model
{
    protected $table            = 'transactions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $allowedFields    = [
        'transaction_number', 'prescription_id', 'patient_id', 'user_id', 'type', 'status',
        'total_amount', 'discount', 'grand_total', 'payment_method', 'paid_amount',
        'change_amount', 'paid_at', 'cancelled_at', 'note',
    ];

    protected $validationRules      = [
        'transaction_number' => 'required|max_length[30]|is_unique[transactions.transaction_number,id,{id}]',
        'type'               => 'permit_empty|in_list[otc,prescription]',
        'status'             => 'permit_empty|in_list[pending,paid,cancelled]',
        'discount'           => 'permit_empty|decimal|greater_than_equal_to[0]',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    public function generateNumber(): string
    {
        $prefix = 'TRX-' . date('Ymd') . '-';
        $last   = $this->like('transaction_number', $prefix, 'after')
            ->orderBy('id', 'DESC')
            ->first();

        $seq = 1;
        if ($last !== null) {
            $seq = (int) substr($last['transaction_number'], -3) + 1;
        }

        return $prefix . str_pad((string) $seq, 3, '0', STR_PAD_LEFT);
    }

    public function isPrescriptionPaid(int $prescriptionId): bool
    {
        return $this->where('prescription_id', $prescriptionId)
            ->where('status', 'paid')
            ->countAllResults() > 0;
    }

    public function getWithRelations(?string $status = null, ?string $search = null, int $perPage = 10)
    {
        $builder = $this->select('transactions.*, patients.name AS patient_name, users.name AS cashier_name, prescriptions.prescription_number')
            ->join('patients', 'patients.id = transactions.patient_id', 'left')
            ->join('users', 'users.id = transactions.user_id', 'left')
            ->join('prescriptions', 'prescriptions.id = transactions.prescription_id', 'left');

        if ($status !== null && $status !== '') {
            $builder->where('transactions.status', $status);
        }

        if ($search !== null && $search !== '') {
            $builder->groupStart()
                ->like('transactions.transaction_number', $search)
                ->orLike('patients.name', $search)
                ->orLike('prescriptions.prescription_number', $search)
                ->groupEnd();
        }

        return $builder->orderBy('transactions.id', 'DESC')
            ->paginate($perPage, 'transactions');
    }
}
