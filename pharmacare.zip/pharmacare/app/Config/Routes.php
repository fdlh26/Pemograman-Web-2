<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Auth::login');
$routes->get('login', 'Auth::login');
$routes->post('login', 'Auth::attempt');
$routes->get('logout', 'Auth::logout');

$routes->get('dashboard', 'Dashboard::index');

// Kategori Obat - hanya admin
$routes->group('categories', ['filter' => 'role:admin'], static function ($routes): void {
    $routes->get('/', 'Category::index');
    $routes->get('create', 'Category::create');
    $routes->post('store', 'Category::store');
    $routes->get('edit/(:num)', 'Category::edit/$1');
    $routes->post('update/(:num)', 'Category::update/$1');
    $routes->post('delete/(:num)', 'Category::delete/$1');
});

// Data Obat - dilihat banyak role, CRUD terbatas
$routes->group('drugs', ['filter' => 'role:admin,apoteker,gudang,dokter,ttk,kepala_farmasi'], static function ($routes): void {
    $routes->get('/', 'Drug::index');
});

$routes->group('drugs', ['filter' => 'role:admin,apoteker,gudang'], static function ($routes): void {
    $routes->get('create', 'Drug::create');
    $routes->post('store', 'Drug::store');
    $routes->get('edit/(:num)', 'Drug::edit/$1');
    $routes->post('update/(:num)', 'Drug::update/$1');
    $routes->post('delete/(:num)', 'Drug::delete/$1');
});

// Stok Obat
$routes->group('stock', ['filter' => 'role:admin,apoteker,gudang,kepala_farmasi'], static function ($routes): void {
    $routes->get('/', 'Stock::index');
    $routes->get('movements', 'Stock::movements');
});

$routes->group('stock', ['filter' => 'role:admin,apoteker,gudang'], static function ($routes): void {
    $routes->get('form/(:segment)', 'Stock::form/$1');
    $routes->post('store', 'Stock::store');
});

// Supplier
$routes->group('suppliers', ['filter' => 'role:admin,apoteker,gudang,kepala_farmasi'], static function ($routes): void {
    $routes->get('/', 'Supplier::index');
});

$routes->group('suppliers', ['filter' => 'role:admin,gudang'], static function ($routes): void {
    $routes->get('create', 'Supplier::create');
    $routes->post('store', 'Supplier::store');
    $routes->get('edit/(:num)', 'Supplier::edit/$1');
    $routes->post('update/(:num)', 'Supplier::update/$1');
    $routes->post('delete/(:num)', 'Supplier::delete/$1');
});

// Pembelian
$routes->group('purchases', ['filter' => 'role:admin,apoteker,gudang,kepala_farmasi'], static function ($routes): void {
    $routes->get('/', 'Purchase::index');
    $routes->get('(:num)', 'Purchase::show/$1');
});

$routes->group('purchases', ['filter' => 'role:admin,apoteker,gudang'], static function ($routes): void {
    $routes->get('create', 'Purchase::create');
    $routes->post('store', 'Purchase::store');
    $routes->post('receive/(:num)', 'Purchase::receive/$1');
    $routes->post('cancel/(:num)', 'Purchase::cancel/$1');
});

// Monitoring Kedaluwarsa
$routes->get('expiry', 'Expiry::index', ['filter' => 'role:admin,apoteker,gudang,kepala_farmasi']);

// Pasien
$routes->group('patients', ['filter' => 'role:admin,pendaftaran,dokter,apoteker,ttk'], static function ($routes): void {
    $routes->get('/', 'Patient::index');
});

$routes->group('patients', ['filter' => 'role:admin,pendaftaran'], static function ($routes): void {
    $routes->get('create', 'Patient::create');
    $routes->post('store', 'Patient::store');
    $routes->get('edit/(:num)', 'Patient::edit/$1');
    $routes->post('update/(:num)', 'Patient::update/$1');
    $routes->post('delete/(:num)', 'Patient::delete/$1');
});

// Resep
$routes->group('prescriptions', ['filter' => 'role:admin,dokter,apoteker,ttk'], static function ($routes): void {
    $routes->get('/', 'Prescription::index');
    $routes->get('(:num)', 'Prescription::show/$1');
});

$routes->group('prescriptions', ['filter' => 'role:admin,dokter'], static function ($routes): void {
    $routes->get('create', 'Prescription::create');
    $routes->post('store', 'Prescription::store');
});

$routes->group('prescriptions', ['filter' => 'role:admin,apoteker'], static function ($routes): void {
    $routes->post('verify/(:num)', 'Prescription::verify/$1');
});

$routes->group('prescriptions', ['filter' => 'role:admin,apoteker,ttk'], static function ($routes): void {
    $routes->post('dispense/(:num)', 'Prescription::dispense/$1');
    $routes->post('complete/(:num)', 'Prescription::complete/$1');
    $routes->get('labels/(:num)', 'Prescription::labels/$1');
});

$routes->group('prescriptions', ['filter' => 'role:admin,apoteker,dokter'], static function ($routes): void {
    $routes->post('cancel/(:num)', 'Prescription::cancel/$1');
});

// Penjualan / Transaksi
$routes->group('transactions', ['filter' => 'role:admin,kasir,kepala_farmasi,manajemen'], static function ($routes): void {
    $routes->get('/', 'Transaction::index');
    $routes->get('(:num)', 'Transaction::show/$1');
    $routes->get('receipt/(:num)', 'Transaction::receipt/$1');
});

$routes->group('transactions', ['filter' => 'role:admin,kasir'], static function ($routes): void {
    $routes->get('create', 'Transaction::create');
    $routes->post('store', 'Transaction::store');
    $routes->post('pay/(:num)', 'Transaction::pay/$1');
    $routes->post('cancel/(:num)', 'Transaction::cancel/$1');
});

// Antrean Pengambilan Obat
$routes->group('queue', ['filter' => 'auth'], static function ($routes): void {
    $routes->get('display', 'Queue::display');
    $routes->get('live', 'Queue::live');
});

$routes->group('queue', ['filter' => 'role:admin,apoteker,ttk,kasir'], static function ($routes): void {
    $routes->get('/', 'Queue::index');
    $routes->post('store', 'Queue::store');
    $routes->post('update/(:num)/(:segment)', 'Queue::updateStatus/$1/$2');
});

// Laporan Farmasi
$routes->group('reports', ['filter' => 'role:admin,kepala_farmasi,manajemen'], static function ($routes): void {
    $routes->get('/', 'Report::index');
});

// Manajemen Pengguna
$routes->group('users', ['filter' => 'role:admin'], static function ($routes): void {
    $routes->get('/', 'User::index');
    $routes->get('create', 'User::create');
    $routes->post('store', 'User::store');
    $routes->get('edit/(:num)', 'User::edit/$1');
    $routes->post('update/(:num)', 'User::update/$1');
    $routes->post('toggle/(:num)', 'User::toggle/$1');
    $routes->post('delete/(:num)', 'User::delete/$1');
});

// Riwayat Aktivitas (Audit Trail)
$routes->group('audit', ['filter' => 'role:admin,kepala_farmasi,manajemen'], static function ($routes): void {
    $routes->get('/', 'Audit::index');
});
