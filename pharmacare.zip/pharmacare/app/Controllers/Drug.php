<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\CategoryModel;
use App\Models\DrugModel;
use App\Models\StockMovementModel;

class Drug extends BaseController
{
    protected DrugModel $drugModel;
    protected CategoryModel $categoryModel;
    protected StockMovementModel $stockMovement;
    protected AuditLogModel $auditLog;

    public function __construct()
    {
        $this->drugModel       = new DrugModel();
        $this->categoryModel   = new CategoryModel();
        $this->stockMovement   = new StockMovementModel();
        $this->auditLog        = new AuditLogModel();
    }

    public function index()
    {
        $search     = $this->request->getGet('q');
        $categoryId = $this->request->getGet('category');
        $categoryId = $categoryId !== null && $categoryId !== '' ? (int) $categoryId : null;

        $drugs = $this->drugModel->getWithCategory($search, $categoryId, 10);

        return view('drugs/index', [
            'title'      => 'Data Obat - PharmaCare',
            'drugs'      => $drugs,
            'pager'      => $this->drugModel->pager,
            'search'     => $search,
            'categoryId' => $categoryId,
            'categories' => $this->categoryModel->orderBy('name', 'ASC')->findAll(),
            'drugModel'  => $this->drugModel,
        ]);
    }

    public function create()
    {
        return view('drugs/form', [
            'title'      => 'Tambah Obat - PharmaCare',
            'drug'       => null,
            'categories' => $this->categoryModel->orderBy('name', 'ASC')->findAll(),
        ]);
    }

    public function store()
    {
        $rules = [
            'category_id' => 'required|integer',
            'code'        => 'required|max_length[50]',
            'name'        => 'required|max_length[150]',
            'unit'        => 'required|max_length[30]',
            'buy_price'   => 'permit_empty|numeric|greater_than_equal_to[0]',
            'sell_price'  => 'permit_empty|numeric|greater_than_equal_to[0]',
            'dosage'      => 'permit_empty|max_length[100]',
            'description' => 'permit_empty',
            'min_stock'   => 'permit_empty|numeric|greater_than_equal_to[0]',
            'is_active'   => 'permit_empty|in_list[0,1]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $initialStock = (float) str_replace(',', '.', (string) $this->request->getPost('initial_stock'));
        if ($initialStock < 0) {
            $initialStock = 0;
        }

        $db = db_connect();
        $db->transBegin();

        $id = $this->drugModel->insert([
            'category_id'   => (int) $this->request->getPost('category_id'),
            'code'          => strtoupper(trim($this->request->getPost('code'))),
            'name'          => trim($this->request->getPost('name')),
            'unit'          => trim($this->request->getPost('unit')),
            'buy_price'     => (float) str_replace(',', '.', (string) ($this->request->getPost('buy_price') ?: 0)),
            'sell_price'    => (float) str_replace(',', '.', (string) ($this->request->getPost('sell_price') ?: 0)),
            'dosage'        => $this->request->getPost('dosage'),
            'description'   => $this->request->getPost('description'),
            'current_stock' => 0,
            'min_stock'     => (float) str_replace(',', '.', (string) ($this->request->getPost('min_stock') ?: 0)),
            'is_active'     => (int) ($this->request->getPost('is_active') ?? 1),
        ], true);

        if ($id === false) {
            $db->transRollback();

            return redirect()->back()->withInput()->with('error', 'Gagal menyimpan obat: ' . implode(', ', $this->drugModel->errors()));
        }

        if ($initialStock > 0) {
            $result = $this->stockMovement->record($id, 'in', $initialStock, (int) session()->get('userId'), 'Stok awal saat input obat');
            if (! $result['success']) {
                $db->transRollback();

                return redirect()->back()->withInput()->with('error', $result['message']);
            }
        }

        $db->transCommit();

        $this->auditLog->log((int) session()->get('userId'), 'create', 'drugs', $id, 'Tambah obat: ' . $this->request->getPost('name'));

        return redirect()->to('/drugs')->with('success', 'Obat berhasil ditambahkan.');
    }

    public function edit(int $id)
    {
        $drug = $this->drugModel->find($id);
        if (! $drug) {
            return redirect()->to('/drugs')->with('error', 'Obat tidak ditemukan.');
        }

        return view('drugs/form', [
            'title'      => 'Edit Obat - PharmaCare',
            'drug'       => $drug,
            'categories' => $this->categoryModel->orderBy('name', 'ASC')->findAll(),
        ]);
    }

    public function update(int $id)
    {
        $drug = $this->drugModel->find($id);
        if (! $drug) {
            return redirect()->to('/drugs')->with('error', 'Obat tidak ditemukan.');
        }

        $rules = [
            'category_id' => 'required|integer',
            'code'        => 'required|max_length[50]',
            'name'        => 'required|max_length[150]',
            'unit'        => 'required|max_length[30]',
            'buy_price'   => 'permit_empty|numeric|greater_than_equal_to[0]',
            'sell_price'  => 'permit_empty|numeric|greater_than_equal_to[0]',
            'dosage'      => 'permit_empty|max_length[100]',
            'description' => 'permit_empty',
            'min_stock'   => 'permit_empty|numeric|greater_than_equal_to[0]',
            'is_active'   => 'permit_empty|in_list[0,1]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $updated = $this->drugModel->update($id, [
            'category_id' => (int) $this->request->getPost('category_id'),
            'code'        => strtoupper(trim($this->request->getPost('code'))),
            'name'        => trim($this->request->getPost('name')),
            'unit'        => trim($this->request->getPost('unit')),
            'buy_price'   => (float) str_replace(',', '.', (string) ($this->request->getPost('buy_price') ?: 0)),
            'sell_price'  => (float) str_replace(',', '.', (string) ($this->request->getPost('sell_price') ?: 0)),
            'dosage'      => $this->request->getPost('dosage'),
            'description' => $this->request->getPost('description'),
            'min_stock'   => (float) str_replace(',', '.', (string) ($this->request->getPost('min_stock') ?: 0)),
            'is_active'   => (int) ($this->request->getPost('is_active') ?? 1),
        ]);

        if ($updated === false) {
            return redirect()->back()->withInput()->with('error', 'Gagal memperbarui obat: ' . implode(', ', $this->drugModel->errors()));
        }

        $this->auditLog->log((int) session()->get('userId'), 'update', 'drugs', $id, 'Edit obat: ' . $this->request->getPost('name'));

        return redirect()->to('/drugs')->with('success', 'Obat berhasil diperbarui.');
    }

    public function delete(int $id)
    {
        $drug = $this->drugModel->find($id);
        if (! $drug) {
            return redirect()->to('/drugs')->with('error', 'Obat tidak ditemukan.');
        }

        $this->drugModel->delete($id);
        $this->auditLog->log((int) session()->get('userId'), 'delete', 'drugs', $id, 'Hapus obat: ' . $drug['name']);

        return redirect()->to('/drugs')->with('success', 'Obat berhasil dihapus.');
    }
}
