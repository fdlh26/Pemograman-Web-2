<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\DrugBatchModel;
use App\Models\DrugModel;
use App\Models\PurchaseItemModel;
use App\Models\PurchaseModel;
use App\Models\StockMovementModel;
use App\Models\SupplierModel;

class Purchase extends BaseController
{
    protected PurchaseModel $purchaseModel;
    protected PurchaseItemModel $itemModel;
    protected SupplierModel $supplierModel;
    protected DrugModel $drugModel;
    protected DrugBatchModel $batchModel;
    protected StockMovementModel $stockMovement;
    protected AuditLogModel $auditLog;

    public function __construct()
    {
        $this->purchaseModel  = new PurchaseModel();
        $this->itemModel      = new PurchaseItemModel();
        $this->supplierModel  = new SupplierModel();
        $this->drugModel      = new DrugModel();
        $this->batchModel     = new DrugBatchModel();
        $this->stockMovement  = new StockMovementModel();
        $this->auditLog       = new AuditLogModel();
    }

    public function index()
    {
        $status = $this->request->getGet('status');
        $status = in_array($status, ['ordered', 'received', 'cancelled'], true) ? $status : null;
        $search = $this->request->getGet('q');

        return view('purchases/index', [
            'title'     => 'Pembelian Obat - PharmaCare',
            'purchases' => $this->purchaseModel->getWithSupplier($status, $search),
            'pager'     => $this->purchaseModel->pager,
            'status'    => $status,
            'search'    => $search,
        ]);
    }

    public function create()
    {
        return view('purchases/form', [
            'title'     => 'Buat Pembelian - PharmaCare',
            'suppliers' => $this->supplierModel->where('is_active', 1)->orderBy('name', 'ASC')->findAll(),
            'drugs'     => $this->drugModel->where('is_active', 1)->orderBy('name', 'ASC')->findAll(),
            'number'    => $this->purchaseModel->generateNumber(),
        ]);
    }

    public function store()
    {
        $rules = [
            'supplier_id'  => 'required|integer',
            'order_date'   => 'required|valid_date',
            'note'         => 'permit_empty',
            'item_drug_id' => 'required',
            'item_qty'     => 'required',
            'item_price'   => 'required',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $drugIds  = (array) $this->request->getPost('item_drug_id');
        $qtys     = (array) $this->request->getPost('item_qty');
        $prices   = (array) $this->request->getPost('item_price');
        $batches  = (array) ($this->request->getPost('item_batch') ?? []);
        $expiries = (array) ($this->request->getPost('item_expiry') ?? []);

        if ($drugIds === []) {
            return redirect()->back()->withInput()->with('error', 'Minimal harus ada satu item pembelian.');
        }

        $items = [];
        foreach ($drugIds as $i => $drugId) {
            $drugId = (int) $drugId;
            $qty    = (float) str_replace(',', '.', (string) ($qtys[$i] ?? 0));
            $price  = (float) str_replace(',', '.', (string) ($prices[$i] ?? 0));

            if ($drugId <= 0 || $qty <= 0) {
                return redirect()->back()->withInput()->with('error', 'Setiap item harus memiliki obat dan jumlah lebih besar dari 0.');
            }

            if (! $this->drugModel->find($drugId)) {
                return redirect()->back()->withInput()->with('error', 'Obat pada item ke-' . ($i + 1) . ' tidak ditemukan.');
            }

            $items[] = [
                'drug_id'      => $drugId,
                'quantity'     => $qty,
                'unit_price'   => $price,
                'batch_number' => trim((string) ($batches[$i] ?? '')) ?: null,
                'expiry_date'  => trim((string) ($expiries[$i] ?? '')) ?: null,
            ];
        }

        $total = 0.0;
        foreach ($items as $item) {
            $total += $item['quantity'] * $item['unit_price'];
        }

        $db = db_connect();
        $db->transBegin();

        $purchaseId = $this->purchaseModel->insert([
            'supplier_id'     => (int) $this->request->getPost('supplier_id'),
            'user_id'         => (int) session()->get('userId'),
            'purchase_number' => $this->purchaseModel->generateNumber(),
            'order_date'      => $this->request->getPost('order_date'),
            'status'          => 'ordered',
            'total_amount'    => $total,
            'note'            => $this->request->getPost('note'),
        ], true);

        if ($purchaseId === false) {
            $db->transRollback();

            return redirect()->back()->withInput()->with('error', 'Gagal menyimpan pembelian: ' . implode(', ', $this->purchaseModel->errors()));
        }

        foreach ($items as $item) {
            $item['purchase_id'] = $purchaseId;
            $itemId              = $this->itemModel->insert($item);

            if ($itemId === false) {
                $db->transRollback();

                return redirect()->back()->withInput()->with('error', 'Gagal menyimpan item pembelian: ' . implode(', ', $this->itemModel->errors()));
            }
        }

        $db->transCommit();

        $this->auditLog->log(
            (int) session()->get('userId'),
            'create',
            'purchases',
            $purchaseId,
            'Buat pembelian: ' . $this->purchaseModel->find($purchaseId)['purchase_number']
        );

        return redirect()->to('/purchases/' . $purchaseId)->with('success', 'Pembelian berhasil dibuat.');
    }

    public function show(int $id)
    {
        $purchase = $this->purchaseModel->find($id);
        if (! $purchase) {
            return redirect()->to('/purchases')->with('error', 'Pembelian tidak ditemukan.');
        }

        $supplier = $this->supplierModel->find($purchase['supplier_id']);
        $items    = $this->itemModel->getWithDrug($id);

        return view('purchases/show', [
            'title'    => 'Detail Pembelian - PharmaCare',
            'purchase' => $purchase,
            'supplier' => $supplier,
            'items'    => $items,
        ]);
    }

    public function receive(int $id)
    {
        $purchase = $this->purchaseModel->find($id);
        if (! $purchase) {
            return redirect()->to('/purchases')->with('error', 'Pembelian tidak ditemukan.');
        }

        if ($purchase['status'] !== 'ordered') {
            return redirect()->to('/purchases/' . $id)->with('error', 'Hanya pembelian berstatus "dipesan" yang dapat diterima.');
        }

        $items = $this->itemModel->getWithDrug($id);
        if ($items === []) {
            return redirect()->to('/purchases/' . $id)->with('error', 'Pembelian tidak memiliki item.');
        }

        $db = db_connect();
        $db->transBegin();

        foreach ($items as $item) {
            $qty = (float) $item['quantity'];

            $batchId = $this->batchModel->insert([
                'drug_id'          => (int) $item['drug_id'],
                'purchase_item_id' => (int) $item['id'],
                'batch_number'     => $item['batch_number'],
                'expiry_date'      => $item['expiry_date'],
                'initial_qty'      => $qty,
                'remaining_qty'    => $qty,
            ]);

            if ($batchId === false) {
                $db->transRollback();

                return redirect()->to('/purchases/' . $id)->with('error', 'Gagal membuat batch: ' . implode(', ', $this->batchModel->errors()));
            }

            // Tambah stok obat + catat movement (tanpa buka transaksi baru)
            $drug = $this->drugModel->find((int) $item['drug_id']);
            $db->table('drugs')
                ->where('id', (int) $item['drug_id'])
                ->set('current_stock', 'current_stock + ' . $qty, false)
                ->update();

            $this->stockMovement->save([
                'drug_id'      => (int) $item['drug_id'],
                'user_id'      => (int) session()->get('userId'),
                'type'         => 'in',
                'quantity'     => $qty,
                'stock_before' => (float) $drug['current_stock'],
                'stock_after'  => (float) $drug['current_stock'] + $qty,
                'note'         => 'Penerimaan ' . $purchase['purchase_number'] . ' (Batch: ' . ($item['batch_number'] ?? '-') . ')',
            ]);
        }

        $updated = $this->purchaseModel->update($id, [
            'status'      => 'received',
            'received_at' => date('Y-m-d H:i:s'),
        ]);

        if ($updated === false) {
            $db->transRollback();

            return redirect()->to('/purchases/' . $id)->with('error', 'Gagal memperbarui status pembelian.');
        }

        $db->transCommit();

        $this->auditLog->log(
            (int) session()->get('userId'),
            'receive',
            'purchases',
            $id,
            'Terima pembelian: ' . $purchase['purchase_number']
        );

        return redirect()->to('/purchases/' . $id)->with('success', 'Pembelian berhasil diterima. Stok dan batch telah diperbarui.');
    }

    public function cancel(int $id)
    {
        $purchase = $this->purchaseModel->find($id);
        if (! $purchase) {
            return redirect()->to('/purchases')->with('error', 'Pembelian tidak ditemukan.');
        }

        if ($purchase['status'] !== 'ordered') {
            return redirect()->to('/purchases/' . $id)->with('error', 'Hanya pembelian berstatus "dipesan" yang dapat dibatalkan.');
        }

        $this->purchaseModel->update($id, ['status' => 'cancelled']);
        $this->auditLog->log((int) session()->get('userId'), 'cancel', 'purchases', $id, 'Batalkan pembelian: ' . $purchase['purchase_number']);

        return redirect()->to('/purchases/' . $id)->with('success', 'Pembelian berhasil dibatalkan.');
    }
}
