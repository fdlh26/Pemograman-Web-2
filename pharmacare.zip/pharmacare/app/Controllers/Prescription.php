<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\DrugModel;
use App\Models\PatientModel;
use App\Models\PrescriptionItemModel;
use App\Models\PrescriptionModel;
use App\Models\QueueModel;
use App\Models\StockMovementModel;

class Prescription extends BaseController
{
    protected PrescriptionModel $prescriptionModel;
    protected PrescriptionItemModel $itemModel;
    protected PatientModel $patientModel;
    protected DrugModel $drugModel;
    protected StockMovementModel $stockMovement;
    protected AuditLogModel $auditLog;

    public function __construct()
    {
        $this->prescriptionModel = new PrescriptionModel();
        $this->itemModel         = new PrescriptionItemModel();
        $this->patientModel      = new PatientModel();
        $this->drugModel         = new DrugModel();
        $this->stockMovement     = new StockMovementModel();
        $this->auditLog          = new AuditLogModel();
    }

    public function index()
    {
        $status = $this->request->getGet('status');
        $status = in_array($status, ['pending', 'verified', 'prepared', 'completed', 'cancelled'], true) ? $status : null;
        $search = $this->request->getGet('q');

        return view('prescriptions/index', [
            'title'         => 'Pelayanan Resep - PharmaCare',
            'prescriptions' => $this->prescriptionModel->getWithRelations($status, $search),
            'pager'         => $this->prescriptionModel->pager,
            'status'        => $status,
            'search'        => $search,
        ]);
    }

    public function create()
    {
        $patients = $this->patientModel->orderBy('name', 'ASC')->findAll();
        $doctors  = db_connect()->table('users')
            ->select('users.id, users.name, roles.name AS role_name')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('roles.name', 'dokter')
            ->where('users.is_active', 1)
            ->where('users.deleted_at', null)
            ->orderBy('users.name', 'ASC')
            ->get()->getResultArray();

        return view('prescriptions/form', [
            'title'    => 'Buat Resep - PharmaCare',
            'patients' => $patients,
            'doctors'  => $doctors,
            'drugs'    => $this->drugModel->where('is_active', 1)->orderBy('name', 'ASC')->findAll(),
            'number'   => $this->prescriptionModel->generateNumber(),
        ]);
    }

    public function store()
    {
        $rules = [
            'patient_id'  => 'required|integer',
            'doctor_id'   => 'required|integer',
            'diagnosis'   => 'permit_empty|max_length[255]',
            'doctor_note' => 'permit_empty',
            'item_drug_id' => 'required',
            'item_qty'     => 'required',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $drugIds = (array) $this->request->getPost('item_drug_id');
        $qtys    = (array) $this->request->getPost('item_qty');
        $dosages = (array) ($this->request->getPost('item_dosage') ?? []);
        $notes   = (array) ($this->request->getPost('item_note') ?? []);

        if ($drugIds === []) {
            return redirect()->back()->withInput()->with('error', 'Minimal harus ada satu item resep.');
        }

        $items = [];
        foreach ($drugIds as $i => $drugId) {
            $drugId = (int) $drugId;
            $qty    = (float) str_replace(',', '.', (string) ($qtys[$i] ?? 0));

            if ($drugId <= 0 || $qty <= 0) {
                return redirect()->back()->withInput()->with('error', 'Setiap item harus memiliki obat dan jumlah lebih besar dari 0.');
            }

            if (! $this->drugModel->find($drugId)) {
                return redirect()->back()->withInput()->with('error', 'Obat pada item ke-' . ($i + 1) . ' tidak ditemukan.');
            }

            $items[] = [
                'drug_id'            => $drugId,
                'quantity'           => $qty,
                'dosage_instruction' => trim((string) ($dosages[$i] ?? '')) ?: null,
                'note'               => trim((string) ($notes[$i] ?? '')) ?: null,
            ];
        }

        $db = db_connect();
        $db->transBegin();

        $rxId = $this->prescriptionModel->insert([
            'patient_id'          => (int) $this->request->getPost('patient_id'),
            'doctor_id'           => (int) $this->request->getPost('doctor_id'),
            'prescription_number' => $this->prescriptionModel->generateNumber(),
            'status'              => 'pending',
            'diagnosis'           => $this->request->getPost('diagnosis'),
            'doctor_note'         => $this->request->getPost('doctor_note'),
        ], true);

        if ($rxId === false) {
            $db->transRollback();

            return redirect()->back()->withInput()->with('error', 'Gagal menyimpan resep: ' . implode(', ', $this->prescriptionModel->errors()));
        }

        foreach ($items as $item) {
            $item['prescription_id'] = $rxId;
            $itemId = $this->itemModel->insert($item);

            if ($itemId === false) {
                $db->transRollback();

                return redirect()->back()->withInput()->with('error', 'Gagal menyimpan item resep: ' . implode(', ', $this->itemModel->errors()));
            }
        }

        $db->transCommit();

        $this->auditLog->log(
            (int) session()->get('userId'),
            'create',
            'prescriptions',
            $rxId,
            'Buat resep: ' . $this->prescriptionModel->find($rxId)['prescription_number']
        );

        return redirect()->to('/prescriptions/' . $rxId)->with('success', 'Resep berhasil dibuat.');
    }

    public function show(int $id)
    {
        $rx = $this->prescriptionModel->find($id);
        if (! $rx) {
            return redirect()->to('/prescriptions')->with('error', 'Resep tidak ditemukan.');
        }

        $patient   = $this->patientModel->find($rx['patient_id']);
        $doctor    = db_connect()->table('users')->where('id', $rx['doctor_id'])->get()->getRowArray();
        $items     = $this->itemModel->getWithDrug($id);
        $verifier  = $rx['verified_by'] ? db_connect()->table('users')->where('id', $rx['verified_by'])->get()->getRowArray() : null;
        $preparer  = $rx['prepared_by'] ? db_connect()->table('users')->where('id', $rx['prepared_by'])->get()->getRowArray() : null;

        return view('prescriptions/show', [
            'title'      => 'Detail Resep - PharmaCare',
            'rx'         => $rx,
            'patient'    => $patient,
            'doctor'     => $doctor,
            'items'      => $items,
            'verifier'   => $verifier,
            'preparer'   => $preparer,
        ]);
    }

    public function labels(int $id)
    {
        $rx = $this->prescriptionModel->find($id);
        if (! $rx) {
            return redirect()->to('/prescriptions')->with('error', 'Resep tidak ditemukan.');
        }

        if (! in_array($rx['status'], ['verified', 'prepared', 'completed'], true)) {
            return redirect()->to('/prescriptions/' . $id)->with('error', 'Label hanya dapat dicetak untuk resep yang sudah diverifikasi.');
        }

        $patient = $this->patientModel->find($rx['patient_id']);
        $doctor  = db_connect()->table('users')->where('id', $rx['doctor_id'])->get()->getRowArray();
        $items   = $this->itemModel->getWithDrug($id);

        if ($items === []) {
            return redirect()->to('/prescriptions/' . $id)->with('error', 'Resep tidak memiliki item.');
        }

        $queue = (new \App\Models\QueueModel())
            ->where('prescription_id', $id)
            ->whereIn('status', ['waiting', 'processing', 'ready', 'called', 'done'])
            ->orderBy('id', 'DESC')
            ->first();

        $verifier = $rx['verified_by']
            ? db_connect()->table('users')->where('id', $rx['verified_by'])->get()->getRowArray()
            : null;

        $this->auditLog->log(
            (int) session()->get('userId'),
            'print_labels',
            'prescriptions',
            $id,
            'Cetak label obat resep: ' . $rx['prescription_number']
        );

        return view('prescriptions/labels', [
            'title'    => 'Cetak Label Obat - PharmaCare',
            'rx'       => $rx,
            'patient'  => $patient,
            'doctor'   => $doctor,
            'items'    => $items,
            'queue'    => $queue,
            'verifier' => $verifier,
            'printer'  => session()->get('userRole'),
        ]);
    }

    public function verify(int $id)
    {
        $rx = $this->prescriptionModel->find($id);
        if (! $rx) {
            return redirect()->to('/prescriptions')->with('error', 'Resep tidak ditemukan.');
        }

        if ($rx['status'] !== 'pending') {
            return redirect()->to('/prescriptions/' . $id)->with('error', 'Hanya resep berstatus "menunggu verifikasi" yang dapat diverifikasi.');
        }

        $items = $this->itemModel->getWithDrug($id);
        if ($items === []) {
            return redirect()->to('/prescriptions/' . $id)->with('error', 'Resep tidak memiliki item.');
        }

        // Cek ketersediaan stok
        $problems = [];
        foreach ($items as $item) {
            if ((int) ($item['drug_active'] ?? 1) !== 1) {
                $problems[] = $item['drug_name'] . ' (nonaktif)';
                continue;
            }
            if ((float) $item['current_stock'] < (float) $item['quantity']) {
                $problems[] = $item['drug_name'] . ' (stok: ' . number_format((float) $item['current_stock'], 2) . ' ' . $item['unit'] . ', diminta: ' . number_format((float) $item['quantity'], 2) . ')';
            }
        }

        if ($problems !== []) {
            return redirect()->to('/prescriptions/' . $id)->with('error', 'Verifikasi ditolak — stok tidak mencukupi: ' . implode('; ', $problems));
        }

        $this->prescriptionModel->update($id, [
            'status'      => 'verified',
            'verified_by' => (int) session()->get('userId'),
            'verified_at' => date('Y-m-d H:i:s'),
        ]);

        $this->auditLog->log((int) session()->get('userId'), 'verify', 'prescriptions', $id, 'Verifikasi resep: ' . $rx['prescription_number']);

        return redirect()->to('/prescriptions/' . $id)->with('success', 'Resep berhasil diverifikasi. Silakan siapkan obat.');
    }

    public function dispense(int $id)
    {
        $rx = $this->prescriptionModel->find($id);
        if (! $rx) {
            return redirect()->to('/prescriptions')->with('error', 'Resep tidak ditemukan.');
        }

        if ($rx['status'] !== 'verified') {
            return redirect()->to('/prescriptions/' . $id)->with('error', 'Hanya resep terverifikasi yang dapat disiapkan.');
        }

        $items = $this->itemModel->getWithDrug($id);
        if ($items === []) {
            return redirect()->to('/prescriptions/' . $id)->with('error', 'Resep tidak memiliki item.');
        }

        $db       = db_connect();
        $userId   = (int) session()->get('userId');
        $failures = [];

        $db->transBegin();

        foreach ($items as $item) {
            $result = $this->stockMovement->record(
                (int) $item['drug_id'],
                'out',
                (float) $item['quantity'],
                $userId,
                'Pengeluaran resep ' . $rx['prescription_number']
            );

            if (! $result['success']) {
                $failures[] = $item['drug_name'] . ': ' . $result['message'];
            }
        }

        if ($failures !== []) {
            $db->transRollback();

            return redirect()->to('/prescriptions/' . $id)->with('error', 'Penyiapan obat gagal — ' . implode('; ', $failures));
        }

        $updated = $this->prescriptionModel->update($id, [
            'status'      => 'prepared',
            'prepared_by' => $userId,
            'prepared_at' => date('Y-m-d H:i:s'),
        ]);

        if ($updated === false) {
            $db->transRollback();

            return redirect()->to('/prescriptions/' . $id)->with('error', 'Gagal memperbarui status resep.');
        }

        // Buat nomor antrean pengambilan obat
        $queueResult = (new QueueModel())->createForPrescription($id, (int) $rx['patient_id']);
        $queueNumber = $queueResult['queue']['queue_number'] ?? null;

        $db->transCommit();

        $this->auditLog->log($userId, 'dispense', 'prescriptions', $id, 'Siapkan obat resep: ' . $rx['prescription_number']);

        $message = 'Obat berhasil disiapkan dan stok telah dikurangi.';
        if ($queueNumber !== null) {
            $message .= ' Nomor antrean: ' . $queueNumber . '.';
        }

        return redirect()->to('/prescriptions/' . $id)->with('success', $message);
    }

    public function complete(int $id)
    {
        $rx = $this->prescriptionModel->find($id);
        if (! $rx) {
            return redirect()->to('/prescriptions')->with('error', 'Resep tidak ditemukan.');
        }

        if ($rx['status'] !== 'prepared') {
            return redirect()->to('/prescriptions/' . $id)->with('error', 'Hanya resep berstatus "obat disiapkan" yang dapat diselesaikan.');
        }

        $this->prescriptionModel->update($id, [
            'status'       => 'completed',
            'completed_at' => date('Y-m-d H:i:s'),
        ]);

        $this->auditLog->log((int) session()->get('userId'), 'complete', 'prescriptions', $id, 'Selesaikan resep: ' . $rx['prescription_number']);

        return redirect()->to('/prescriptions/' . $id)->with('success', 'Resep telah selesai. Obat dapat diserahkan ke pasien.');
    }

    public function cancel(int $id)
    {
        $rx = $this->prescriptionModel->find($id);
        if (! $rx) {
            return redirect()->to('/prescriptions')->with('error', 'Resep tidak ditemukan.');
        }

        if (! in_array($rx['status'], ['pending', 'verified'], true)) {
            return redirect()->to('/prescriptions/' . $id)->with('error', 'Hanya resep berstatus menunggu/terverifikasi yang dapat dibatalkan.');
        }

        $reason = trim((string) $this->request->getPost('cancel_reason'));

        $this->prescriptionModel->update($id, [
            'status'        => 'cancelled',
            'cancelled_at'  => date('Y-m-d H:i:s'),
            'cancel_reason' => $reason !== '' ? $reason : null,
        ]);

        $this->auditLog->log((int) session()->get('userId'), 'cancel', 'prescriptions', $id, 'Batalkan resep: ' . $rx['prescription_number'] . ($reason !== '' ? ' (' . $reason . ')' : ''));

        return redirect()->to('/prescriptions/' . $id)->with('success', 'Resep berhasil dibatalkan.');
    }
}
