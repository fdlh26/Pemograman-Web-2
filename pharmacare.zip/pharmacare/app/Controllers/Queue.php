<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\PatientModel;
use App\Models\QueueModel;

class Queue extends BaseController
{
    protected QueueModel $queueModel;
    protected PatientModel $patientModel;
    protected AuditLogModel $auditLog;

    public function __construct()
    {
        $this->queueModel   = new QueueModel();
        $this->patientModel = new PatientModel();
        $this->auditLog     = new AuditLogModel();
    }

    public function index()
    {
        return view('queue/index', [
            'title'    => 'Antrean Pengambilan Obat - PharmaCare',
            'queues'   => $this->queueModel->getToday(),
            'pager'    => $this->queueModel->pager,
            'live'     => $this->queueModel->getLiveStatus(),
            'patients' => $this->patientModel->orderBy('name', 'ASC')->findAll(),
        ]);
    }

    public function store()
    {
        $patientId = (int) ($this->request->getPost('patient_id') ?: 0) ?: null;
        $note      = trim((string) $this->request->getPost('note'));

        if (! $patientId) {
            return redirect()->back()->with('error', 'Pasien harus dipilih.');
        }

        $patient = $this->patientModel->find($patientId);
        if (! $patient) {
            return redirect()->back()->with('error', 'Pasien tidak ditemukan.');
        }

        $db = db_connect();
        $db->transBegin();

        $queueId = $this->queueModel->insert([
            'queue_number' => $this->queueModel->generateNumber(),
            'queue_date'   => date('Y-m-d'),
            'patient_id'   => $patientId,
            'status'       => 'waiting',
            'note'         => $note !== '' ? $note : null,
        ], true);

        if ($queueId === false) {
            $db->transRollback();

            return redirect()->back()->with('error', 'Gagal membuat antrean: ' . implode(', ', $this->queueModel->errors()));
        }

        $db->transCommit();

        $queue = $this->queueModel->find($queueId);
        $this->auditLog->log(
            (int) session()->get('userId'),
            'create',
            'queues',
            $queueId,
            'Buat antrean manual: ' . $queue['queue_number'] . ' untuk ' . $patient['name']
        );

        return redirect()->to('/queue')->with('success', 'Nomor antrean ' . $queue['queue_number'] . ' berhasil dibuat untuk ' . $patient['name'] . '.');
    }

    public function updateStatus(int $id, string $action)
    {
        $queue = $this->queueModel->find($id);
        if (! $queue) {
            return redirect()->to('/queue')->with('error', 'Antrean tidak ditemukan.');
        }

        $allowed = [
            'process' => ['from' => ['waiting'], 'to' => 'processing', 'label' => 'diproses'],
            'ready'   => ['from' => ['waiting', 'processing'], 'to' => 'ready', 'label' => 'siap diambil'],
            'call'    => ['from' => ['waiting', 'processing', 'ready'], 'to' => 'called', 'label' => 'dipanggil'],
            'done'    => ['from' => ['waiting', 'processing', 'ready', 'called'], 'to' => 'done', 'label' => 'selesai'],
        ];

        if (! isset($allowed[$action])) {
            return redirect()->to('/queue')->with('error', 'Aksi tidak valid.');
        }

        if (! in_array($queue['status'], $allowed[$action]['from'], true)) {
            [$label, $color] = $this->queueModel->getStatusLabel($queue['status']);

            return redirect()->to('/queue')->with('error', 'Antrean berstatus "' . $label . '" tidak dapat di' . $allowed[$action]['label'] . '.');
        }

        $data = ['status' => $allowed[$action]['to']];
        if ($action === 'call') {
            $data['called_at'] = date('Y-m-d H:i:s');
            $data['called_by'] = (int) session()->get('userId');
        }
        if ($action === 'done') {
            $data['finished_at'] = date('Y-m-d H:i:s');
        }

        $this->queueModel->update($id, $data);

        $this->auditLog->log(
            (int) session()->get('userId'),
            'queue_' . $action,
            'queues',
            $id,
            'Antrean ' . $queue['queue_number'] . ' ' . $allowed[$action]['label']
        );

        return redirect()->to('/queue')->with('success', 'Antrean ' . $queue['queue_number'] . ' telah ' . $allowed[$action]['label'] . '.');
    }

    public function display()
    {
        return view('queue/display', [
            'title' => 'Layar Antrean - PharmaCare',
        ]);
    }

    public function live()
    {
        return $this->response->setJSON($this->queueModel->getLiveStatus());
    }
}
