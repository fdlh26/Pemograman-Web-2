<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\CategoryModel;

class Category extends BaseController
{
    protected CategoryModel $categoryModel;
    protected AuditLogModel $auditLog;

    public function __construct()
    {
        $this->categoryModel = new CategoryModel();
        $this->auditLog      = new AuditLogModel();
    }

    public function index()
    {
        $search = $this->request->getGet('q');

        $builder = $this->categoryModel;
        if ($search !== null && $search !== '') {
            $builder = $builder->like('name', $search);
        }

        $categories = $builder->orderBy('name', 'ASC')->paginate(10, 'categories');
        $pager      = $this->categoryModel->pager;

        return view('categories/index', [
            'title'      => 'Kategori Obat - PharmaCare',
            'categories' => $categories,
            'pager'      => $pager,
            'search'     => $search,
        ]);
    }

    public function create()
    {
        return view('categories/form', [
            'title'    => 'Tambah Kategori - PharmaCare',
            'category' => null,
        ]);
    }

    public function store()
    {
        $rules = [
            'name'        => 'required|max_length[100]',
            'description' => 'permit_empty|max_length[255]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $id = $this->categoryModel->insert([
            'name'        => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
        ]);

        if ($id === false) {
            return redirect()->back()->withInput()->with('error', 'Gagal menyimpan kategori: ' . implode(', ', $this->categoryModel->errors()));
        }

        $this->auditLog->log((int) session()->get('userId'), 'create', 'categories', $id, 'Tambah kategori: ' . $this->request->getPost('name'));

        return redirect()->to('/categories')->with('success', 'Kategori berhasil ditambahkan.');
    }

    public function edit(int $id)
    {
        $category = $this->categoryModel->find($id);
        if (! $category) {
            return redirect()->to('/categories')->with('error', 'Kategori tidak ditemukan.');
        }

        return view('categories/form', [
            'title'    => 'Edit Kategori - PharmaCare',
            'category' => $category,
        ]);
    }

    public function update(int $id)
    {
        $category = $this->categoryModel->find($id);
        if (! $category) {
            return redirect()->to('/categories')->with('error', 'Kategori tidak ditemukan.');
        }

        $rules = [
            'name'        => 'required|max_length[100]',
            'description' => 'permit_empty|max_length[255]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $updated = $this->categoryModel->update($id, [
            'name'        => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
        ]);

        if ($updated === false) {
            return redirect()->back()->withInput()->with('error', 'Gagal memperbarui kategori: ' . implode(', ', $this->categoryModel->errors()));
        }

        $this->auditLog->log((int) session()->get('userId'), 'update', 'categories', $id, 'Edit kategori: ' . $this->request->getPost('name'));

        return redirect()->to('/categories')->with('success', 'Kategori berhasil diperbarui.');
    }

    public function delete(int $id)
    {
        $category = $this->categoryModel->find($id);
        if (! $category) {
            return redirect()->to('/categories')->with('error', 'Kategori tidak ditemukan.');
        }

        $drugCount = (int) db_connect()->table('drugs')->where('category_id', $id)->countAllResults();
        if ($drugCount > 0) {
            return redirect()->to('/categories')->with('error', 'Kategori tidak dapat dihapus karena masih digunakan oleh ' . $drugCount . ' obat.');
        }

        $this->categoryModel->delete($id);
        $this->auditLog->log((int) session()->get('userId'), 'delete', 'categories', $id, 'Hapus kategori: ' . $category['name']);

        return redirect()->to('/categories')->with('success', 'Kategori berhasil dihapus.');
    }
}
