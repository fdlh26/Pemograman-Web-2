<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\RoleModel;
use App\Models\UserModel;

class Auth extends BaseController
{
    protected UserModel $userModel;
    protected RoleModel $roleModel;
    protected AuditLogModel $auditLog;

    public function __construct()
    {
        $this->userModel  = new UserModel();
        $this->roleModel  = new RoleModel();
        $this->auditLog   = new AuditLogModel();
    }

    public function login()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to('/dashboard');
        }

        return view('auth/login', [
            'title' => 'Login - PharmaCare',
        ]);
    }

    public function attempt()
    {
        $rules = [
            'username' => 'required',
            'password' => 'required',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $username = trim((string) $this->request->getPost('username'));
        $password = (string) $this->request->getPost('password');

        $user = $this->userModel->findActiveByUsername($username);

        if (! $user || ! password_verify($password, $user['password'])) {
            $this->auditLog->log(null, 'login_failed', 'users', null, 'Percobaan login gagal untuk username: ' . $username);

            return redirect()->back()->withInput()->with('error', 'Username atau password salah.');
        }

        if ((int) $user['is_active'] !== 1) {
            return redirect()->back()->withInput()->with('error', 'Akun Anda tidak aktif. Hubungi administrator.');
        }

        $this->userModel->update($user['id'], ['last_login_at' => date('Y-m-d H:i:s')]);

        $role      = $this->roleModel->find($user['role_id']);
        $roleName  = $role['name'] ?? '';
        $roleLabel = $role['description'] ?? $roleName;

        session()->set([
            'isLoggedIn'    => true,
            'userId'        => $user['id'],
            'userName'      => $user['name'],
            'userUsername'  => $user['username'],
            'userEmail'     => $user['email'],
            'userRole'      => $roleName,
            'userRoleLabel' => $roleLabel,
        ]);

        $this->auditLog->log($user['id'], 'login', 'users', $user['id'], 'Login berhasil: ' . $user['name'] . ' (' . $user['username'] . ')');

        return redirect()->to('/dashboard')->with('success', 'Selamat datang, ' . $user['name'] . '!');
    }

    public function logout()
    {
        $userId = session()->get('userId');

        if ($userId) {
            $this->auditLog->log($userId, 'logout', 'users', $userId, 'Logout: ' . session()->get('userName'));
        }

        session()->destroy();

        return redirect()->to('/login')->with('success', 'Anda telah logout.');
    }
}
