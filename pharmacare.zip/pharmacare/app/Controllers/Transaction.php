<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\DrugModel;
use App\Models\PatientModel;
use App\Models\PrescriptionItemModel;
use App\Models\PrescriptionModel;
use App\Models\StockMovementModel;
use App\Models\TransactionItemModel;
use App\Models\TransactionModel;

class Transaction extends BaseController
{
    protected TransactionModel $transactionModel;
    protected TransactionItemModel $itemModel;
    protected PatientModel $patientModel;
    protected PrescriptionModel $prescriptionModel;
    protected PrescriptionItemModel $rxItemModel;
    protected DrugModel $drugModel;
    protected StockMovementModel $stockMovement;
    protected AuditLogModel $auditLog;

    public function __construct()
    {
        $this->transactionModel = new TransactionModel();
        $this->itemModel        = new TransactionItemModel();
        $this->patientModel     = new PatientModel();
        $this->prescriptionModel = new PrescriptionModel();
        $this->rxItemModel      = new PrescriptionItemModel();
        $this->drugModel        = new DrugModel();
        $this->stockMovement    = new StockMovementModel();
        $this->auditLog         = new AuditLogModel();
    }

    public function index()
    {
        $status = $this->request->getGet('status');
        $status = in_array($status, ['pending', 'paid', 'cancelled'], true) ? $status : null;
        $search = $this->request->getGet('q');

        return view('transactions/index', [
            'title'        => 'Penjualan - PharmaCare',
            'transactions' => $this->transactionModel->getWithRelations($status, $search),
            'pager'        => $this->transactionModel->pager,
            'status'       => $status,
            'search'       => $search,
        ]);
    }

    public function create()
    {
        $prescriptionId = $this->request->getGet('prescription_id');
        $prescription   = null;
        $rxItems        = [];

        if ($prescriptionId !== null && $prescriptionId !== '') {
            $prescription = $this->prescriptionModel->find((int) $prescriptionId);

            if ($prescription && ! in_array($prescription['status'], ['prepared', 'completed'], true)) {
                return redirect()->to('/transactions/create')->with('error', 'Hanya resep berstatus "obat disiapkan" atau "selesai" yang dapat dibayar.');
            }

            if ($prescription && $this->transactionModel->isPrescriptionPaid((int) $prescriptionId)) {
                return redirect()->to('/transactions/create')->with('error', 'Resep tersebut sudah pernah dibayar.');
            }

            if ($prescription) {
                $rxItems = $this->rxItemModel->getWithDrug((int) $prescriptionId);
            }
        }

        $readyPrescriptions = db_connect()->table('prescriptions')
            ->select('prescriptions.id, prescriptions.prescription_number, prescriptions.status, patients.name AS patient_name')
            ->join('patients', 'patients.id = prescriptions.patient_id', 'left')
            ->whereIn('prescriptions.status', ['prepared'])
            ->orderBy('prescriptions.id', 'DESC')
            ->get()->getResultArray();

        return view('transactions/form', [
            'title'             => 'Buat Transaksi - PharmaCare',
            'patients'          => $this->patientModel->orderBy('name', 'ASC')->findAll(),
            'drugs'             => $this->drugModel->where('is_active', 1)->orderBy('name', 'ASC')->findAll(),
            'prescriptions'     => $readyPrescriptions,
            'prescription'      => $prescription,
            'rxItems'           => $rxItems,
            'number'            => $this->transactionModel->generateNumber(),
        ]);
    }

    public function store()
    {
        $type = (string) $this->request->getPost('type');
        if (! in_array($type, ['otc', 'prescription'], true)) {
            return redirect()->back()->with('error', 'Jenis transaksi tidak valid.');
        }

        $discount = (float) str_replace(',', '.', (string) ($this->request->getPost('discount') ?: 0));
        if ($discount < 0) {
            $discount = 0;
        }

        $items = [];

        if ($type === 'prescription') {
            $prescriptionId = (int) $this->request->getPost('prescription_id');
            $prescription   = $this->prescriptionModel->find($prescriptionId);

            if (! $prescription || ! in_array($prescription['status'], ['prepared', 'completed'], true)) {
                return redirect()->back()->with('error', 'Resep tidak valid atau belum siap dibayar.');
            }

            if ($this->transactionModel->isPrescriptionPaid($prescriptionId)) {
                return redirect()->back()->with('error', 'Resep tersebut sudah pernah dibayar.');
            }

            foreach ($this->rxItemModel->getWithDrug($prescriptionId) as $rxItem) {
                $price = (float) $rxItem['sell_price'];
                $qty   = (float) $rxItem['quantity'];
                $items[] = [
                    'drug_id'    => (int) $rxItem['drug_id'],
                    'quantity'   => $qty,
                    'unit_price' => $price,
                    'subtotal'   => $qty * $price,
                ];
            }

            $patientId = (int) $prescription['patient_id'];
        } else {
            $patientId = (int) ($this->request->getPost('patient_id') ?: 0) ?: null;
            $drugIds   = (array) ($this->request->getPost('item_drug_id') ?? []);
            $qtys      = (array) ($this->request->getPost('item_qty') ?? []);
            $prices    = (array) ($this->request->getPost('item_price') ?? []);

            if ($drugIds === []) {
                return redirect()->back()->withInput()->with('error', 'Minimal harus ada satu item penjualan.');
            }

            foreach ($drugIds as $i => $drugId) {
                $drugId = (int) $drugId;
                $qty    = (float) str_replace(',', '.', (string) ($qtys[$i] ?? 0));
                $price  = (float) str_replace(',', '.', (string) ($prices[$i] ?? 0));

                if ($drugId <= 0 || $qty <= 0) {
                    return redirect()->back()->withInput()->with('error', 'Setiap item harus memiliki obat dan jumlah lebih besar dari 0.');
                }

                if (! $this->drugModel->find($drugId)) {
                    return redirect()->back()->withInput()->with('error', 'Obat pada item ke-' . ($i + 1) . ' tidak ditemukan.');
                }

                $items[] = [
                    'drug_id'    => $drugId,
                    'quantity'   => $qty,
                    'unit_price' => $price,
                    'subtotal'   => $qty * $price,
                ];
            }
        }

        if ($items === []) {
            return redirect()->back()->with('error', 'Transaksi tidak memiliki item.');
        }

        $total = 0.0;
        foreach ($items as $item) {
            $total += $item['subtotal'];
        }
        $grandTotal = max(0, $total - $discount);

        $db = db_connect();
        $db->transBegin();

        $trxId = $this->transactionModel->insert([
            'transaction_number' => $this->transactionModel->generateNumber(),
            'prescription_id'    => $type === 'prescription' ? (int) $this->request->getPost('prescription_id') : null,
            'patient_id'         => $patientId,
            'user_id'            => (int) session()->get('userId'),
            'type'               => $type,
            'status'             => 'pending',
            'total_amount'       => $total,
            'discount'           => $discount,
            'grand_total'        => $grandTotal,
            'note'               => $this->request->getPost('note'),
        ], true);

        if ($trxId === false) {
            $db->transRollback();

            return redirect()->back()->with('error', 'Gagal menyimpan transaksi: ' . implode(', ', $this->transactionModel->errors()));
        }

        foreach ($items as $item) {
            $item['transaction_id'] = $trxId;
            $itemId = $this->itemModel->insert($item);

            if ($itemId === false) {
                $db->transRollback();

                return redirect()->back()->with('error', 'Gagal menyimpan item transaksi: ' . implode(', ', $this->itemModel->errors()));
            }
        }

        $db->transCommit();

        $this->auditLog->log(
            (int) session()->get('userId'),
            'create',
            'transactions',
            $trxId,
            'Buat transaksi: ' . $this->transactionModel->find($trxId)['transaction_number']
        );

        return redirect()->to('/transactions/' . $trxId)->with('success', 'Transaksi dibuat. Silakan proses pembayaran.');
    }

    public function show(int $id)
    {
        $trx = $this->transactionModel->find($id);
        if (! $trx) {
            return redirect()->to('/transactions')->with('error', 'Transaksi tidak ditemukan.');
        }

        $patient = $trx['patient_id'] ? $this->patientModel->find($trx['patient_id']) : null;
        $items   = $this->itemModel->getWithDrug($id);
        $cashier = $trx['user_id'] ? db_connect()->table('users')->where('id', $trx['user_id'])->get()->getRowArray() : null;

        return view('transactions/show', [
            'title'   => 'Detail Transaksi - PharmaCare',
            'trx'     => $trx,
            'patient' => $patient,
            'items'   => $items,
            'cashier' => $cashier,
        ]);
    }

    public function pay(int $id)
    {
        $trx = $this->transactionModel->find($id);
        if (! $trx) {
            return redirect()->to('/transactions')->with('error', 'Transaksi tidak ditemukan.');
        }

        if ($trx['status'] !== 'pending') {
            return redirect()->to('/transactions/' . $id)->with('error', 'Hanya transaksi berstatus menunggu yang dapat dibayar.');
        }

        $rules = [
            'payment_method' => 'required|in_list[cash,debit,qris,transfer]',
            'paid_amount'    => 'required|numeric|greater_than_equal_to[0]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $paid       = (float) str_replace(',', '.', (string) $this->request->getPost('paid_amount'));
        $grandTotal = (float) $trx['grand_total'];

        if ($paid < $grandTotal) {
            return redirect()->back()->withInput()->with('error', 'Jumlah bayar kurang. Total yang harus dibayar: Rp ' . number_format($grandTotal, 0, ',', '.') . '.');
        }

        $change    = $paid - $grandTotal;
        $items     = $this->itemModel->getWithDrug($id);
        $db        = db_connect();
        $userId    = (int) session()->get('userId');
        $failures  = [];

        $db->transBegin();

        // Penjualan OTC: potong stok. Resep: stok sudah dipotong saat penyiapan obat.
        if ($trx['type'] === 'otc') {
            foreach ($items as $item) {
                $result = $this->stockMovement->record(
                    (int) $item['drug_id'],
                    'out',
                    (float) $item['quantity'],
                    $userId,
                    'Penjualan ' . $trx['transaction_number']
                );

                if (! $result['success']) {
                    $failures[] = $item['drug_name'] . ': ' . $result['message'];
                }
            }
        }

        if ($failures !== []) {
            $db->transRollback();

            return redirect()->to('/transactions/' . $id)->with('error', 'Pembayaran gagal — stok tidak mencukupi: ' . implode('; ', $failures));
        }

        $updated = $this->transactionModel->update($id, [
            'status'        => 'paid',
            'payment_method' => $this->request->getPost('payment_method'),
            'paid_amount'   => $paid,
            'change_amount' => $change,
            'paid_at'       => date('Y-m-d H:i:s'),
        ]);

        if ($updated === false) {
            $db->transRollback();

            return redirect()->to('/transactions/' . $id)->with('error', 'Gagal memperbarui transaksi.');
        }

        $db->transCommit();

        $this->auditLog->log($userId, 'pay', 'transactions', $id, 'Bayar transaksi: ' . $trx['transaction_number'] . ' (Rp ' . number_format($grandTotal, 0, ',', '.') . ')');

        return redirect()->to('/transactions/' . $id)->with('success', 'Pembayaran berhasil. Kembalian: Rp ' . number_format($change, 0, ',', '.') . '.');
    }

    public function cancel(int $id)
    {
        $trx = $this->transactionModel->find($id);
        if (! $trx) {
            return redirect()->to('/transactions')->with('error', 'Transaksi tidak ditemukan.');
        }

        if ($trx['status'] !== 'pending') {
            return redirect()->to('/transactions/' . $id)->with('error', 'Hanya transaksi berstatus menunggu yang dapat dibatalkan. Transaksi lunas tidak dapat dibatalkan.');
        }

        $this->transactionModel->update($id, [
            'status'       => 'cancelled',
            'cancelled_at' => date('Y-m-d H:i:s'),
        ]);

        $this->auditLog->log((int) session()->get('userId'), 'cancel', 'transactions', $id, 'Batalkan transaksi: ' . $trx['transaction_number']);

        return redirect()->to('/transactions/' . $id)->with('success', 'Transaksi berhasil dibatalkan.');
    }

    public function receipt(int $id)
    {
        $trx = $this->transactionModel->find($id);
        if (! $trx) {
            return redirect()->to('/transactions')->with('error', 'Transaksi tidak ditemukan.');
        }

        if ($trx['status'] !== 'paid') {
            return redirect()->to('/transactions/' . $id)->with('error', 'Struk hanya tersedia untuk transaksi yang sudah dibayar.');
        }

        $patient = $trx['patient_id'] ? $this->patientModel->find($trx['patient_id']) : null;
        $items   = $this->itemModel->getWithDrug($id);

        return view('transactions/receipt', [
            'trx'     => $trx,
            'patient' => $patient,
            'items'   => $items,
        ]);
    }
}
