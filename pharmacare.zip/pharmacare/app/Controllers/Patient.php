<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\PatientModel;

class Patient extends BaseController
{
    protected PatientModel $patientModel;
    protected AuditLogModel $auditLog;

    public function __construct()
    {
        $this->patientModel = new PatientModel();
        $this->auditLog     = new AuditLogModel();
    }

    public function index()
    {
        $search = $this->request->getGet('q');

        return view('patients/index', [
            'title'    => 'Data Pasien - PharmaCare',
            'patients' => $this->patientModel->search($search),
            'pager'    => $this->patientModel->pager,
            'search'   => $search,
        ]);
    }

    public function create()
    {
        return view('patients/form', [
            'title'   => 'Tambah Pasien - PharmaCare',
            'patient' => null,
            'rm'      => $this->patientModel->generateRmNumber(),
        ]);
    }

    public function store()
    {
        $rules = [
            'rm_number'  => 'required|max_length[20]',
            'name'       => 'required|max_length[150]',
            'gender'     => 'required|in_list[L,P]',
            'birth_date' => 'permit_empty|valid_date',
            'phone'      => 'permit_empty|max_length[20]',
            'address'    => 'permit_empty',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $id = $this->patientModel->insert([
            'rm_number'  => strtoupper(trim($this->request->getPost('rm_number'))),
            'name'       => trim($this->request->getPost('name')),
            'gender'     => $this->request->getPost('gender'),
            'birth_date' => $this->request->getPost('birth_date') ?: null,
            'phone'      => $this->request->getPost('phone'),
            'address'    => $this->request->getPost('address'),
        ]);

        if ($id === false) {
            return redirect()->back()->withInput()->with('error', 'Gagal menyimpan pasien: ' . implode(', ', $this->patientModel->errors()));
        }

        $this->auditLog->log((int) session()->get('userId'), 'create', 'patients', $id, 'Tambah pasien: ' . $this->request->getPost('name'));

        return redirect()->to('/patients')->with('success', 'Pasien berhasil ditambahkan.');
    }

    public function edit(int $id)
    {
        $patient = $this->patientModel->find($id);
        if (! $patient) {
            return redirect()->to('/patients')->with('error', 'Pasien tidak ditemukan.');
        }

        return view('patients/form', [
            'title'   => 'Edit Pasien - PharmaCare',
            'patient' => $patient,
            'rm'      => $patient['rm_number'],
        ]);
    }

    public function update(int $id)
    {
        $patient = $this->patientModel->find($id);
        if (! $patient) {
            return redirect()->to('/patients')->with('error', 'Pasien tidak ditemukan.');
        }

        $rules = [
            'rm_number'  => 'required|max_length[20]',
            'name'       => 'required|max_length[150]',
            'gender'     => 'required|in_list[L,P]',
            'birth_date' => 'permit_empty|valid_date',
            'phone'      => 'permit_empty|max_length[20]',
            'address'    => 'permit_empty',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $updated = $this->patientModel->update($id, [
            'rm_number'  => strtoupper(trim($this->request->getPost('rm_number'))),
            'name'       => trim($this->request->getPost('name')),
            'gender'     => $this->request->getPost('gender'),
            'birth_date' => $this->request->getPost('birth_date') ?: null,
            'phone'      => $this->request->getPost('phone'),
            'address'    => $this->request->getPost('address'),
        ]);

        if ($updated === false) {
            return redirect()->back()->withInput()->with('error', 'Gagal memperbarui pasien: ' . implode(', ', $this->patientModel->errors()));
        }

        $this->auditLog->log((int) session()->get('userId'), 'update', 'patients', $id, 'Edit pasien: ' . $this->request->getPost('name'));

        return redirect()->to('/patients')->with('success', 'Data pasien berhasil diperbarui.');
    }

    public function delete(int $id)
    {
        $patient = $this->patientModel->find($id);
        if (! $patient) {
            return redirect()->to('/patients')->with('error', 'Pasien tidak ditemukan.');
        }

        $rxCount = (int) db_connect()->table('prescriptions')->where('patient_id', $id)->countAllResults();
        if ($rxCount > 0) {
            return redirect()->to('/patients')->with('error', 'Pasien tidak dapat dihapus karena memiliki ' . $rxCount . ' riwayat resep.');
        }

        $this->patientModel->delete($id);
        $this->auditLog->log((int) session()->get('userId'), 'delete', 'patients', $id, 'Hapus pasien: ' . $patient['name']);

        return redirect()->to('/patients')->with('success', 'Pasien berhasil dihapus.');
    }
}
