<?php

namespace App\Controllers;

use App\Models\DrugBatchModel;
use App\Models\PrescriptionModel;
use App\Models\QueueModel;
use App\Models\TransactionModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $db = db_connect();
        $today = date('Y-m-d');

        $activeDrugs = $db->table('drugs')
            ->select('name, unit, current_stock, min_stock')
            ->where('deleted_at', null)
            ->where('is_active', 1)
            ->get()
            ->getResultArray();

        $totalDrugs = count($activeDrugs);

        $lowStockAll  = array_values(array_filter(
            $activeDrugs,
            static fn (array $d): bool => (float) $d['current_stock'] <= (float) $d['min_stock']
        ));
        $lowStockCount = count($lowStockAll);
        $lowStockList  = array_slice($lowStockAll, 0, 5);

        $expiringList = (new DrugBatchModel())
            ->select('drug_batches.*, drugs.name AS drug_name, drugs.unit')
            ->join('drugs', 'drugs.id = drug_batches.drug_id', 'left')
            ->where('drug_batches.remaining_qty >', 0)
            ->where('drug_batches.expiry_date <=', date('Y-m-d', strtotime('+30 days')))
            ->orderBy('drug_batches.expiry_date', 'ASC')
            ->limit(5)
            ->findAll();
        $expiringCount = (int) $db->table('drug_batches')
            ->where('remaining_qty >', 0)
            ->where('expiry_date <=', date('Y-m-d', strtotime('+30 days')))
            ->countAllResults();
        $expiredCount = (int) $db->table('drug_batches')
            ->where('remaining_qty >', 0)
            ->where('expiry_date <', $today)
            ->countAllResults();

        $trxDashboard = (new TransactionModel())
            ->where('created_at >=', $today . ' 00:00:00')
            ->where('created_at <=', $today . ' 23:59:59')
            ->where('status', 'paid')
            ->findAll();
        $trxCount    = count($trxDashboard);
        $trxRevenue  = array_sum(array_column($trxDashboard, 'grand_total'));

        $rxToday = (new PrescriptionModel())
            ->where('created_at >=', $today . ' 00:00:00')
            ->where('created_at <=', $today . ' 23:59:59')
            ->countAllResults();

        $queueLive   = (new QueueModel())->getLiveStatus();
        $queueActive = (int) $db->table('queues')
            ->where('queue_date', $today)
            ->whereIn('status', ['waiting', 'processing', 'ready', 'called'])
            ->countAllResults();

        $recentTransactions = (new TransactionModel())
            ->select('transactions.*, patients.name AS patient_name, users.name AS cashier_name')
            ->join('patients', 'patients.id = transactions.patient_id', 'left')
            ->join('users', 'users.id = transactions.user_id', 'left')
            ->orderBy('transactions.id', 'DESC')
            ->limit(5)
            ->findAll();

        return view('dashboard/index', [
            'title'              => 'Dashboard - PharmaCare',
            'userName'           => session()->get('userName'),
            'userRole'           => session()->get('userRoleLabel'),
            'totalDrugs'         => $totalDrugs,
            'lowStockCount'      => $lowStockCount,
            'lowStockList'       => $lowStockList,
            'expiringCount'      => $expiringCount,
            'expiringList'       => $expiringList,
            'expiredCount'       => $expiredCount,
            'trxCount'           => $trxCount,
            'trxRevenue'         => $trxRevenue,
            'rxToday'            => $rxToday,
            'queueActive'        => $queueActive,
            'queueDoneToday'     => (int) $queueLive['done_today'],
            'recentTransactions' => $recentTransactions,
        ]);
    }
}
