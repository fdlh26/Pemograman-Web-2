<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\DrugModel;
use App\Models\StockMovementModel;

class Stock extends BaseController
{
    protected DrugModel $drugModel;
    protected StockMovementModel $stockMovement;
    protected AuditLogModel $auditLog;

    public function __construct()
    {
        $this->drugModel     = new DrugModel();
        $this->stockMovement = new StockMovementModel();
        $this->auditLog      = new AuditLogModel();
    }

    public function index()
    {
        $search = $this->request->getGet('q');

        $builder = $this->drugModel->select('drugs.*, categories.name AS category_name')
            ->join('categories', 'categories.id = drugs.category_id', 'left')
            ->where('drugs.is_active', 1);

        if ($search !== null && $search !== '') {
            $builder->groupStart()
                ->like('drugs.name', $search)
                ->orLike('drugs.code', $search)
                ->groupEnd();
        }

        $drugs = $builder->orderBy('drugs.name', 'ASC')->paginate(15, 'stock');

        return view('stock/index', [
            'title'     => 'Stok Obat - PharmaCare',
            'drugs'     => $drugs,
            'pager'     => $this->drugModel->pager,
            'search'    => $search,
            'drugModel' => $this->drugModel,
        ]);
    }

    public function movements()
    {
        $type = $this->request->getGet('type');
        $type = in_array($type, ['in', 'out', 'adjustment'], true) ? $type : null;

        return view('stock/movements', [
            'title'     => 'Riwayat Pergerakan Stok - PharmaCare',
            'movements' => $this->stockMovement->getWithDrug($type),
            'pager'     => $this->stockMovement->pager,
            'type'      => $type,
        ]);
    }

    public function form(string $type)
    {
        if (! in_array($type, ['in', 'out', 'adjustment'], true)) {
            return redirect()->to('/stock')->with('error', 'Jenis pergerakan tidak valid.');
        }

        $drugId = $this->request->getGet('drug_id');
        $drug   = $drugId !== null && $drugId !== '' ? $this->drugModel->find((int) $drugId) : null;

        return view('stock/form', [
            'title' => 'Stok ' . ($type === 'in' ? 'Masuk' : ($type === 'out' ? 'Keluar' : 'Penyesuaian')) . ' - PharmaCare',
            'type'  => $type,
            'drugs' => $this->drugModel->where('is_active', 1)->orderBy('name', 'ASC')->findAll(),
            'drug'  => $drug,
        ]);
    }

    public function store()
    {
        $type = (string) $this->request->getPost('type');
        if (! in_array($type, ['in', 'out', 'adjustment'], true)) {
            return redirect()->back()->with('error', 'Jenis pergerakan tidak valid.');
        }

        $rules = [
            'drug_id'  => 'required|integer',
            'quantity' => 'required|numeric|greater_than[0]',
            'note'     => 'permit_empty|max_length[255]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $drugId  = (int) $this->request->getPost('drug_id');
        $quantity = (float) str_replace(',', '.', (string) $this->request->getPost('quantity'));
        $note     = $this->request->getPost('note');

        $result = $this->stockMovement->record(
            $drugId,
            $type,
            $quantity,
            (int) session()->get('userId'),
            $note !== null && $note !== '' ? $note : null
        );

        if (! $result['success']) {
            return redirect()->back()->withInput()->with('error', $result['message']);
        }

        $drug      = $this->drugModel->find($drugId);
        $typeLabel = $type === 'in' ? 'masuk' : ($type === 'out' ? 'keluar' : 'penyesuaian');
        $this->auditLog->log(
            (int) session()->get('userId'),
            'stock_' . $type,
            'drugs',
            $drugId,
            'Stok ' . $typeLabel . ': ' . $drug['name'] . ' (' . number_format($quantity, 2) . ' ' . $drug['unit'] . ')'
        );

        return redirect()->to('/stock')->with('success', 'Stok ' . $typeLabel . ' berhasil dicatat. Stok sekarang: ' . number_format((float) $result['stock_after'], 2) . ' ' . $drug['unit'] . '.');
    }
}
