<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\SupplierModel;

class Supplier extends BaseController
{
    protected SupplierModel $supplierModel;
    protected AuditLogModel $auditLog;

    public function __construct()
    {
        $this->supplierModel = new SupplierModel();
        $this->auditLog      = new AuditLogModel();
    }

    public function index()
    {
        $search = $this->request->getGet('q');

        $builder = $this->supplierModel;
        if ($search !== null && $search !== '') {
            $builder = $builder->groupStart()
                ->like('name', $search)
                ->orLike('contact_person', $search)
                ->orLike('phone', $search)
                ->groupEnd();
        }

        return view('suppliers/index', [
            'title'     => 'Supplier - PharmaCare',
            'suppliers' => $builder->orderBy('name', 'ASC')->paginate(10, 'suppliers'),
            'pager'     => $this->supplierModel->pager,
            'search'    => $search,
        ]);
    }

    public function create()
    {
        return view('suppliers/form', [
            'title'    => 'Tambah Supplier - PharmaCare',
            'supplier' => null,
        ]);
    }

    public function store()
    {
        $rules = [
            'name'           => 'required|max_length[150]',
            'contact_person' => 'permit_empty|max_length[100]',
            'phone'          => 'permit_empty|max_length[20]',
            'email'          => 'permit_empty|valid_email|max_length[100]',
            'address'        => 'permit_empty',
            'is_active'      => 'permit_empty|in_list[0,1]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $id = $this->supplierModel->insert([
            'name'           => trim($this->request->getPost('name')),
            'contact_person' => $this->request->getPost('contact_person'),
            'phone'          => $this->request->getPost('phone'),
            'email'          => $this->request->getPost('email'),
            'address'        => $this->request->getPost('address'),
            'is_active'      => (int) ($this->request->getPost('is_active') ?? 1),
        ]);

        if ($id === false) {
            return redirect()->back()->withInput()->with('error', 'Gagal menyimpan supplier: ' . implode(', ', $this->supplierModel->errors()));
        }

        $this->auditLog->log((int) session()->get('userId'), 'create', 'suppliers', $id, 'Tambah supplier: ' . $this->request->getPost('name'));

        return redirect()->to('/suppliers')->with('success', 'Supplier berhasil ditambahkan.');
    }

    public function edit(int $id)
    {
        $supplier = $this->supplierModel->find($id);
        if (! $supplier) {
            return redirect()->to('/suppliers')->with('error', 'Supplier tidak ditemukan.');
        }

        return view('suppliers/form', [
            'title'    => 'Edit Supplier - PharmaCare',
            'supplier' => $supplier,
        ]);
    }

    public function update(int $id)
    {
        $supplier = $this->supplierModel->find($id);
        if (! $supplier) {
            return redirect()->to('/suppliers')->with('error', 'Supplier tidak ditemukan.');
        }

        $rules = [
            'name'           => 'required|max_length[150]',
            'contact_person' => 'permit_empty|max_length[100]',
            'phone'          => 'permit_empty|max_length[20]',
            'email'          => 'permit_empty|valid_email|max_length[100]',
            'address'        => 'permit_empty',
            'is_active'      => 'permit_empty|in_list[0,1]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $updated = $this->supplierModel->update($id, [
            'name'           => trim($this->request->getPost('name')),
            'contact_person' => $this->request->getPost('contact_person'),
            'phone'          => $this->request->getPost('phone'),
            'email'          => $this->request->getPost('email'),
            'address'        => $this->request->getPost('address'),
            'is_active'      => (int) ($this->request->getPost('is_active') ?? 1),
        ]);

        if ($updated === false) {
            return redirect()->back()->withInput()->with('error', 'Gagal memperbarui supplier: ' . implode(', ', $this->supplierModel->errors()));
        }

        $this->auditLog->log((int) session()->get('userId'), 'update', 'suppliers', $id, 'Edit supplier: ' . $this->request->getPost('name'));

        return redirect()->to('/suppliers')->with('success', 'Supplier berhasil diperbarui.');
    }

    public function delete(int $id)
    {
        $supplier = $this->supplierModel->find($id);
        if (! $supplier) {
            return redirect()->to('/suppliers')->with('error', 'Supplier tidak ditemukan.');
        }

        $poCount = (int) db_connect()->table('purchases')->where('supplier_id', $id)->countAllResults();
        if ($poCount > 0) {
            return redirect()->to('/suppliers')->with('error', 'Supplier tidak dapat dihapus karena memiliki ' . $poCount . ' riwayat pembelian.');
        }

        $this->supplierModel->delete($id);
        $this->auditLog->log((int) session()->get('userId'), 'delete', 'suppliers', $id, 'Hapus supplier: ' . $supplier['name']);

        return redirect()->to('/suppliers')->with('success', 'Supplier berhasil dihapus.');
    }
}
