<?php

namespace App\Controllers;

class Report extends BaseController
{
    private const TYPES = ['inventory', 'purchases', 'sales', 'usage', 'expiry', 'transactions'];

    public function index()
    {
        $type = (string) ($this->request->getGet('type') ?: 'inventory');
        if (! in_array($type, self::TYPES, true)) {
            $type = 'inventory';
        }

        $from = (string) $this->request->getGet('from');
        $to   = (string) $this->request->getGet('to');

        if (! preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
            $from = date('Y-m-01');
        }
        if (! preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
            $to = date('Y-m-t');
        }
        if ($from > $to) {
            [$from, $to] = [$to, $from];
        }

        $categoryId = (int) $this->request->getGet('category_id');

        $db = db_connect();

        $data = [
            'title'      => 'Laporan Farmasi - PharmaCare',
            'type'       => $type,
            'from'       => $from,
            'to'         => $to,
            'categoryId' => $categoryId,
            'categories' => $db->table('categories')->where('deleted_at', null)->orderBy('name')->get()->getResultArray(),
            'rows'       => [],
            'summary'    => [],
        ];

        switch ($type) {
            case 'purchases':
                $rows = $db->table('purchases')
                    ->select('purchases.*, suppliers.name AS supplier_name, users.name AS staff_name')
                    ->join('suppliers', 'suppliers.id = purchases.supplier_id', 'left')
                    ->join('users', 'users.id = purchases.user_id', 'left')
                    ->where('purchases.deleted_at', null)
                    ->where('order_date >=', $from)
                    ->where('order_date <=', $to)
                    ->orderBy('order_date', 'ASC')
                    ->get()->getResultArray();
                $data['rows'] = $rows;
                $data['summary'] = [
                    'Jumlah PO'      => count($rows),
                    'Total Nilai'    => 'Rp ' . number_format(array_sum(array_column($rows, 'total_amount')), 0, ',', '.'),
                    'Diterima'       => count(array_filter($rows, static fn ($r) => $r['status'] === 'received')),
                    'Dibatalkan'     => count(array_filter($rows, static fn ($r) => $r['status'] === 'cancelled')),
                ];
                break;

            case 'sales':
                $rows = $db->table('transactions')
                    ->select('transactions.*, patients.name AS patient_name, users.name AS cashier_name')
                    ->join('patients', 'patients.id = transactions.patient_id', 'left')
                    ->join('users', 'users.id = transactions.user_id', 'left')
                    ->where('transactions.deleted_at', null)
                    ->where('transactions.status', 'paid')
                    ->where('transactions.paid_at >=', $from . ' 00:00:00')
                    ->where('transactions.paid_at <=', $to . ' 23:59:59')
                    ->orderBy('transactions.paid_at', 'ASC')
                    ->get()->getResultArray();
                $byMethod = [];
                foreach ($rows as $r) {
                    $m = $r['payment_method'] ?? '-';
                    $byMethod[$m] = ($byMethod[$m] ?? 0) + (float) $r['grand_total'];
                }
                $data['rows'] = $rows;
                $data['summary'] = [
                    'Transaksi Lunas' => count($rows),
                    'Total Penjualan' => 'Rp ' . number_format(array_sum(array_column($rows, 'grand_total')), 0, ',', '.'),
                    'Diskon'          => 'Rp ' . number_format(array_sum(array_column($rows, 'discount')), 0, ',', '.'),
                    'Metode'          => $byMethod === [] ? '-' : implode(', ', array_keys($byMethod)),
                ];
                break;

            case 'usage':
                $q = $db->table('stock_movements')
                    ->select('drugs.name AS drug_name, drugs.code, drugs.unit, categories.name AS category_name,
                              SUM(stock_movements.quantity) AS total_qty, COUNT(*) AS times')
                    ->join('drugs', 'drugs.id = stock_movements.drug_id', 'left')
                    ->join('categories', 'categories.id = drugs.category_id', 'left')
                    ->where('stock_movements.type', 'out')
                    ->where('stock_movements.created_at >=', $from . ' 00:00:00')
                    ->where('stock_movements.created_at <=', $to . ' 23:59:59')
                    ->groupBy('stock_movements.drug_id')
                    ->orderBy('total_qty', 'DESC');
                if ($categoryId > 0) {
                    $q->where('drugs.category_id', $categoryId);
                }
                $rows = $q->get()->getResultArray();
                $data['rows'] = $rows;
                $data['summary'] = [
                    'Jenis Obat Keluar' => count($rows),
                    'Total Keluar'      => number_format(array_sum(array_column($rows, 'total_qty')), 2, ',', '.'),
                ];
                break;

            case 'expiry':
                $q = $db->table('drug_batches')
                    ->select('drug_batches.*, drugs.name AS drug_name, drugs.unit, categories.name AS category_name')
                    ->join('drugs', 'drugs.id = drug_batches.drug_id', 'left')
                    ->join('categories', 'categories.id = drugs.category_id', 'left')
                    ->where('drug_batches.expiry_date >=', $from)
                    ->where('drug_batches.expiry_date <=', $to)
                    ->where('drug_batches.remaining_qty >', 0)
                    ->orderBy('drug_batches.expiry_date', 'ASC');
                if ($categoryId > 0) {
                    $q = $q->where('drugs.category_id', $categoryId);
                }
                $rows = $q->get()->getResultArray();
                $now = date('Y-m-d');
                $data['rows'] = $rows;
                $data['summary'] = [
                    'Batch dalam Periode' => count($rows),
                    'Sudah Kedaluwarsa'   => count(array_filter($rows, static fn ($r) => $r['expiry_date'] < $now)),
                    'Total Sisa Stok'     => number_format(array_sum(array_column($rows, 'remaining_qty')), 2, ',', '.'),
                ];
                break;

            case 'transactions':
                $rows = $db->table('transactions')
                    ->select('transactions.*, patients.name AS patient_name, prescriptions.prescription_number, users.name AS staff_name')
                    ->join('patients', 'patients.id = transactions.patient_id', 'left')
                    ->join('prescriptions', 'prescriptions.id = transactions.prescription_id', 'left')
                    ->join('users', 'users.id = transactions.user_id', 'left')
                    ->where('transactions.deleted_at', null)
                    ->where('transactions.created_at >=', $from . ' 00:00:00')
                    ->where('transactions.created_at <=', $to . ' 23:59:59')
                    ->orderBy('transactions.created_at', 'ASC')
                    ->get()->getResultArray();
                $data['rows'] = $rows;
                $data['summary'] = [
                    'Total Transaksi'  => count($rows),
                    'Lunas'            => count(array_filter($rows, static fn ($r) => $r['status'] === 'paid')),
                    'Menunggu/Batal'   => count(array_filter($rows, static fn ($r) => $r['status'] !== 'paid')),
                    'Nilai Lunas'      => 'Rp ' . number_format(
                        array_sum(array_map(static fn ($r) => $r['status'] === 'paid' ? (float) $r['grand_total'] : 0.0, $rows)),
                        0, ',', '.'
                    ),
                ];
                break;

            default: // inventory
                $q = $db->table('drugs')
                    ->select('drugs.*, categories.name AS category_name')
                    ->join('categories', 'categories.id = drugs.category_id', 'left')
                    ->where('drugs.deleted_at', null)
                    ->orderBy('drugs.name', 'ASC');
                if ($categoryId > 0) {
                    $q->where('drugs.category_id', $categoryId);
                }
                $rows = $q->get()->getResultArray();
                $menipis  = array_filter($rows, static fn ($r) => (float) $r['current_stock'] <= (float) $r['min_stock'] && (float) $r['current_stock'] > 0);
                $habis    = array_filter($rows, static fn ($r) => (float) $r['current_stock'] <= 0);
                $data['rows'] = $rows;
                $data['summary'] = [
                    'Jenis Obat'          => count($rows),
                    'Nilai Persediaan'    => 'Rp ' . number_format(
                        array_sum(array_map(static fn ($r) => (float) $r['current_stock'] * (float) $r['buy_price'], $rows)),
                        0, ',', '.'
                    ),
                    'Stok Menipis'        => count($menipis),
                    'Stok Habis'          => count($habis),
                ];
                break;
        }

        return view('reports/index', $data);
    }
}
