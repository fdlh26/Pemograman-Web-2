<?php

namespace App\Controllers;

use App\Models\AuditLogModel;

class Audit extends BaseController
{
    public function index()
    {
        $auditLog = new AuditLogModel();

        $action = trim((string) $this->request->getGet('action'));
        $userId = (int) $this->request->getGet('user_id');
        $from   = (string) $this->request->getGet('from');
        $to     = (string) $this->request->getGet('to');
        $q      = trim((string) $this->request->getGet('q'));

        if (! preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
            $from = date('Y-m-01');
        }
        if (! preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
            $to = date('Y-m-t');
        }
        if ($from > $to) {
            [$from, $to] = [$to, $from];
        }

        $builder = $auditLog
            ->select('audit_logs.*, users.name AS user_name, users.email AS user_email')
            ->join('users', 'users.id = audit_logs.user_id', 'left')
            ->where('audit_logs.created_at >=', $from . ' 00:00:00')
            ->where('audit_logs.created_at <=', $to . ' 23:59:59');

        if ($action !== '') {
            $builder->where('audit_logs.action', $action);
        }
        if ($userId > 0) {
            $builder->where('audit_logs.user_id', $userId);
        }
        if ($q !== '') {
            $builder->groupStart()
                ->like('audit_logs.description', $q)
                ->orLike('audit_logs.table_name', $q)
                ->groupEnd();
        }

        $logs = $builder->orderBy('audit_logs.id', 'DESC')->paginate(25, 'audit');

        $actions = db_connect()->table('audit_logs')
            ->select('action')
            ->groupBy('action')
            ->orderBy('action')
            ->get()
            ->getResultArray();

        return view('audit/index', [
            'title'   => 'Riwayat Aktivitas - PharmaCare',
            'logs'    => $logs,
            'pager'   => $auditLog->pager,
            'actions' => array_column($actions, 'action'),
            'users'   => db_connect()->table('users')
                ->select('id, name')
                ->where('deleted_at', null)
                ->orderBy('name')
                ->get()
                ->getResultArray(),
            'filters' => [
                'action' => $action,
                'user_id' => $userId,
                'from'   => $from,
                'to'     => $to,
                'q'      => $q,
            ],
        ]);
    }
}
