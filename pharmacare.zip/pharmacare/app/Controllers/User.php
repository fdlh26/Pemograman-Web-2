<?php

namespace App\Controllers;

use App\Models\AuditLogModel;
use App\Models\RoleModel;
use App\Models\UserModel;

class User extends BaseController
{
    protected UserModel $userModel;
    protected RoleModel $roleModel;
    protected AuditLogModel $auditLog;

    public function __construct()
    {
        $this->userModel  = new UserModel();
        $this->roleModel  = new RoleModel();
        $this->auditLog   = new AuditLogModel();
    }

    public function index()
    {
        $keyword = trim((string) $this->request->getGet('q'));
        $roleId  = (int) $this->request->getGet('role_id');

        $builder = $this->userModel
            ->select('users.*, roles.name AS role_name, roles.description AS role_description')
            ->join('roles', 'roles.id = users.role_id', 'left')
            ->where('users.deleted_at', null);

        if ($keyword !== '') {
            $builder->groupStart()
                ->like('users.username', $keyword)
                ->orLike('users.name', $keyword)
                ->orLike('users.email', $keyword)
                ->groupEnd();
        }
        if ($roleId > 0) {
            $builder->where('users.role_id', $roleId);
        }

        $users = $builder->orderBy('users.name', 'ASC')->paginate(15, 'users');

        return view('users/index', [
            'title'   => 'Manajemen Pengguna - PharmaCare',
            'users'   => $users,
            'pager'   => $this->userModel->pager,
            'roles'   => $this->roleModel->orderBy('id')->findAll(),
            'keyword' => $keyword,
            'roleId'  => $roleId,
        ]);
    }

    public function create()
    {
        return view('users/form', [
            'title' => 'Tambah Pengguna - PharmaCare',
            'user'  => null,
            'roles' => $this->roleModel->orderBy('id')->findAll(),
        ]);
    }

    public function store()
    {
        $data = [
            'username'  => strtolower(trim((string) $this->request->getPost('username'))),
            'name'      => trim((string) $this->request->getPost('name')),
            'email'     => strtolower(trim((string) $this->request->getPost('email'))),
            'phone'     => trim((string) $this->request->getPost('phone')),
            'role_id'   => (int) $this->request->getPost('role_id'),
            'password'  => (string) $this->request->getPost('password'),
            'is_active' => $this->request->getPost('is_active') ? 1 : 0,
        ];

        if (! $this->roleModel->find($data['role_id'])) {
            return redirect()->back()->with('error', 'Role tidak valid.')->withInput();
        }

        $id = $this->userModel->insert($data, true);
        if ($id === false) {
            return redirect()->back()->with('error', 'Gagal menyimpan: ' . implode('; ', $this->userModel->errors()))->withInput();
        }

        $user = $this->userModel->find($id);
        $this->auditLog->log(
            (int) session()->get('userId'),
            'create',
            'users',
            $id,
            'Buat pengguna: ' . $user['name'] . ' (' . $user['email'] . ')'
        );

        return redirect()->to('/users')->with('success', 'Pengguna "' . $user['name'] . '" berhasil dibuat.');
    }

    public function edit(int $id)
    {
        $user = $this->userModel->find($id);
        if (! $user) {
            return redirect()->to('/users')->with('error', 'Pengguna tidak ditemukan.');
        }

        return view('users/form', [
            'title' => 'Edit Pengguna - PharmaCare',
            'user'  => $user,
            'roles' => $this->roleModel->orderBy('id')->findAll(),
        ]);
    }

    public function update(int $id)
    {
        $user = $this->userModel->find($id);
        if (! $user) {
            return redirect()->to('/users')->with('error', 'Pengguna tidak ditemukan.');
        }

        $roleId = (int) $this->request->getPost('role_id');
        if (! $this->roleModel->find($roleId)) {
            return redirect()->back()->with('error', 'Role tidak valid.')->withInput();
        }

        // Sertakan id agar placeholder {id} pada rule is_unique terganti saat update
        $data = [
            'id'        => $id,
            'username'  => strtolower(trim((string) $this->request->getPost('username'))),
            'name'      => trim((string) $this->request->getPost('name')),
            'email'     => strtolower(trim((string) $this->request->getPost('email'))),
            'phone'     => trim((string) $this->request->getPost('phone')),
            'role_id'   => $roleId,
            'is_active' => $this->request->getPost('is_active') ? 1 : 0,
        ];

        // Nonaktifkan akun terakhir harus dicegah
        if ($user['is_active'] === 1 && $data['is_active'] === 0) {
            if ($this->isLastActiveAdmin($id)) {
                return redirect()->back()->with('error', 'Tidak dapat menonaktifkan akun admin aktif terakhir.');
            }
        }

        $newPassword = (string) $this->request->getPost('password');
        if ($newPassword !== '') {
            $data['password'] = $newPassword;
        }

        $updated = $this->userModel->update($id, $data);
        if ($updated === false) {
            return redirect()->back()->with('error', 'Gagal memperbarui: ' . implode('; ', $this->userModel->errors()))->withInput();
        }

        $this->auditLog->log(
            (int) session()->get('userId'),
            'update',
            'users',
            $id,
            'Ubah pengguna: ' . $data['email'] . ($newPassword !== '' ? ' (password direset)' : '') . ($data['is_active'] === 0 ? ' (dinonaktifkan)' : '')
        );

        return redirect()->to('/users')->with('success', 'Pengguna "' . $data['name'] . '" berhasil diperbarui.');
    }

    public function toggle(int $id)
    {
        $user = $this->userModel->find($id);
        if (! $user) {
            return redirect()->to('/users')->with('error', 'Pengguna tidak ditemukan.');
        }

        if ($id === (int) session()->get('userId')) {
            return redirect()->to('/users')->with('error', 'Anda tidak dapat menonaktifkan akun sendiri.');
        }

        if ((int) $user['is_active'] === 1 && $this->isLastActiveAdmin($id)) {
            return redirect()->to('/users')->with('error', 'Tidak dapat menonaktifkan akun admin aktif terakhir.');
        }

        $newStatus = (int) $user['is_active'] === 1 ? 0 : 1;
        $this->userModel->update($id, ['is_active' => $newStatus]);

        $label = $newStatus === 1 ? 'diaktifkan' : 'dinonaktifkan';
        $this->auditLog->log((int) session()->get('userId'), 'toggle_user', 'users', $id, 'Pengguna ' . $user['email'] . ' ' . $label);

        return redirect()->to('/users')->with('success', 'Pengguna "' . $user['name'] . '" telah ' . $label . '.');
    }

    public function delete(int $id)
    {
        $user = $this->userModel->find($id);
        if (! $user) {
            return redirect()->to('/users')->with('error', 'Pengguna tidak ditemukan.');
        }

        if ($id === (int) session()->get('userId')) {
            return redirect()->to('/users')->with('error', 'Anda tidak dapat menghapus akun sendiri.');
        }

        if ($this->isLastActiveAdmin($id)) {
            return redirect()->to('/users')->with('error', 'Tidak dapat menghapus akun admin aktif terakhir.');
        }

        $this->userModel->update($id, [
            'username'  => 'deleted-' . $id,
            'email'     => 'deleted-' . $id . '@removed.local',
            'is_active' => 0,
        ]);
        $this->userModel->delete($id);

        $this->auditLog->log((int) session()->get('userId'), 'delete', 'users', $id, 'Hapus pengguna: ' . $user['name'] . ' (' . $user['email'] . ')');

        return redirect()->to('/users')->with('success', 'Pengguna "' . $user['name'] . '" berhasil dihapus.');
    }

    private function isLastActiveAdmin(int $exceptId): bool
    {
        $adminRoleId = $this->roleModel->where('name', 'admin')->first()['id'] ?? 0;
        if ($adminRoleId === 0) {
            return false;
        }

        return $this->userModel
            ->where('role_id', $adminRoleId)
            ->where('is_active', 1)
            ->where('deleted_at', null)
            ->where('id !=', $exceptId)
            ->countAllResults() === 0;
    }
}
