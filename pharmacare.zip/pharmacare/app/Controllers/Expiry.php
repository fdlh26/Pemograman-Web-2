<?php

namespace App\Controllers;

use App\Models\DrugBatchModel;

class Expiry extends BaseController
{
    protected DrugBatchModel $batchModel;

    public function __construct()
    {
        $this->batchModel = new DrugBatchModel();
    }

    public function index()
    {
        $status = $this->request->getGet('status');
        $status = in_array($status, ['expired', 'critical', 'warning'], true) ? $status : null;

        return view('expiry/index', [
            'title'      => 'Monitoring Kedaluwarsa - PharmaCare',
            'batches'    => $this->batchModel->getExpiring(30, $status),
            'pager'      => $this->batchModel->pager,
            'status'     => $status,
            'batchModel' => $this->batchModel,
        ]);
    }
}
