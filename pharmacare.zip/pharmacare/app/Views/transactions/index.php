<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-receipt-cutoff page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Penjualan</h1>
        <p class="text-muted mb-0">Transaksi penjualan obat dan pembayaran pasien</p>
    </div>
    <?php if (in_array(session()->get('userRole'), ['admin', 'kasir'], true)): ?>
        <a href="<?= base_url('transactions/create') ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Transaksi Baru
        </a>
    <?php endif; ?>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= base_url('transactions') ?>" method="get" class="row g-2 mb-3">
            <div class="col-md-3">
                <select class="form-select" name="status">
                    <option value="">Semua Status</option>
                    <option value="pending" <?= ($status ?? '') === 'pending' ? 'selected' : '' ?>>Menunggu Bayar</option>
                    <option value="paid" <?= ($status ?? '') === 'paid' ? 'selected' : '' ?>>Lunas</option>
                    <option value="cancelled" <?= ($status ?? '') === 'cancelled' ? 'selected' : '' ?>>Dibatalkan</option>
                </select>
            </div>
            <div class="col-md-4">
                <input type="text" class="form-control" name="q" placeholder="Cari no. TRX / pasien / resep..." value="<?= esc($search ?? '') ?>">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-funnel"></i> Filter</button>
                <?php if (! empty($search) || ! empty($status)): ?>
                    <a href="<?= base_url('transactions') ?>" class="btn btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="50">No</th>
                        <th>No. TRX</th>
                        <th>Waktu</th>
                        <th>Jenis</th>
                        <th>Pasien</th>
                        <th>Kasir</th>
                        <th class="text-end">Grand Total</th>
                        <th class="text-center">Status</th>
                        <th width="90">Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($transactions)): ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted py-4">Belum ada transaksi. Klik "Transaksi Baru" untuk memulai penjualan.</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = ($pager->getCurrentPage('transactions') - 1) * $pager->getPerPage('transactions') + 1; ?>
                        <?php foreach ($transactions as $trx): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><code><?= esc($trx['transaction_number']) ?></code></td>
                                <td class="text-muted"><?= date('d/m/Y H:i', strtotime($trx['created_at'])) ?></td>
                                <td>
                                    <?php if ($trx['type'] === 'prescription'): ?>
                                        <span class="badge bg-info text-dark">Resep</span>
                                        <div class="small text-muted"><?= esc($trx['prescription_number'] ?? '') ?></div>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">OTC</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= esc($trx['patient_name'] ?? '-') ?></td>
                                <td><?= esc($trx['cashier_name'] ?? '-') ?></td>
                                <td class="text-end">Rp <?= number_format((float) $trx['grand_total'], 0, ',', '.') ?></td>
                                <td class="text-center">
                                    <?php if ($trx['status'] === 'pending'): ?>
                                        <span class="badge bg-warning text-dark">Menunggu</span>
                                    <?php elseif ($trx['status'] === 'paid'): ?>
                                        <span class="badge bg-success">Lunas</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Dibatalkan</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?= base_url('transactions/' . $trx['id']) ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye" title="Lihat detail"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= $pager->links('transactions') ?>
    </div>
</div>
<?= $this->endSection() ?>
