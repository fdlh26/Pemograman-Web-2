<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Struk <?= esc($trx['transaction_number']) ?></title>
    <style>
        body {
            font-family: 'Courier New', monospace;
            font-size: 13px;
            max-width: 320px;
            margin: 20px auto;
            color: #000;
        }
        .center { text-align: center; }
        .bold { font-weight: bold; }
        hr { border: none; border-top: 1px dashed #000; margin: 8px 0; }
        table { width: 100%; border-collapse: collapse; }
        td { padding: 1px 0; vertical-align: top; }
        .right { text-align: right; }
        .no-print { text-align: center; margin-top: 16px; }
        @media print {
            .no-print { display: none; }
            body { margin: 0; }
        }
    </style>
</head>
<body>
    <div class="center bold">PHARMACARE</div>
    <div class="center">Sistem Manajemen Apotek</div>
    <hr>
    <table>
        <tr><td>No.</td><td class="right"><?= esc($trx['transaction_number']) ?></td></tr>
        <tr><td>Tanggal</td><td class="right"><?= date('d/m/Y H:i', strtotime($trx['paid_at'] ?? $trx['created_at'])) ?></td></tr>
        <?php if ($patient): ?>
            <tr><td>Pasien</td><td class="right"><?= esc($patient['name']) ?></td></tr>
        <?php endif; ?>
        <tr><td>Jenis</td><td class="right"><?= $trx['type'] === 'prescription' ? 'Resep' : 'OTC' ?></td></tr>
    </table>
    <hr>
    <table>
        <?php foreach ($items as $item): ?>
            <tr>
                <td colspan="2"><?= esc($item['drug_name']) ?></td>
            </tr>
            <tr>
                <td><?= number_format((float) $item['quantity'], 0) ?> x Rp <?= number_format((float) $item['unit_price'], 0, ',', '.') ?></td>
                <td class="right">Rp <?= number_format((float) $item['subtotal'], 0, ',', '.') ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <hr>
    <table>
        <tr><td>Subtotal</td><td class="right">Rp <?= number_format((float) $trx['total_amount'], 0, ',', '.') ?></td></tr>
        <?php if ((float) $trx['discount'] > 0): ?>
            <tr><td>Diskon</td><td class="right">- Rp <?= number_format((float) $trx['discount'], 0, ',', '.') ?></td></tr>
        <?php endif; ?>
        <tr class="bold"><td>TOTAL</td><td class="right bold">Rp <?= number_format((float) $trx['grand_total'], 0, ',', '.') ?></td></tr>
        <tr><td>Bayar (<?= esc($trx['payment_method']) ?>)</td><td class="right">Rp <?= number_format((float) $trx['paid_amount'], 0, ',', '.') ?></td></tr>
        <tr><td>Kembali</td><td class="right">Rp <?= number_format((float) $trx['change_amount'], 0, ',', '.') ?></td></tr>
    </table>
    <hr>
    <div class="center">Terima kasih atas kunjungan Anda</div>

    <div class="no-print">
        <button onclick="window.print()">Cetak</button>
        <a href="<?= base_url('transactions/' . $trx['id']) ?>">Kembali</a>
    </div>
</body>
</html>
