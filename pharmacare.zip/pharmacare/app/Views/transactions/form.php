<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-cart-plus page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Transaksi Baru</h1>
        <p class="text-muted mb-0">Penjualan bebas (OTC) atau pembayaran resep</p>
    </div>
    <a href="<?= base_url('transactions') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali
    </a>
</div>

<form action="<?= base_url('transactions/store') ?>" method="post" id="trxForm">
    <?= csrf_field() ?>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body p-4">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">No. Transaksi (otomatis)</label>
                    <input type="text" class="form-control" value="<?= esc($number) ?>" disabled>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Jenis Transaksi</label>
                    <select class="form-select" name="type" id="trxType">
                        <option value="otc" <?= empty($prescription) ? 'selected' : '' ?>>Penjualan Bebas (OTC)</option>
                        <option value="prescription" <?= ! empty($prescription) ? 'selected' : '' ?>>Pembayaran Resep</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="discount" class="form-label">Diskon (Rp)</label>
                    <input type="number" class="form-control" id="discount" name="discount" min="0" step="0.01"
                           value="<?= esc(old('discount', '0')) ?>">
                </div>
                <div class="col-md-12">
                    <label for="note" class="form-label">Catatan</label>
                    <input type="text" class="form-control" id="note" name="note" maxlength="255"
                           value="<?= esc(old('note', '')) ?>" placeholder="Opsional">
                </div>
            </div>
        </div>
    </div>

    <!-- OTC Items -->
    <div class="card border-0 shadow-sm mb-3" id="otcSection" <?= ! empty($prescription) ? 'style="display:none"' : '' ?>>
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <span class="fw-bold">Item Penjualan</span>
            <div class="d-flex gap-2 align-items-center">
                <select class="form-select form-select-sm" id="patientSelect" name="patient_id" style="width: 260px;">
                    <option value="">Pasien umum (opsional)</option>
                    <?php foreach ($patients as $patient): ?>
                        <option value="<?= $patient['id'] ?>"><?= esc($patient['name']) ?> (<?= esc($patient['rm_number']) ?>)</option>
                    <?php endforeach; ?>
                </select>
                <button type="button" class="btn btn-sm btn-outline-primary" id="addItem">
                    <i class="bi bi-plus-lg"></i> Tambah Item
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table align-middle" id="itemsTable">
                    <thead class="table-light">
                        <tr>
                            <th width="40">No</th>
                            <th style="min-width: 200px;">Obat <span class="text-danger">*</span></th>
                            <th width="100">Jumlah <span class="text-danger">*</span></th>
                            <th width="140">Harga <span class="text-danger">*</span></th>
                            <th width="110" class="text-end">Subtotal</th>
                            <th width="50"></th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Resep Items -->
    <div class="card border-0 shadow-sm mb-3" id="rxSection" <?= empty($prescription) ? 'style="display:none"' : '' ?>>
        <div class="card-header bg-white fw-bold">Item Resep</div>
        <div class="card-body">
            <?php if (! empty($prescription)): ?>
                <div class="mb-3">
                    <label for="prescription_id" class="form-label">Resep</label>
                    <select class="form-select" name="prescription_id" id="prescriptionSelect" required>
                        <?php foreach ($prescriptions as $rxOption): ?>
                            <option value="<?= $rxOption['id'] ?>" <?= (int) ($prescription['id'] ?? 0) === (int) $rxOption['id'] ? 'selected' : '' ?>>
                                <?= esc($rxOption['prescription_number']) ?> — <?= esc($rxOption['patient_name'] ?? '-') ?> (<?= esc($rxOption['status']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead class="table-light">
                            <tr>
                                <th width="40">No</th>
                                <th>Obat</th>
                                <th class="text-end">Jumlah</th>
                                <th class="text-end">Harga</th>
                                <th class="text-end">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $total = 0; ?>
                            <?php foreach ($rxItems as $i => $rxItem): ?>
                                <?php $sub = (float) $rxItem['quantity'] * (float) $rxItem['sell_price']; $total += $sub; ?>
                                <tr>
                                    <td><?= $i + 1 ?></td>
                                    <td class="fw-semibold"><?= esc($rxItem['drug_name']) ?></td>
                                    <td class="text-end"><?= number_format((float) $rxItem['quantity'], 2) ?> <?= esc($rxItem['unit']) ?></td>
                                    <td class="text-end">Rp <?= number_format((float) $rxItem['sell_price'], 0, ',', '.') ?></td>
                                    <td class="text-end">Rp <?= number_format($sub, 0, ',', '.') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-end fw-bold">Total</td>
                                <td class="text-end fw-bold" id="rxTotal">Rp <?= number_format($total, 0, ',', '.') ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-muted">Pilih resep dari dropdown di atas item untuk memuat item resep.</div>
            <?php endif; ?>
        </div>
    </div>

    <div class="d-flex align-items-center gap-3">
        <button type="submit" class="btn btn-primary fw-semibold">
            <i class="bi bi-save me-1"></i> Simpan Transaksi
        </button>
        <div class="fs-5">Total: <strong id="grandTotalDisplay">Rp 0</strong></div>
    </div>
</form>

<template id="rowTemplate">
    <tr>
        <td class="row-no"></td>
        <td>
            <select name="item_drug_id[]" class="form-select form-select-sm item-drug" required>
                <option value="">-- Pilih --</option>
                <?php foreach ($drugs as $drug): ?>
                    <option value="<?= $drug['id'] ?>" data-price="<?= $drug['sell_price'] ?>">
                        <?= esc($drug['name']) ?> (<?= esc($drug['code']) ?>) — stok <?= number_format((float) $drug['current_stock'], 2) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </td>
        <td><input type="number" name="item_qty[]" class="form-control form-control-sm item-qty" min="0.01" step="0.01" required></td>
        <td><input type="number" name="item_price[]" class="form-control form-control-sm item-price" min="0" step="0.01" required></td>
        <td class="text-end item-subtotal">Rp 0</td>
        <td><button type="button" class="btn btn-sm btn-outline-danger remove-row"><i class="bi bi-x"></i></button></td>
    </tr>
</template>

<script>
const tbody = document.querySelector('#itemsTable tbody');
const template = document.getElementById('rowTemplate');
const otcSection = document.getElementById('otcSection');
const rxSection = document.getElementById('rxSection');
const trxType = document.getElementById('trxType');

function recalc() {
    let total = 0;
    tbody.querySelectorAll('tr').forEach((tr, i) => {
        tr.querySelector('.row-no').textContent = i + 1;
        const qty = parseFloat(tr.querySelector('.item-qty').value) || 0;
        const price = parseFloat(tr.querySelector('.item-price').value) || 0;
        const sub = qty * price;
        tr.querySelector('.item-subtotal').textContent = 'Rp ' + sub.toLocaleString('id-ID');
        total += sub;
    });
    const rxTotalText = document.getElementById('rxTotal')?.textContent || 'Rp 0';
    const rxTotal = parseFloat(rxTotalText.replace(/[^\d]/g, '')) || 0;
    const grand = trxType.value === 'prescription' ? rxTotal : total;
    document.getElementById('grandTotalDisplay').textContent = 'Rp ' + grand.toLocaleString('id-ID');
}

function addRow() {
    tbody.appendChild(template.content.cloneNode(true));
    recalc();
}

document.getElementById('addItem').addEventListener('click', addRow);

tbody.addEventListener('click', (e) => {
    const btn = e.target.closest('.remove-row');
    if (btn) { btn.closest('tr').remove(); recalc(); }
});

tbody.addEventListener('change', (e) => {
    if (e.target.classList.contains('item-drug')) {
        const price = e.target.options[e.target.selectedIndex]?.dataset.price || '';
        e.target.closest('tr').querySelector('.item-price').value = price;
    }
    recalc();
});

tbody.addEventListener('input', recalc);

trxType.addEventListener('change', () => {
    if (trxType.value === 'prescription') {
        if (!document.querySelector('[name="prescription_id"]')) {
            window.location.href = '<?= base_url('transactions/create') ?>';
            return;
        }
        otcSection.style.display = 'none';
        rxSection.style.display = '';
        document.querySelector('[name="prescription_id"]').required = true;
    } else {
        otcSection.style.display = '';
        rxSection.style.display = 'none';
        if (document.querySelector('[name="prescription_id"]')) {
            document.querySelector('[name="prescription_id"]').required = false;
        }
    }
    recalc();
});

const rxSelect = document.getElementById('prescriptionSelect');
if (rxSelect) {
    rxSelect.addEventListener('change', () => {
        window.location.href = '<?= base_url('transactions/create') ?>?prescription_id=' + rxSelect.value;
    });
}

document.getElementById('trxForm').addEventListener('submit', (e) => {
    if (trxType.value === 'otc' && tbody.querySelectorAll('tr').length === 0) {
        e.preventDefault();
        alert('Minimal harus ada satu item penjualan.');
    }
});

if (trxType.value === 'otc' || tbody.querySelectorAll('tr').length === 0) {
    if (trxType.value === 'otc') addRow();
}
recalc();
</script>
<?= $this->endSection() ?>
