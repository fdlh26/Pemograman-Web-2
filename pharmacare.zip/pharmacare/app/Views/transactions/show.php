<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php
$userRole = session()->get('userRole');
$paymentLabels = ['cash' => 'Tunai', 'debit' => 'Kartu Debit', 'qris' => 'QRIS', 'transfer' => 'Transfer'];
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-receipt page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Detail Transaksi</h1>
        <p class="text-muted mb-0">
            <code><?= esc($trx['transaction_number']) ?></code>
            <?php if ($trx['type'] === 'prescription'): ?>
                <span class="badge bg-info text-dark ms-1">Resep</span>
            <?php else: ?>
                <span class="badge bg-secondary ms-1">OTC</span>
            <?php endif; ?>
        </p>
    </div>
    <div class="d-flex gap-2">
        <?php if ($trx['status'] === 'paid'): ?>
            <a href="<?= base_url('transactions/receipt/' . $trx['id']) ?>" target="_blank" class="btn btn-outline-primary">
                <i class="bi bi-printer me-1"></i> Cetak Struk
            </a>
        <?php endif; ?>
        <a href="<?= base_url('transactions') ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Status</div>
                <div>
                    <?php if ($trx['status'] === 'pending'): ?>
                        <span class="badge bg-warning text-dark">Menunggu Bayar</span>
                    <?php elseif ($trx['status'] === 'paid'): ?>
                        <span class="badge bg-success">Lunas</span>
                    <?php else: ?>
                        <span class="badge bg-secondary">Dibatalkan</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Pasien</div>
                <div class="fw-bold"><?= esc($patient['name'] ?? 'Pasien Umum') ?></div>
                <?php if ($patient): ?>
                    <div class="small text-muted"><?= esc($patient['rm_number']) ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Grand Total</div>
                <div class="fw-bold fs-5">Rp <?= number_format((float) $trx['grand_total'], 0, ',', '.') ?></div>
                <?php if ((float) $trx['discount'] > 0): ?>
                    <div class="small text-muted">Diskon: Rp <?= number_format((float) $trx['discount'], 0, ',', '.') ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Waktu</div>
                <div class="fw-bold"><?= date('d/m/Y H:i', strtotime($trx['created_at'])) ?></div>
                <?php if ($trx['paid_at']): ?>
                    <div class="small text-muted">Dibayar: <?= date('d/m/Y H:i', strtotime($trx['paid_at'])) ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm mb-3">
    <div class="card-header bg-white fw-bold">Item</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="50">No</th>
                        <th>Kode</th>
                        <th>Obat</th>
                        <th class="text-end">Jumlah</th>
                        <th class="text-end">Harga</th>
                        <th class="text-end">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $i => $item): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><code><?= esc($item['drug_code'] ?? '-') ?></code></td>
                            <td class="fw-semibold"><?= esc($item['drug_name'] ?? '-') ?></td>
                            <td class="text-end"><?= number_format((float) $item['quantity'], 2) ?> <?= esc($item['unit'] ?? '') ?></td>
                            <td class="text-end">Rp <?= number_format((float) $item['unit_price'], 0, ',', '.') ?></td>
                            <td class="text-end">Rp <?= number_format((float) $item['subtotal'], 0, ',', '.') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="5" class="text-end">Subtotal</td>
                        <td class="text-end">Rp <?= number_format((float) $trx['total_amount'], 0, ',', '.') ?></td>
                    </tr>
                    <tr>
                        <td colspan="5" class="text-end">Diskon</td>
                        <td class="text-end">- Rp <?= number_format((float) $trx['discount'], 0, ',', '.') ?></td>
                    </tr>
                    <tr class="table-light">
                        <td colspan="5" class="text-end fw-bold">Grand Total</td>
                        <td class="text-end fw-bold">Rp <?= number_format((float) $trx['grand_total'], 0, ',', '.') ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<?php if ($trx['status'] === 'paid'): ?>
    <div class="card border-0 shadow-sm mb-3">
        <div class="card-header bg-white fw-bold">Pembayaran</div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3"><span class="text-muted">Metode:</span> <strong><?= $paymentLabels[$trx['payment_method']] ?? esc($trx['payment_method']) ?></strong></div>
                <div class="col-md-3"><span class="text-muted">Dibayar:</span> <strong>Rp <?= number_format((float) $trx['paid_amount'], 0, ',', '.') ?></strong></div>
                <div class="col-md-3"><span class="text-muted">Kembalian:</span> <strong>Rp <?= number_format((float) $trx['change_amount'], 0, ',', '.') ?></strong></div>
                <div class="col-md-3"><span class="text-muted">Kasir:</span> <strong><?= esc($cashier['name'] ?? '-') ?></strong></div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if ($trx['status'] === 'pending' && in_array($userRole, ['admin', 'kasir'], true)): ?>
    <div class="card border-0 shadow-sm mb-3">
        <div class="card-header bg-white fw-bold">Proses Pembayaran</div>
        <div class="card-body">
            <form action="<?= base_url('transactions/pay/' . $trx['id']) ?>" method="post" class="row g-3 align-items-end">
                <?= csrf_field() ?>
                <div class="col-md-3">
                    <label for="payment_method" class="form-label">Metode Bayar <span class="text-danger">*</span></label>
                    <select class="form-select" id="payment_method" name="payment_method" required>
                        <option value="cash">Tunai</option>
                        <option value="debit">Kartu Debit</option>
                        <option value="qris">QRIS</option>
                        <option value="transfer">Transfer</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="paid_amount" class="form-label">Jumlah Bayar <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="paid_amount" name="paid_amount" min="0" step="0.01" required
                           value="<?= esc(old('paid_amount', $trx['grand_total'])) ?>">
                </div>
                <div class="col-md-3">
                    <div class="form-label">Kembalian</div>
                    <div class="form-control bg-light" id="changeDisplay">Rp 0</div>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-success fw-semibold w-100">
                        <i class="bi bi-cash-coin me-1"></i> Bayar
                    </button>
                </div>
            </form>
            <div class="mt-3">
                <form action="<?= base_url('transactions/cancel/' . $trx['id']) ?>" method="post" class="d-inline"
                      onsubmit="return confirm('Batalkan transaksi ini? Transaksi yang dibatalkan tidak dapat dipulihkan.')">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-outline-danger btn-sm">
                        <i class="bi bi-x-circle me-1"></i> Batalkan Transaksi
                    </button>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>

<script>
const paidInput = document.getElementById('paid_amount');
const changeDisplay = document.getElementById('changeDisplay');
const grandTotal = <?= (float) $trx['grand_total'] ?>;
if (paidInput) {
    const update = () => {
        const paid = parseFloat(paidInput.value) || 0;
        const change = paid - grandTotal;
        changeDisplay.textContent = 'Rp ' + Math.max(0, change).toLocaleString('id-ID');
    };
    paidInput.addEventListener('input', update);
    update();
}
</script>
<?= $this->endSection() ?>
