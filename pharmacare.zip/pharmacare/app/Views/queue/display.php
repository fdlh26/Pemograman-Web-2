<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Layar Antrean') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0d2137 0%, #1e3a5f 100%);
            color: #fff;
            min-height: 100vh;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        .header {
            padding: 1.25rem 2rem;
            border-bottom: 1px solid rgba(255,255,255,0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.6rem; margin: 0; }
        .now-called {
            text-align: center;
            padding: 2.5rem 1rem;
        }
        .now-called .label { font-size: 1.3rem; opacity: 0.8; letter-spacing: 4px; text-transform: uppercase; }
        .now-called .number {
            font-size: 9rem;
            font-weight: 800;
            color: #ffd43b;
            line-height: 1.1;
            text-shadow: 0 4px 24px rgba(255, 212, 59, 0.35);
            animation: pulse 1.6s ease-in-out infinite;
        }
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.04); }
        }
        .next-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 1rem;
            padding: 0 2rem 2rem;
        }
        .next-card {
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.12);
            border-radius: 1rem;
            padding: 1.25rem;
            text-align: center;
        }
        .next-card .n-label { font-size: 0.85rem; opacity: 0.7; text-transform: uppercase; letter-spacing: 2px; }
        .next-card .n-number { font-size: 2.4rem; font-weight: 700; }
        .next-card.waiting { opacity: 0.55; }
        .stats {
            display: flex;
            gap: 2rem;
            justify-content: center;
            padding-bottom: 2rem;
        }
        .stat { text-align: center; }
        .stat .v { font-size: 2rem; font-weight: 700; }
        .stat .l { font-size: 0.9rem; opacity: 0.7; }
        .footer-bar {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 0.6rem 2rem;
            background: rgba(0,0,0,0.35);
            display: flex;
            justify-content: space-between;
            font-size: 0.95rem;
        }
        .empty-number { color: rgba(255,255,255,0.35); }
    </style>
</head>
<body>
    <div class="header">
        <h1><i class="bi bi-capsule-pill me-2"></i>Pengambilan Obat — PharmaCare</h1>
        <div class="fs-5" id="clock"></div>
    </div>

    <div class="now-called">
        <div class="label">Sedang Dipanggil</div>
        <div class="number" id="calledNumber">—</div>
        <div class="fs-4" id="calledPatient"></div>
    </div>

    <div class="next-grid" id="nextGrid"></div>

    <div class="stats">
        <div class="stat"><div class="v" id="statTotal">0</div><div class="l">Total Hari Ini</div></div>
        <div class="stat"><div class="v" id="statDone">0</div><div class="l">Selesai</div></div>
        <div class="stat"><div class="v" id="statWaiting">0</div><div class="l">Menunggu</div></div>
    </div>

    <div class="footer-bar">
        <span><i class="bi bi-volume-up me-1"></i> Suara panggilan aktif</span>
        <span id="updatedAt"></span>
    </div>

    <script>
        let lastCalled = null;

        function speak(text) {
            if (!('speechSynthesis' in window)) return;
            const u = new SpeechSynthesisUtterance(text);
            u.lang = 'id-ID';
            u.rate = 0.95;
            speechSynthesis.cancel();
            speechSynthesis.speak(u);
        }

        function render(data) {
            const calledEl = document.getElementById('calledNumber');
            const patientEl = document.getElementById('calledPatient');

            if (data.called) {
                calledEl.textContent = data.called.queue_number;
                calledEl.classList.remove('empty-number');
                patientEl.textContent = data.called.patient_name || '';

                if (lastCalled !== null && data.called.queue_number !== lastCalled) {
                    speak('Nomor antrean ' + data.called.queue_number.split('').join(' ') + ', silakan menuju loket pengambilan obat.');
                }
                lastCalled = data.called.queue_number;
            } else {
                calledEl.textContent = '—';
                calledEl.classList.add('empty-number');
                patientEl.textContent = '';
                lastCalled = null;
            }

            const grid = document.getElementById('nextGrid');
            grid.innerHTML = '';
            const next = (data.next || []).slice(0, 5);
            if (next.length === 0) {
                grid.innerHTML = '<div class="next-card" style="grid-column: 1 / -1;"><div class="n-label">Antrean Berikutnya</div><div class="n-number empty-number">Kosong</div></div>';
            } else {
                next.forEach((q) => {
                    const cls = q.status === 'waiting' ? 'next-card waiting' : 'next-card';
                    const statusLabel = { waiting: 'Menunggu', processing: 'Diproses', ready: 'Siap' }[q.status] || q.status;
                    grid.innerHTML += '<div class="' + cls + '"><div class="n-label">' + statusLabel + '</div><div class="n-number">' + q.queue_number + '</div></div>';
                });
            }

            document.getElementById('statTotal').textContent = data.total_today || 0;
            document.getElementById('statDone').textContent = data.done_today || 0;
            document.getElementById('statWaiting').textContent = (data.next || []).length;
            document.getElementById('updatedAt').textContent = 'Diperbarui: ' + new Date().toLocaleTimeString('id-ID');
        }

        async function fetchLive() {
            try {
                const res = await fetch('<?= base_url('queue/live') ?>', { credentials: 'same-origin' });
                if (res.ok) render(await res.json());
            } catch (e) { /* ignore */ }
        }

        function updateClock() {
            document.getElementById('clock').textContent = new Date().toLocaleString('id-ID', {
                weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit'
            });
        }

        updateClock();
        setInterval(updateClock, 1000);
        fetchLive();
        setInterval(fetchLive, 5000);
    </script>
</body>
</html>
