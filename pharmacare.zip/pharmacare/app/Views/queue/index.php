<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-people-clock page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Antrean Pengambilan Obat</h1>
        <p class="text-muted mb-0">Kelola & panggil nomor antrean hari ini (<?= date('d/m/Y') ?>)</p>
    </div>
    <div>
        <a href="<?= base_url('queue/display') ?>" target="_blank" class="btn btn-outline-primary">
            <i class="bi bi-tv me-1"></i> Layar Monitor
        </a>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#manualModal">
            <i class="bi bi-plus-lg me-1"></i> Antrean Manual
        </button>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm bg-warning bg-opacity-10">
            <div class="card-body text-center">
                <div class="text-muted small">Sedang Dipanggil</div>
                <div class="fs-2 fw-bold text-warning"><?= esc($live['called']['queue_number'] ?? '—') ?></div>
                <?php if (! empty($live['called']['patient_name'])): ?>
                    <div class="small"><?= esc($live['called']['patient_name']) ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center">
                <div class="text-muted small">Total Hari Ini</div>
                <div class="fs-2 fw-bold"><?= (int) $live['total_today'] ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center">
                <div class="text-muted small">Menunggu / Diproses</div>
                <div class="fs-2 fw-bold text-info"><?= count($live['next']) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center">
                <div class="text-muted small">Selesai</div>
                <div class="fs-2 fw-bold text-success"><?= (int) $live['done_today'] ?></div>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="50">No</th>
                        <th>No. Antrean</th>
                        <th>Pasien</th>
                        <th>Resep</th>
                        <th class="text-center">Status</th>
                        <th>Dibuat</th>
                        <th width="280">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($queues)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">Belum ada antrean hari ini. Klik "Buat Nomor" untuk mendaftarkan pasien.</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = ($pager->getCurrentPage('queues') - 1) * $pager->getPerPage('queues') + 1; ?>
                        <?php foreach ($queues as $queue): ?>
                            <?php $lc = match ($queue['status']) {
                                'waiting'    => ['Menunggu', 'secondary'],
                                'processing' => ['Diproses', 'info'],
                                'ready'      => ['Siap Diambil', 'primary'],
                                'called'     => ['Dipanggil', 'warning'],
                                'done'       => ['Selesai', 'success'],
                                default      => ['-', 'secondary'],
                            }; [$label, $color] = $lc; ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td class="fs-5 fw-bold"><?= esc($queue['queue_number']) ?></td>
                                <td>
                                    <?= esc($queue['patient_name'] ?? '-') ?>
                                    <div class="small text-muted"><?= esc($queue['rm_number'] ?? '') ?></div>
                                </td>
                                <td><code class="small"><?= esc($queue['prescription_number'] ?? '-') ?></code></td>
                                <td class="text-center"><span class="badge bg-<?= $color ?>"><?= $label ?></span></td>
                                <td class="text-muted"><?= date('H:i', strtotime($queue['created_at'])) ?></td>
                                <td>
                                    <?php $userId = (int) session()->get('userId'); ?>
                                    <?php if (in_array($queue['status'], ['waiting'], true)): ?>
                                        <form action="<?= base_url('queue/update/' . $queue['id'] . '/process') ?>" method="post" class="d-inline"><?= csrf_field() ?>
                                            <button class="btn btn-sm btn-outline-info"><i class="bi bi-gear"></i> Proses</button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if (in_array($queue['status'], ['waiting', 'processing'], true)): ?>
                                        <form action="<?= base_url('queue/update/' . $queue['id'] . '/ready') ?>" method="post" class="d-inline"><?= csrf_field() ?>
                                            <button class="btn btn-sm btn-outline-primary"><i class="bi bi-check2"></i> Siap</button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if (in_array($queue['status'], ['waiting', 'processing', 'ready'], true)): ?>
                                        <form action="<?= base_url('queue/update/' . $queue['id'] . '/call') ?>" method="post" class="d-inline"><?= csrf_field() ?>
                                            <button class="btn btn-sm btn-warning"><i class="bi bi-megaphone"></i> Panggil</button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if ($queue['status'] !== 'done'): ?>
                                        <form action="<?= base_url('queue/update/' . $queue['id'] . '/done') ?>" method="post" class="d-inline"><?= csrf_field() ?>
                                            <button class="btn btn-sm btn-success"><i class="bi bi-check-circle"></i> Selesai</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= $pager->links('queues') ?>
    </div>
</div>

<!-- Modal antrean manual -->
<div class="modal fade" id="manualModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="<?= base_url('queue/store') ?>" method="post" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header">
                <h5 class="modal-title">Antrean Manual</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="patient_id" class="form-label">Pasien <span class="text-danger">*</span></label>
                    <select class="form-select" id="patient_id" name="patient_id" required>
                        <option value="">-- Pilih Pasien --</option>
                        <?php foreach ($patients as $p): ?>
                            <option value="<?= $p['id'] ?>"><?= esc($p['name']) ?> (<?= esc($p['rm_number']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-0">
                    <label for="note" class="form-label">Catatan</label>
                    <input type="text" class="form-control" id="note" name="note" maxlength="255" placeholder="Opsional">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary">Buat Nomor</button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
