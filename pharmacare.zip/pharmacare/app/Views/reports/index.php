<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php
$tabs = [
    'inventory'    => ['label' => 'Persediaan', 'icon' => 'bi-box-seam'],
    'purchases'    => ['label' => 'Pembelian', 'icon' => 'bi-cart-check'],
    'sales'        => ['label' => 'Penjualan', 'icon' => 'bi-cash-stack'],
    'usage'        => ['label' => 'Penggunaan Obat', 'icon' => 'bi-arrow-down-square'],
    'expiry'       => ['label' => 'Kedaluwarsa', 'icon' => 'bi-calendar-x'],
    'transactions' => ['label' => 'Riwayat Transaksi', 'icon' => 'bi-receipt-cutoff'],
];
$showCategory = in_array($type, ['inventory', 'usage', 'expiry'], true);
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-graph-up page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Laporan Farmasi</h1>
        <p class="text-muted mb-0">Periode <?= date('d/m/Y', strtotime($from)) ?> — <?= date('d/m/Y', strtotime($to)) ?></p>
    </div>
    <button type="button" class="btn btn-outline-primary" onclick="window.print()">
        <i class="bi bi-printer me-1"></i> Cetak Laporan
    </button>
</div>

<ul class="nav nav-pills mb-3 flex-nowrap" style="overflow-x: auto;">
    <?php foreach ($tabs as $key => $tab): ?>
        <li class="nav-item">
            <a class="nav-link <?= $type === $key ? 'active' : '' ?>"
               href="<?= base_url('reports?type=' . $key . '&from=' . urlencode($from) . '&to=' . urlencode($to) . ($categoryId > 0 ? '&category_id=' . $categoryId : '')) ?>">
                <i class="bi <?= $tab['icon'] ?> me-1"></i><?= $tab['label'] ?>
            </a>
        </li>
    <?php endforeach; ?>
</ul>

<div class="card border-0 shadow-sm mb-3 no-print">
    <div class="card-body">
        <form action="<?= base_url('reports') ?>" method="get" class="row g-2 align-items-end">
            <input type="hidden" name="type" value="<?= esc($type) ?>">
            <div class="col-auto">
                <label class="form-label small mb-1">Dari Tanggal</label>
                <input type="date" class="form-control form-control-sm" name="from" value="<?= esc($from) ?>">
            </div>
            <div class="col-auto">
                <label class="form-label small mb-1">Sampai Tanggal</label>
                <input type="date" class="form-control form-control-sm" name="to" value="<?= esc($to) ?>">
            </div>
            <?php if ($showCategory): ?>
                <div class="col-auto">
                    <label class="form-label small mb-1">Kategori</label>
                    <select class="form-select form-select-sm" name="category_id">
                        <option value="0">-- Semua Kategori --</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= $categoryId === (int) $cat['id'] ? 'selected' : '' ?>>
                                <?= esc($cat['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary btn-sm">
                    <i class="bi bi-funnel me-1"></i> Tampilkan
                </button>
            </div>
        </form>
    </div>
</div>

<div class="row g-2 mb-3">
    <?php foreach ($summary as $label => $value): ?>
        <div class="col-6 col-md-3">
            <div class="card border-0 bg-light">
                <div class="card-body py-2 px-3">
                    <div class="small text-muted"><?= esc((string) $label) ?></div>
                    <div class="fw-bold"><?= is_numeric($value) ? number_format((float) $value, 0, ',', '.') : esc((string) $value) ?></div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <?php if ($type === 'inventory'): ?>
                            <th>Kode</th><th>Obat</th><th>Kategori</th><th class="text-end">Stok</th><th class="text-end">Min</th>
                            <th class="text-end">Beli</th><th class="text-end">Jual</th><th class="text-end">Nilai Stok</th><th class="text-center">Status</th>
                        <?php elseif ($type === 'purchases'): ?>
                            <th>No. PO</th><th>Tanggal</th><th>Supplier</th><th>Petugas</th><th class="text-center">Status</th><th class="text-end">Total</th>
                        <?php elseif ($type === 'sales'): ?>
                            <th>No. TRX</th><th>Tanggal Lunas</th><th>Tipe</th><th>Pasien</th><th>Kasir</th><th>Metode</th><th class="text-end">Diskon</th><th class="text-end">Grand Total</th>
                        <?php elseif ($type === 'usage'): ?>
                            <th>Obat</th><th>Kode</th><th>Kategori</th><th class="text-center">Kali Keluar</th><th class="text-end">Total Keluar</th>
                        <?php elseif ($type === 'expiry'): ?>
                            <th>Obat</th><th>Kategori</th><th>Batch</th><th>Kedaluwarsa</th><th class="text-end">Sisa</th><th class="text-center">Status</th>
                        <?php else: ?>
                            <th>No. TRX</th><th>Tanggal</th><th>Tipe</th><th>Pasien</th><th>Resep</th><th>Petugas</th><th class="text-center">Status</th><th class="text-end">Grand Total</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($rows)): ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted py-4">Tidak ada data pada periode ini.</td>
                        </tr>
                    <?php else: ?>
                        <?php $rp = static fn ($v): string => 'Rp ' . number_format((float) $v, 0, ',', '.'); ?>
                        <?php $num = static fn ($v): string => rtrim(rtrim(number_format((float) $v, 2, '.', ''), '0'), '.'); ?>
                        <?php foreach ($rows as $r): ?>
                            <tr>
                                <?php if ($type === 'inventory'): ?>
                                    <td><code class="small"><?= esc($r['code']) ?></code></td>
                                    <td><?= esc($r['name']) ?></td>
                                    <td class="small"><?= esc($r['category_name'] ?? '-') ?></td>
                                    <td class="text-end fw-semibold"><?= $num($r['current_stock']) ?></td>
                                    <td class="text-end small"><?= $num($r['min_stock']) ?></td>
                                    <td class="text-end small"><?= $rp($r['buy_price']) ?></td>
                                    <td class="text-end small"><?= $rp($r['sell_price']) ?></td>
                                    <td class="text-end"><?= $rp((float) $r['current_stock'] * (float) $r['buy_price']) ?></td>
                                    <td class="text-center">
                                        <?php if ((float) $r['current_stock'] <= 0): ?>
                                            <span class="badge bg-danger">Habis</span>
                                        <?php elseif ((float) $r['current_stock'] <= (float) $r['min_stock']): ?>
                                            <span class="badge bg-warning text-dark">Menipis</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Normal</span>
                                        <?php endif; ?>
                                    </td>
                                <?php elseif ($type === 'purchases'): ?>
                                    <td><code class="small"><?= esc($r['purchase_number']) ?></code></td>
                                    <td class="small"><?= date('d/m/Y', strtotime($r['order_date'])) ?></td>
                                    <td class="small"><?= esc($r['supplier_name'] ?? '-') ?></td>
                                    <td class="small"><?= esc($r['staff_name'] ?? '-') ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-<?= ['ordered' => 'secondary', 'received' => 'success', 'cancelled' => 'danger'][$r['status']] ?>">
                                            <?= ['ordered' => 'Dipesan', 'received' => 'Diterima', 'cancelled' => 'Batal'][$r['status']] ?>
                                        </span>
                                    </td>
                                    <td class="text-end"><?= $rp($r['total_amount']) ?></td>
                                <?php elseif ($type === 'sales'): ?>
                                    <td><code class="small"><?= esc($r['transaction_number']) ?></code></td>
                                    <td class="small"><?= $r['paid_at'] ? date('d/m/Y H:i', strtotime($r['paid_at'])) : '-' ?></td>
                                    <td class="small"><?= $r['type'] === 'otc' ? 'OTC' : 'Resep' ?></td>
                                    <td class="small"><?= esc($r['patient_name'] ?? '-') ?></td>
                                    <td class="small"><?= esc($r['cashier_name'] ?? '-') ?></td>
                                    <td class="small"><?= esc(strtoupper($r['payment_method'] ?? '-')) ?></td>
                                    <td class="text-end small"><?= $rp($r['discount']) ?></td>
                                    <td class="text-end"><?= $rp($r['grand_total']) ?></td>
                                <?php elseif ($type === 'usage'): ?>
                                    <td><?= esc($r['drug_name'] ?? '-') ?></td>
                                    <td><code class="small"><?= esc($r['code'] ?? '-') ?></code></td>
                                    <td class="small"><?= esc($r['category_name'] ?? '-') ?></td>
                                    <td class="text-center"><?= (int) $r['times'] ?></td>
                                    <td class="text-end fw-semibold"><?= $num($r['total_qty']) ?></td>
                                <?php elseif ($type === 'expiry'): ?>
                                    <td><?= esc($r['drug_name'] ?? '-') ?></td>
                                    <td class="small"><?= esc($r['category_name'] ?? '-') ?></td>
                                    <td><code class="small"><?= esc($r['batch_number'] ?? '-') ?></code></td>
                                    <td class="small <?= $r['expiry_date'] < date('Y-m-d') ? 'text-danger fw-bold' : '' ?>">
                                        <?= date('d/m/Y', strtotime($r['expiry_date'])) ?>
                                    </td>
                                    <td class="text-end"><?= $num($r['remaining_qty']) ?> <?= esc($r['unit'] ?? '') ?></td>
                                    <td class="text-center">
                                        <?php if ($r['expiry_date'] < date('Y-m-d')): ?>
                                            <span class="badge bg-danger">Kedaluwarsa</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">≤ Periode</span>
                                        <?php endif; ?>
                                    </td>
                                <?php else: ?>
                                    <td><code class="small"><?= esc($r['transaction_number']) ?></code></td>
                                    <td class="small"><?= date('d/m/Y H:i', strtotime($r['created_at'])) ?></td>
                                    <td class="small"><?= $r['type'] === 'otc' ? 'OTC' : 'Resep' ?></td>
                                    <td class="small"><?= esc($r['patient_name'] ?? '-') ?></td>
                                    <td class="small"><code class="small"><?= esc($r['prescription_number'] ?? '-') ?></code></td>
                                    <td class="small"><?= esc($r['staff_name'] ?? '-') ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-<?= ['pending' => 'secondary', 'paid' => 'success', 'cancelled' => 'danger'][$r['status']] ?>">
                                            <?= ['pending' => 'Menunggu', 'paid' => 'Lunas', 'cancelled' => 'Batal'][$r['status']] ?>
                                        </span>
                                    </td>
                                    <td class="text-end"><?= $rp($r['grand_total']) ?></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style media="print">
    .no-print, .sidebar, .topbar { display: none !important; }
    .content-wrapper { margin: 0 !important; padding: 0 !important; }
    .card { box-shadow: none !important; }
</style>
<?= $this->endSection() ?>
