<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-capsule page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Data Obat</h1>
        <p class="text-muted mb-0">Kelola data master obat</p>
    </div>
    <?php if (in_array(session()->get('userRole'), ['admin', 'apoteker', 'gudang'], true)): ?>
        <a href="<?= base_url('drugs/create') ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Tambah
        </a>
    <?php endif; ?>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= base_url('drugs') ?>" method="get" class="row g-2 mb-3">
            <div class="col-md-4">
                <input type="text" class="form-control" name="q" placeholder="Cari nama / kode obat..." value="<?= esc($search ?? '') ?>">
            </div>
            <div class="col-md-3">
                <select class="form-select" name="category">
                    <option value="">Semua Kategori</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= $category['id'] ?>" <?= ($categoryId ?? null) == $category['id'] ? 'selected' : '' ?>>
                            <?= esc($category['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
                <?php if (! empty($search) || ! empty($categoryId)): ?>
                    <a href="<?= base_url('drugs') ?>" class="btn btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="60">No</th>
                        <th>Kode</th>
                        <th>Nama Obat</th>
                        <th>Kategori</th>
                        <th>Satuan</th>
                        <th class="text-end">Harga Jual</th>
                        <th class="text-center">Stok</th>
                        <th>Status</th>
                        <th width="200">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($drugs)): ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted py-4">Belum ada data obat. Klik "Tambah" untuk menambahkan obat baru.</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = ($pager->getCurrentPage('drugs') - 1) * $pager->getPerPage('drugs') + 1; ?>
                        <?php foreach ($drugs as $drug): ?>
                            <?php $status = $drugModel->getStockStatus($drug); ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><code><?= esc($drug['code']) ?></code></td>
                                <td class="fw-semibold"><?= esc($drug['name']) ?></td>
                                <td><?= esc($drug['category_name'] ?? '-') ?></td>
                                <td><?= esc($drug['unit']) ?></td>
                                <td class="text-end">Rp <?= number_format((float) $drug['sell_price'], 0, ',', '.') ?></td>
                                <td class="text-center"><?= number_format((float) $drug['current_stock'], 2) ?></td>
                                <td>
                                    <?php if ($status === 'habis'): ?>
                                        <span class="badge bg-danger">Habis</span>
                                    <?php elseif ($status === 'menipis'): ?>
                                        <span class="badge bg-warning text-dark">Menipis</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Aman</span>
                                    <?php endif; ?>
                                    <?php if ((int) $drug['is_active'] !== 1): ?>
                                        <span class="badge bg-secondary">Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (in_array(session()->get('userRole'), ['admin', 'apoteker', 'gudang'], true)): ?>
                                        <a href="<?= base_url('drugs/edit/' . $drug['id']) ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-pencil" title="Edit"></i>
                                        </a>
                                        <form action="<?= base_url('drugs/delete/' . $drug['id']) ?>" method="post" class="d-inline"
                                              onsubmit="return confirm('Hapus obat ini? Data yang dihapus tidak dapat dikembalikan.')">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash" title="Hapus"></i></button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= $pager->links('drugs') ?>
    </div>
</div>
<?= $this->endSection() ?>
