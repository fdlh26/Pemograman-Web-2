<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-capsule page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1"><?= $drug ? 'Edit' : 'Tambah' ?> Obat</h1>
        <p class="text-muted mb-0"><?= $drug ? 'Perbarui data obat' : 'Tambah data obat baru' ?></p>
    </div>
    <a href="<?= base_url('drugs') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <form action="<?= $drug ? base_url('drugs/update/' . $drug['id']) : base_url('drugs/store') ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="code" class="form-label">Kode Obat <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="code" name="code" required maxlength="50"
                           value="<?= esc(old('code', $drug['code'] ?? '')) ?>" placeholder="Contoh: OBT-001">
                </div>
                <div class="col-md-6">
                    <label for="name" class="form-label">Nama Obat <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="name" name="name" required maxlength="150"
                           value="<?= esc(old('name', $drug['name'] ?? '')) ?>" placeholder="Contoh: Paracetamol 500mg">
                </div>
                <div class="col-md-6">
                    <label for="category_id" class="form-label">Kategori <span class="text-danger">*</span></label>
                    <select class="form-select" id="category_id" name="category_id" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= $category['id'] ?>"
                                <?= (int) old('category_id', $drug['category_id'] ?? 0) === (int) $category['id'] ? 'selected' : '' ?>>
                                <?= esc($category['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="unit" class="form-label">Satuan <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="unit" name="unit" required maxlength="30"
                           value="<?= esc(old('unit', $drug['unit'] ?? '')) ?>" placeholder="tablet / strip / botol">
                </div>
                <div class="col-md-3">
                    <label for="dosage" class="form-label">Dosis</label>
                    <input type="text" class="form-control" id="dosage" name="dosage" maxlength="100"
                           value="<?= esc(old('dosage', $drug['dosage'] ?? '')) ?>" placeholder="500 mg">
                </div>
                <div class="col-md-4">
                    <label for="buy_price" class="form-label">Harga Beli (Rp)</label>
                    <input type="number" class="form-control" id="buy_price" name="buy_price" min="0" step="0.01"
                           value="<?= esc(old('buy_price', $drug['buy_price'] ?? '0')) ?>">
                </div>
                <div class="col-md-4">
                    <label for="sell_price" class="form-label">Harga Jual (Rp)</label>
                    <input type="number" class="form-control" id="sell_price" name="sell_price" min="0" step="0.01"
                           value="<?= esc(old('sell_price', $drug['sell_price'] ?? '0')) ?>">
                </div>
                <div class="col-md-4">
                    <label for="min_stock" class="form-label">Stok Minimum</label>
                    <input type="number" class="form-control" id="min_stock" name="min_stock" min="0" step="0.01"
                           value="<?= esc(old('min_stock', $drug['min_stock'] ?? '0')) ?>">
                </div>
                <?php if (! $drug): ?>
                    <div class="col-md-4">
                        <label for="initial_stock" class="form-label">Stok Awal</label>
                        <input type="number" class="form-control" id="initial_stock" name="initial_stock" min="0" step="0.01"
                               value="<?= esc(old('initial_stock', '0')) ?>">
                        <div class="form-text">Dicatat otomatis sebagai stok masuk.</div>
                    </div>
                <?php endif; ?>
                <div class="col-md-12">
                    <label for="description" class="form-label">Deskripsi / Aturan Pakai</label>
                    <textarea class="form-control" id="description" name="description" rows="3"
                              placeholder="Informasi tambahan obat (opsional)"><?= esc(old('description', $drug['description'] ?? '')) ?></textarea>
                </div>
                <div class="col-md-4">
                    <label for="is_active" class="form-label">Status</label>
                    <select class="form-select" id="is_active" name="is_active">
                        <option value="1" <?= (int) old('is_active', $drug['is_active'] ?? 1) === 1 ? 'selected' : '' ?>>Aktif</option>
                        <option value="0" <?= (int) old('is_active', $drug['is_active'] ?? 1) === 0 ? 'selected' : '' ?>>Nonaktif</option>
                    </select>
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Simpan
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
