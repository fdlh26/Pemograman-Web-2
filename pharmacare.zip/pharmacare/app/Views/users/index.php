<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-people-gear page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Manajemen Pengguna</h1>
        <p class="text-muted mb-0">Kelola akun, peran, dan status pengguna sistem</p>
    </div>
    <a href="<?= base_url('users/create') ?>" class="btn btn-primary">
        <i class="bi bi-person-plus me-1"></i> Tambah Pengguna
    </a>
</div>

<div class="card border-0 shadow-sm mb-3">
    <div class="card-body">
        <form action="<?= base_url('users') ?>" method="get" class="row g-2">
            <div class="col-md-5">
                <input type="text" class="form-control" name="q" placeholder="Cari username, nama, atau email..." value="<?= esc($keyword) ?>">
            </div>
            <div class="col-md-4">
                <select class="form-select" name="role_id">
                    <option value="0">-- Semua Role --</option>
                    <?php foreach ($roles as $r): ?>
                        <option value="<?= $r['id'] ?>" <?= $roleId === (int) $r['id'] ? 'selected' : '' ?>>
                            <?= esc($r['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto">
                <button class="btn btn-outline-primary" type="submit"><i class="bi bi-funnel me-1"></i> Filter</button>
                <a href="<?= base_url('users') ?>" class="btn btn-outline-secondary">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Username</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Telepon</th>
                        <th>Peran</th>
                        <th class="text-center">Status</th>
                        <th>Login Terakhir</th>
                        <th width="230">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-4">Belum ada pengguna. Klik "Tambah Pengguna" untuk menambahkan akun baru.</td></tr>
                    <?php else: $selfId = (int) session()->get('userId'); ?>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td><code><?= esc($u['username'] ?? '-') ?></code></td>
                                <td class="fw-semibold"><?= esc($u['name']) ?><?= (int) $u['id'] === $selfId ? ' <span class="badge bg-info">Anda</span>' : '' ?></td>
                                <td><?= esc($u['email']) ?></td>
                                <td class="small"><?= esc($u['phone'] ?: '-') ?></td>
                                <td>
                                    <span class="badge bg-<?= $u['role_name'] === 'admin' ? 'danger' : 'secondary' ?>"><?= esc($u['role_name']) ?></span>
                                    <div class="small text-muted"><?= esc($u['role_description'] ?? '') ?></div>
                                </td>
                                <td class="text-center">
                                    <?php if ((int) $u['is_active'] === 1): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-dark">Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                                <td class="small text-muted"><?= $u['last_login_at'] ? date('d/m/Y H:i', strtotime($u['last_login_at'])) : '-' ?></td>
                                <td>
                                    <a href="<?= base_url('users/edit/' . $u['id']) ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil" title="Edit"></i>
                                    </a>
                                    <form action="<?= base_url('users/toggle/' . $u['id']) ?>" method="post" class="d-inline"><?= csrf_field() ?>
                                        <button class="btn btn-sm btn-outline-<?= (int) $u['is_active'] === 1 ? 'warning' : 'success' ?>"
                                                onclick="return confirm('<?= (int) $u['is_active'] === 1 ? 'Nonaktifkan pengguna ini? Pengguna tidak akan bisa login.' : 'Aktifkan pengguna ini? Pengguna dapat kembali login.' ?>')">
                                            <i class="bi bi-<?= (int) $u['is_active'] === 1 ? 'pause' : 'play' ?>"></i>
                                        </button>
                                    </form>
                                    <?php if ((int) $u['id'] !== $selfId): ?>
                                        <form action="<?= base_url('users/delete/' . $u['id']) ?>" method="post" class="d-inline"><?= csrf_field() ?>
                                            <button class="btn btn-sm btn-outline-danger"
                                                    onclick="return confirm('Hapus pengguna <?= esc($u['name']) ?>? Pengguna tidak akan bisa login lagi. Tindakan ini tercatat di Riwayat Aktivitas.')">
                                                <i class="bi bi-trash" title="Hapus"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?= $pager->links('users') ?>
    </div>
</div>
<?= $this->endSection() ?>
