<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php $isEdit = $user !== null; ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-person-plus page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1"><?= $isEdit ? 'Edit Pengguna' : 'Tambah Pengguna' ?></h1>
        <p class="text-muted mb-0"><?= $isEdit ? esc($user['email']) : 'Buat akun pengguna baru' ?></p>
    </div>
    <a href="<?= base_url('users') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali
    </a>
</div>

<div class="row">
    <div class="col-lg-7">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <form action="<?= base_url($isEdit ? 'users/update/' . $user['id'] : 'users/store') ?>" method="post">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label">Username <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="username" maxlength="50" required
                               pattern="[a-z0-9._-]{3,50}" title="Huruf kecil, angka, titik, strip, atau underscore"
                               value="<?= esc(old('username', $user['username'] ?? '')) ?>">
                        <div class="form-text">Dipakai untuk login. Huruf kecil, angka, titik, strip (maks. 50).</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="name" maxlength="100" required
                               value="<?= esc(old('name', $user['name'] ?? '')) ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" name="email" maxlength="100" required
                               value="<?= esc(old('email', $user['email'] ?? '')) ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Telepon</label>
                            <input type="text" class="form-control" name="phone" maxlength="20"
                                   value="<?= esc(old('phone', $user['phone'] ?? '')) ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Role <span class="text-danger">*</span></label>
                            <select class="form-select" name="role_id" required>
                                <option value="">-- Pilih Role --</option>
                                <?php foreach ($roles as $r): ?>
                                    <option value="<?= $r['id'] ?>"
                                        <?= (int) old('role_id', $user['role_id'] ?? 0) === (int) $r['id'] ? 'selected' : '' ?>>
                                        <?= esc($r['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            Password <?= $isEdit ? '<span class="text-muted small">(kosongkan jika tidak diganti)</span>' : '<span class="text-danger">*</span>' ?>
                        </label>
                        <input type="password" class="form-control" name="password" minlength="8" maxlength="255"
                               autocomplete="new-password" <?= $isEdit ? '' : 'required' ?>>
                        <?php if (! $isEdit): ?>
                            <div class="form-text">Minimal 8 karakter.</div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-4">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="is_active" value="1" id="isActive"
                                <?= (int) old('is_active', $user['is_active'] ?? 1) === 1 ? 'checked' : '' ?>>
                            <label class="form-check-label" for="isActive">Akun aktif (dapat login)</label>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary fw-semibold">
                        <i class="bi bi-check-lg me-1"></i> <?= $isEdit ? 'Simpan Perubahan' : 'Buat Pengguna' ?>
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h2 class="h6 fw-bold mb-2">Keterangan Role</h2>
                <ul class="list-unstyled mb-0 small">
                    <?php foreach ($roles as $r): ?>
                        <li class="mb-2">
                            <span class="badge bg-<?= $r['name'] === 'admin' ? 'danger' : 'secondary' ?>"><?= esc($r['name']) ?></span>
                            <div class="text-muted"><?= esc($r['description']) ?></div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
