<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-cart3 page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Buat Pembelian</h1>
        <p class="text-muted mb-0">Catat pesanan obat ke supplier</p>
    </div>
    <a href="<?= base_url('purchases') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali
    </a>
</div>

<form action="<?= base_url('purchases/store') ?>" method="post" id="purchaseForm">
    <?= csrf_field() ?>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body p-4">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">No. PO (otomatis)</label>
                    <input type="text" class="form-control" value="<?= esc($number) ?>" disabled>
                </div>
                <div class="col-md-4">
                    <label for="supplier_id" class="form-label">Supplier <span class="text-danger">*</span></label>
                    <select class="form-select" id="supplier_id" name="supplier_id" required>
                        <option value="">-- Pilih Supplier --</option>
                        <?php foreach ($suppliers as $supplier): ?>
                            <option value="<?= $supplier['id'] ?>" <?= (int) old('supplier_id') === (int) $supplier['id'] ? 'selected' : '' ?>>
                                <?= esc($supplier['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="order_date" class="form-label">Tanggal Pesan <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" id="order_date" name="order_date" required
                           value="<?= esc(old('order_date', date('Y-m-d'))) ?>">
                </div>
                <div class="col-md-12">
                    <label for="note" class="form-label">Catatan</label>
                    <input type="text" class="form-control" id="note" name="note" maxlength="255"
                           value="<?= esc(old('note', '')) ?>" placeholder="Opsional">
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <span class="fw-bold">Item Pembelian</span>
            <button type="button" class="btn btn-sm btn-outline-primary" id="addItem">
                <i class="bi bi-plus-lg"></i> Tambah Item
            </button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table align-middle" id="itemsTable">
                    <thead class="table-light">
                        <tr>
                            <th width="40">No</th>
                            <th style="min-width: 200px;">Obat <span class="text-danger">*</span></th>
                            <th width="110">Jumlah <span class="text-danger">*</span></th>
                            <th width="140">Harga/Satuan <span class="text-danger">*</span></th>
                            <th width="130">No. Batch</th>
                            <th width="150">Kedaluwarsa</th>
                            <th width="110" class="text-end">Subtotal</th>
                            <th width="50"></th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                    <tfoot>
                        <tr>
                            <td colspan="6" class="text-end fw-bold">Total</td>
                            <td class="text-end fw-bold" id="totalAmount">Rp 0</td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary fw-semibold">
        <i class="bi bi-save me-1"></i> Simpan Pembelian
    </button>
</form>

<template id="rowTemplate">
    <tr>
        <td class="row-no"></td>
        <td>
            <select name="item_drug_id[]" class="form-select form-select-sm item-drug" required>
                <option value="">-- Pilih --</option>
                <?php foreach ($drugs as $drug): ?>
                    <option value="<?= $drug['id'] ?>" data-price="<?= $drug['buy_price'] ?>" data-unit="<?= esc($drug['unit']) ?>">
                        <?= esc($drug['name']) ?> (<?= esc($drug['code']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </td>
        <td><input type="number" name="item_qty[]" class="form-control form-control-sm item-qty" min="0.01" step="0.01" required></td>
        <td><input type="number" name="item_price[]" class="form-control form-control-sm item-price" min="0" step="0.01" required></td>
        <td><input type="text" name="item_batch[]" class="form-control form-control-sm" maxlength="50" placeholder="Opsional"></td>
        <td><input type="date" name="item_expiry[]" class="form-control form-control-sm"></td>
        <td class="text-end item-subtotal">Rp 0</td>
        <td><button type="button" class="btn btn-sm btn-outline-danger remove-row"><i class="bi bi-x"></i></button></td>
    </tr>
</template>

<script>
const tbody = document.querySelector('#itemsTable tbody');
const template = document.getElementById('rowTemplate');

function recalc() {
    let total = 0;
    tbody.querySelectorAll('tr').forEach((tr, i) => {
        tr.querySelector('.row-no').textContent = i + 1;
        const qty = parseFloat(tr.querySelector('.item-qty').value) || 0;
        const price = parseFloat(tr.querySelector('.item-price').value) || 0;
        const sub = qty * price;
        tr.querySelector('.item-subtotal').textContent = 'Rp ' + sub.toLocaleString('id-ID');
        total += sub;
    });
    document.getElementById('totalAmount').textContent = 'Rp ' + total.toLocaleString('id-ID');
}

function addRow() {
    const clone = template.content.cloneNode(true);
    tbody.appendChild(clone);
    recalc();
}

document.getElementById('addItem').addEventListener('click', addRow);

tbody.addEventListener('click', (e) => {
    const btn = e.target.closest('.remove-row');
    if (btn) {
        btn.closest('tr').remove();
        recalc();
    }
});

tbody.addEventListener('change', (e) => {
    if (e.target.classList.contains('item-drug')) {
        const price = e.target.options[e.target.selectedIndex]?.dataset.price || '';
        e.target.closest('tr').querySelector('.item-price').value = price;
    }
    recalc();
});

tbody.addEventListener('input', recalc);

document.getElementById('purchaseForm').addEventListener('submit', (e) => {
    if (tbody.querySelectorAll('tr').length === 0) {
        e.preventDefault();
        alert('Minimal harus ada satu item pembelian.');
    }
});

addRow();
</script>
<?= $this->endSection() ?>
