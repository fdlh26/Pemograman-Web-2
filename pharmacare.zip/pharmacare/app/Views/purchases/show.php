<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-cart3 page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Detail Pembelian</h1>
        <p class="text-muted mb-0"><code><?= esc($purchase['purchase_number']) ?></code></p>
    </div>
    <div>
        <?php if ($purchase['status'] === 'ordered'): ?>
            <form action="<?= base_url('purchases/receive/' . $purchase['id']) ?>" method="post" class="d-inline"
                  onsubmit="return confirm('Terima pembelian ini? Stok dan nomor batch akan otomatis ditambahkan.')">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-success">
                    <i class="bi bi-box-arrow-in-down me-1"></i> Terima Barang
                </button>
            </form>
            <form action="<?= base_url('purchases/cancel/' . $purchase['id']) ?>" method="post" class="d-inline"
                  onsubmit="return confirm('Batalkan pembelian ini? Pembelian tidak dapat diproses kembali.')">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-outline-danger">
                    <i class="bi bi-x-circle me-1"></i> Batalkan
                </button>
            </form>
        <?php endif; ?>
        <a href="<?= base_url('purchases') ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="text-muted small">No. PO</div>
                <div class="fw-bold"><?= esc($purchase['purchase_number']) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="text-muted small">Supplier</div>
                <div class="fw-bold"><?= esc($supplier['name'] ?? '-') ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="text-muted small">Tanggal</div>
                <div class="fw-bold"><?= date('d/m/Y', strtotime($purchase['order_date'])) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="text-muted small">Status</div>
                <div>
                    <?php if ($purchase['status'] === 'ordered'): ?>
                        <span class="badge bg-warning text-dark">Dipesan</span>
                    <?php elseif ($purchase['status'] === 'received'): ?>
                        <span class="badge bg-success">Diterima</span>
                    <?php else: ?>
                        <span class="badge bg-secondary">Dibatalkan</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="text-muted small">Total</div>
                <div class="fw-bold">Rp <?= number_format((float) $purchase['total_amount'], 0, ',', '.') ?></div>
            </div>
        </div>
    </div>
</div>

<?php if (! empty($purchase['note'])): ?>
    <div class="alert alert-light border">
        <strong>Catatan:</strong> <?= esc($purchase['note']) ?>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-bold">Item Pembelian</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="50">No</th>
                        <th>Kode</th>
                        <th>Obat</th>
                        <th class="text-end">Jumlah</th>
                        <th class="text-end">Harga/Satuan</th>
                        <th class="text-end">Subtotal</th>
                        <th>No. Batch</th>
                        <th>Kedaluwarsa</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($items)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-3">Tidak ada item.</td></tr>
                    <?php else: ?>
                        <?php foreach ($items as $i => $item): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><code><?= esc($item['drug_code'] ?? '-') ?></code></td>
                                <td class="fw-semibold"><?= esc($item['drug_name'] ?? '-') ?></td>
                                <td class="text-end"><?= number_format((float) $item['quantity'], 2) ?> <?= esc($item['unit'] ?? '') ?></td>
                                <td class="text-end">Rp <?= number_format((float) $item['unit_price'], 0, ',', '.') ?></td>
                                <td class="text-end">Rp <?= number_format((float) $item['quantity'] * (float) $item['unit_price'], 0, ',', '.') ?></td>
                                <td><?= esc($item['batch_number'] ?? '-') ?></td>
                                <td>
                                    <?php if ($item['expiry_date']): ?>
                                        <?= date('d/m/Y', strtotime($item['expiry_date'])) ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
