<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-cart3 page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Pembelian Obat</h1>
        <p class="text-muted mb-0">Pesanan dan penerimaan obat dari supplier</p>
    </div>
    <a href="<?= base_url('purchases/create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i> Buat Pembelian
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= base_url('purchases') ?>" method="get" class="row g-2 mb-3">
            <div class="col-md-3">
                <select class="form-select" name="status">
                    <option value="">Semua Status</option>
                    <option value="ordered" <?= ($status ?? '') === 'ordered' ? 'selected' : '' ?>>Dipesan</option>
                    <option value="received" <?= ($status ?? '') === 'received' ? 'selected' : '' ?>>Diterima</option>
                    <option value="cancelled" <?= ($status ?? '') === 'cancelled' ? 'selected' : '' ?>>Dibatalkan</option>
                </select>
            </div>
            <div class="col-md-4">
                <input type="text" class="form-control" name="q" placeholder="Cari no. PO / supplier..." value="<?= esc($search ?? '') ?>">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-funnel"></i> Filter</button>
                <?php if (! empty($search) || ! empty($status)): ?>
                    <a href="<?= base_url('purchases') ?>" class="btn btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="60">No</th>
                        <th>No. PO</th>
                        <th>Tanggal</th>
                        <th>Supplier</th>
                        <th class="text-end">Total</th>
                        <th class="text-center">Status</th>
                        <th width="90">Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($purchases)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">Belum ada data pembelian. Klik "Buat Pembelian" untuk mencatat pesanan baru.</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = ($pager->getCurrentPage('purchases') - 1) * $pager->getPerPage('purchases') + 1; ?>
                        <?php foreach ($purchases as $purchase): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><code><?= esc($purchase['purchase_number']) ?></code></td>
                                <td><?= date('d/m/Y', strtotime($purchase['order_date'])) ?></td>
                                <td><?= esc($purchase['supplier_name'] ?? '-') ?></td>
                                <td class="text-end">Rp <?= number_format((float) $purchase['total_amount'], 0, ',', '.') ?></td>
                                <td class="text-center">
                                    <?php if ($purchase['status'] === 'ordered'): ?>
                                        <span class="badge bg-warning text-dark">Dipesan</span>
                                    <?php elseif ($purchase['status'] === 'received'): ?>
                                        <span class="badge bg-success">Diterima</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Dibatalkan</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?= base_url('purchases/' . $purchase['id']) ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye" title="Lihat detail"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= $pager->links('purchases') ?>
    </div>
</div>
<?= $this->endSection() ?>
