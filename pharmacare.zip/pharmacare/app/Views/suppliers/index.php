<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-truck page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Supplier</h1>
        <p class="text-muted mb-0">Kelola data pemasok obat</p>
    </div>
    <a href="<?= base_url('suppliers/create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i> Tambah
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= base_url('suppliers') ?>" method="get" class="row g-2 mb-3">
            <div class="col-md-5">
                <input type="text" class="form-control" name="q" placeholder="Cari nama / kontak / telepon..." value="<?= esc($search ?? '') ?>">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
                <?php if (! empty($search)): ?>
                    <a href="<?= base_url('suppliers') ?>" class="btn btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="60">No</th>
                        <th>Nama Supplier</th>
                        <th>Kontak Person</th>
                        <th>Telepon</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th width="160">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($suppliers)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">Belum ada data supplier. Klik "Tambah" untuk menambahkan supplier baru.</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = ($pager->getCurrentPage('suppliers') - 1) * $pager->getPerPage('suppliers') + 1; ?>
                        <?php foreach ($suppliers as $supplier): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td class="fw-semibold"><?= esc($supplier['name']) ?></td>
                                <td><?= esc($supplier['contact_person'] ?? '-') ?></td>
                                <td><?= esc($supplier['phone'] ?? '-') ?></td>
                                <td><?= esc($supplier['email'] ?? '-') ?></td>
                                <td>
                                    <?php if ((int) $supplier['is_active'] === 1): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?= base_url('suppliers/edit/' . $supplier['id']) ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil" title="Edit"></i>
                                    </a>
                                    <form action="<?= base_url('suppliers/delete/' . $supplier['id']) ?>" method="post" class="d-inline"
                                          onsubmit="return confirm('Hapus supplier ini? Data yang dihapus tidak dapat dikembalikan.')">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash" title="Hapus"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= $pager->links('suppliers') ?>
    </div>
</div>
<?= $this->endSection() ?>
