<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-truck page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1"><?= $supplier ? 'Edit' : 'Tambah' ?> Supplier</h1>
        <p class="text-muted mb-0"><?= $supplier ? 'Perbarui data supplier' : 'Tambah data supplier baru' ?></p>
    </div>
    <a href="<?= base_url('suppliers') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali
    </a>
</div>

<div class="card border-0 shadow-sm" style="max-width: 720px;">
    <div class="card-body p-4">
        <form action="<?= $supplier ? base_url('suppliers/update/' . $supplier['id']) : base_url('suppliers/store') ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-12">
                    <label for="name" class="form-label">Nama Supplier <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="name" name="name" required maxlength="150"
                           value="<?= esc(old('name', $supplier['name'] ?? '')) ?>" placeholder="PT. Contoh Farmasi">
                </div>
                <div class="col-md-6">
                    <label for="contact_person" class="form-label">Kontak Person</label>
                    <input type="text" class="form-control" id="contact_person" name="contact_person" maxlength="100"
                           value="<?= esc(old('contact_person', $supplier['contact_person'] ?? '')) ?>" placeholder="Nama narahubung">
                </div>
                <div class="col-md-6">
                    <label for="phone" class="form-label">Telepon</label>
                    <input type="text" class="form-control" id="phone" name="phone" maxlength="20"
                           value="<?= esc(old('phone', $supplier['phone'] ?? '')) ?>" placeholder="021-xxxxxxx">
                </div>
                <div class="col-md-6">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" maxlength="100"
                           value="<?= esc(old('email', $supplier['email'] ?? '')) ?>" placeholder="info@supplier.com">
                </div>
                <div class="col-md-6">
                    <label for="is_active" class="form-label">Status</label>
                    <select class="form-select" id="is_active" name="is_active">
                        <option value="1" <?= (int) old('is_active', $supplier['is_active'] ?? 1) === 1 ? 'selected' : '' ?>>Aktif</option>
                        <option value="0" <?= (int) old('is_active', $supplier['is_active'] ?? 1) === 0 ? 'selected' : '' ?>>Nonaktif</option>
                    </select>
                </div>
                <div class="col-md-12">
                    <label for="address" class="form-label">Alamat</label>
                    <textarea class="form-control" id="address" name="address" rows="3"
                              placeholder="Alamat lengkap supplier (opsional)"><?= esc(old('address', $supplier['address'] ?? '')) ?></textarea>
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Simpan
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
