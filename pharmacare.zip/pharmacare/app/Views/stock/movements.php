<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-arrow-left-right page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Riwayat Pergerakan Stok</h1>
        <p class="text-muted mb-0">Log stok masuk, keluar, dan penyesuaian</p>
    </div>
    <a href="<?= base_url('stock') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= base_url('stock/movements') ?>" method="get" class="row g-2 mb-3">
            <div class="col-md-3">
                <select class="form-select" name="type">
                    <option value="">Semua Jenis</option>
                    <option value="in" <?= ($type ?? '') === 'in' ? 'selected' : '' ?>>Stok Masuk</option>
                    <option value="out" <?= ($type ?? '') === 'out' ? 'selected' : '' ?>>Stok Keluar</option>
                    <option value="adjustment" <?= ($type ?? '') === 'adjustment' ? 'selected' : '' ?>>Penyesuaian</option>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-funnel"></i> Filter</button>
                <?php if (! empty($type)): ?>
                    <a href="<?= base_url('stock/movements') ?>" class="btn btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="50">No</th>
                        <th>Waktu</th>
                        <th>Obat</th>
                        <th class="text-center">Jenis</th>
                        <th class="text-end">Jumlah</th>
                        <th class="text-end">Sebelum</th>
                        <th class="text-end">Sesudah</th>
                        <th>Petugas</th>
                        <th>Catatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($movements)): ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted py-4">Belum ada pergerakan stok. Setiap transaksi stok akan tercatat otomatis di sini.</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = ($pager->getCurrentPage('movements') - 1) * $pager->getPerPage('movements') + 1; ?>
                        <?php foreach ($movements as $movement): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td class="text-muted"><?= date('d/m/Y H:i', strtotime($movement['created_at'])) ?></td>
                                <td class="fw-semibold"><?= esc($movement['drug_name'] ?? '-') ?></td>
                                <td class="text-center">
                                    <?php if ($movement['type'] === 'in'): ?>
                                        <span class="badge bg-success">Masuk</span>
                                    <?php elseif ($movement['type'] === 'out'): ?>
                                        <span class="badge bg-warning text-dark">Keluar</span>
                                    <?php else: ?>
                                        <span class="badge bg-info text-dark">Penyesuaian</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end"><?= number_format((float) $movement['quantity'], 2) ?> <?= esc($movement['unit'] ?? '') ?></td>
                                <td class="text-end"><?= number_format((float) $movement['stock_before'], 2) ?></td>
                                <td class="text-end fw-semibold"><?= number_format((float) $movement['stock_after'], 2) ?></td>
                                <td><?= esc($movement['user_name'] ?? '-') ?></td>
                                <td class="text-muted"><?= esc($movement['note'] ?? '-') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= $pager->links('movements') ?>
    </div>
</div>
<?= $this->endSection() ?>
