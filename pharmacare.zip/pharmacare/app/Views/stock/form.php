<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php
$labels = [
    'in'         => ['Stok Masuk', 'success', 'Tambah stok obat (penerimaan barang)'],
    'out'        => ['Stok Keluar', 'warning', 'Kurangi stok obat (pengeluaran / kerusakan)'],
    'adjustment' => ['Penyesuaian Stok', 'info', 'Atur ulang stok ke nilai yang benar'],
];
[$titleLabel, $color, $subtitle] = $labels[$type];
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-box-arrow-in-out page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1"><?= $titleLabel ?></h1>
        <p class="text-muted mb-0"><?= $subtitle ?></p>
    </div>
    <a href="<?= base_url('stock') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali
    </a>
</div>

<div class="card border-0 shadow-sm" style="max-width: 640px;">
    <div class="card-body p-4">
        <form action="<?= base_url('stock/store') ?>" method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="type" value="<?= esc($type) ?>">

            <div class="mb-3">
                <label for="drug_id" class="form-label">Obat <span class="text-danger">*</span></label>
                <select class="form-select" id="drug_id" name="drug_id" required>
                    <option value="">-- Pilih Obat --</option>
                    <?php foreach ($drugs as $d): ?>
                        <option value="<?= $d['id'] ?>"
                            data-stock="<?= $d['current_stock'] ?>"
                            data-unit="<?= esc($d['unit']) ?>"
                            <?= (int) old('drug_id', $drug['id'] ?? 0) === (int) $d['id'] ? 'selected' : '' ?>>
                            <?= esc($d['name']) ?> (<?= esc($d['code']) ?>) - Stok: <?= number_format((float) $d['current_stock'], 2) ?> <?= esc($d['unit']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <div class="form-text" id="currentStockInfo"></div>
            </div>

            <div class="mb-3">
                <label for="quantity" class="form-label">
                    <?= $type === 'adjustment' ? 'Stok Baru (nilai absolut)' : 'Jumlah' ?>
                    <span class="text-danger">*</span>
                </label>
                <input type="number" class="form-control" id="quantity" name="quantity" min="0.01" step="0.01" required
                       value="<?= esc(old('quantity', '')) ?>" placeholder="0">
                <?php if ($type === 'adjustment'): ?>
                    <div class="form-text">Masukkan total stok yang benar setelah penyesuaian.</div>
                <?php endif; ?>
            </div>

            <div class="mb-4">
                <label for="note" class="form-label">Catatan</label>
                <input type="text" class="form-control" id="note" name="note" maxlength="255"
                       value="<?= esc(old('note', '')) ?>" placeholder="Opsional, contoh: No. PO / no. surat jalan">
            </div>

            <button type="submit" class="btn btn-<?= $color ?> fw-semibold">
                <i class="bi bi-save me-1"></i> Simpan
            </button>
        </form>
    </div>
</div>

<script>
document.getElementById('drug_id').addEventListener('change', function () {
    const opt = this.options[this.selectedIndex];
    const info = document.getElementById('currentStockInfo');
    if (this.value) {
        info.textContent = 'Stok saat ini: ' + opt.dataset.stock + ' ' + opt.dataset.unit;
    } else {
        info.textContent = '';
    }
});
document.getElementById('drug_id').dispatchEvent(new Event('change'));
</script>
<?= $this->endSection() ?>
