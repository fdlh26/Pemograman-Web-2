<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-box-seam page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Stok Obat</h1>
        <p class="text-muted mb-0">Pantau ketersediaan stok obat</p>
    </div>
    <div>
        <a href="<?= base_url('stock/movements') ?>" class="btn btn-outline-secondary">
            <i class="bi bi-clock-history me-1"></i> Riwayat
        </a>
        <?php if (in_array(session()->get('userRole'), ['admin', 'apoteker', 'gudang'], true)): ?>
            <a href="<?= base_url('stock/form/in') ?>" class="btn btn-success">
                <i class="bi bi-box-arrow-in-down me-1"></i> Stok Masuk
            </a>
            <a href="<?= base_url('stock/form/out') ?>" class="btn btn-warning">
                <i class="bi bi-box-arrow-up me-1"></i> Stok Keluar
            </a>
        <?php endif; ?>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= base_url('stock') ?>" method="get" class="row g-2 mb-3">
            <div class="col-md-5">
                <input type="text" class="form-control" name="q" placeholder="Cari nama / kode obat..." value="<?= esc($search ?? '') ?>">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
                <?php if (! empty($search)): ?>
                    <a href="<?= base_url('stock') ?>" class="btn btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="60">No</th>
                        <th>Kode</th>
                        <th>Nama Obat</th>
                        <th>Kategori</th>
                        <th class="text-center">Stok</th>
                        <th class="text-center">Min. Stok</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($drugs)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">Belum ada data obat. Tambahkan obat melalui menu Data Obat.</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = ($pager->getCurrentPage('stock') - 1) * $pager->getPerPage('stock') + 1; ?>
                        <?php foreach ($drugs as $drug): ?>
                            <?php $status = $drugModel->getStockStatus($drug); ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><code><?= esc($drug['code']) ?></code></td>
                                <td class="fw-semibold"><?= esc($drug['name']) ?></td>
                                <td><?= esc($drug['category_name'] ?? '-') ?></td>
                                <td class="text-center fw-bold"><?= number_format((float) $drug['current_stock'], 2) ?> <?= esc($drug['unit']) ?></td>
                                <td class="text-center"><?= number_format((float) $drug['min_stock'], 2) ?></td>
                                <td>
                                    <?php if ($status === 'habis'): ?>
                                        <span class="badge bg-danger">Habis</span>
                                    <?php elseif ($status === 'menipis'): ?>
                                        <span class="badge bg-warning text-dark">Menipis</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Aman</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= $pager->links('stock') ?>
    </div>
</div>
<?= $this->endSection() ?>
