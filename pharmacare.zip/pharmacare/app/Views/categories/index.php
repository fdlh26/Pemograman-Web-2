<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-tags page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Kategori Obat</h1>
        <p class="text-muted mb-0">Kelola kategori/kelas obat</p>
    </div>
    <a href="<?= base_url('categories/create') ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i> Tambah
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= base_url('categories') ?>" method="get" class="row g-2 mb-3">
            <div class="col-md-5">
                <input type="text" class="form-control" name="q" placeholder="Cari kategori..." value="<?= esc($search ?? '') ?>">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
                <?php if (! empty($search)): ?>
                    <a href="<?= base_url('categories') ?>" class="btn btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="60">No</th>
                        <th>Nama Kategori</th>
                        <th>Deskripsi</th>
                        <th width="160">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($categories)): ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted py-4">Belum ada kategori. Klik "Tambah" untuk menambahkan kategori baru.</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = ($pager->getCurrentPage('categories') - 1) * $pager->getPerPage('categories') + 1; ?>
                        <?php foreach ($categories as $category): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td class="fw-semibold"><?= esc($category['name']) ?></td>
                                <td class="text-muted"><?= esc($category['description'] ?? '-') ?></td>
                                <td>
                                    <a href="<?= base_url('categories/edit/' . $category['id']) ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil" title="Edit"></i> Edit
                                    </a>
                                    <form action="<?= base_url('categories/delete/' . $category['id']) ?>" method="post" class="d-inline"
                                          onsubmit="return confirm('Hapus kategori ini? Data yang dihapus tidak dapat dikembalikan.')">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash" title="Hapus"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= $pager->links('categories') ?>
    </div>
</div>
<?= $this->endSection() ?>
