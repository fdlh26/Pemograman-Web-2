<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-tags page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1"><?= $category ? 'Edit' : 'Tambah' ?> Kategori</h1>
        <p class="text-muted mb-0"><?= $category ? 'Perbarui data kategori' : 'Tambah kategori obat baru' ?></p>
    </div>
    <a href="<?= base_url('categories') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali
    </a>
</div>

<div class="card border-0 shadow-sm" style="max-width: 640px;">
    <div class="card-body p-4">
        <form action="<?= $category ? base_url('categories/update/' . $category['id']) : base_url('categories/store') ?>" method="post">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label for="name" class="form-label">Nama Kategori <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="name" name="name" required maxlength="100"
                       value="<?= esc(old('name', $category['name'] ?? '')) ?>" placeholder="Contoh: Analgesik">
            </div>
            <div class="mb-4">
                <label for="description" class="form-label">Deskripsi</label>
                <textarea class="form-control" id="description" name="description" rows="3" maxlength="255"
                          placeholder="Deskripsi singkat kategori (opsional)"><?= esc(old('description', $category['description'] ?? '')) ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-save me-1"></i> Simpan
            </button>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
