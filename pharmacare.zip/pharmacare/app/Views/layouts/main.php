<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'PharmaCare') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* ============================================================
           PharmaCare Design System
           Bootstrap 5.3 token overrides — konsisten di seluruh app
           ============================================================ */
        :root {
            --sidebar-width: 260px;
            --brand-900: #022c22;
            --brand-800: #064e3b;
            --brand-700: #047857;
            --brand-600: #059669;
            --brand-500: #10b981;
            --brand-400: #34d399;
            --brand-100: #d1fae5;
            --brand-50:  #ecfdf5;

            /* warna primer aplikasi (teal) menggantikan biru bawaan */
            --bs-primary: #047857;
            --bs-primary-rgb: 4, 120, 87;
            --bs-primary-bg-subtle: #ecfdf5;
            --bs-primary-border-subtle: #a7f3d0;
            --bs-primary-text-emphasis: #065f46;

            /* radius global */
            --bs-border-radius: 0.6rem;
            --bs-border-radius-sm: 0.45rem;
            --bs-border-radius-lg: 0.85rem;
            --bs-border-radius-xl: 1rem;

            /* tipografi */
            --bs-body-font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', sans-serif;
            --bs-body-color: #1e293b;
            --bs-body-font-size: 1rem;
            --bs-body-line-height: 1.55;

            /* link & fokus */
            --bs-link-color: #047857;
            --bs-link-hover-color: #065f46;
            --bs-focus-ring-color: rgba(16, 185, 129, 0.35);

            --bs-emphasis-color: #022c22;
        }

        * { font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', sans-serif; }
        body {
            min-height: 100vh;
            background: #f1f5f9;
            color: #1e293b;
            line-height: 1.55;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            text-rendering: optimizeLegibility;
        }
        h1, h2, h3, h4, h5, h6 { letter-spacing: -0.02em; color: #022c22; }
        a { text-underline-offset: 2px; }
        hr { border-color: #e2e8f0; }

        /* ---------- Header halaman (judul + subjudul) ---------- */
        .main-content h1 {
            font-size: 1.55rem;
            font-weight: 800;
            color: #022c22;
        }
        .main-content h1 + p { font-size: 0.92rem; color: #64748b !important; }

        /* ---------- Page head: ikon + judul ---------- */
        .page-head {
            display: grid;
            grid-template-columns: auto minmax(0, 1fr);
            column-gap: 1rem;
            align-items: center;
        }
        .page-head .page-icon {
            grid-column: 1;
            grid-row: 1 / span 2;
            width: 52px;
            height: 52px;
            border-radius: 0.9rem;
            background: linear-gradient(135deg, var(--brand-700) 0%, var(--brand-500) 100%);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.45rem;
            box-shadow: 0 12px 24px -12px rgba(4, 120, 87, 0.55);
        }
        .page-head h1 { grid-column: 2; grid-row: 1; }
        .page-head p { grid-column: 2; grid-row: 2; }
        @media (max-width: 575.98px) {
            .page-head .page-icon { width: 44px; height: 44px; font-size: 1.2rem; border-radius: 0.75rem; }
        }

        /* ---------- Kartu ---------- */
        .card {
            border: 1px solid #e8eef5 !important;
            border-radius: 1rem !important;
            box-shadow: 0 1px 2px rgba(2, 44, 34, 0.04), 0 14px 32px -18px rgba(2, 44, 34, 0.18) !important;
        }
        .card-header {
            background: #f8fafc;
            border-bottom: 1px solid #eef2f7;
            font-weight: 700;
            color: #022c22;
        }

        /* ---------- Tombol ---------- */
        .btn {
            border-radius: 0.6rem;
            font-weight: 600;
            font-size: 0.9rem;
            letter-spacing: 0.01em;
        }
        .btn-sm { font-size: 0.82rem; }
        .btn-primary {
            --bs-btn-bg: #047857; --bs-btn-border-color: #047857;
            --bs-btn-hover-bg: #065f46; --bs-btn-hover-border-color: #065f46;
            --bs-btn-active-bg: #022c22; --bs-btn-active-border-color: #022c22;
            --bs-btn-disabled-bg: #a7d8c8; --bs-btn-disabled-border-color: #a7d8c8;
            box-shadow: 0 8px 18px -8px rgba(4, 120, 87, 0.45);
        }
        .btn-outline-primary {
            --bs-btn-color: #047857; --bs-btn-border-color: #047857;
            --bs-btn-hover-bg: #047857; --bs-btn-hover-border-color: #047857;
            --bs-btn-active-bg: #065f46; --bs-btn-active-border-color: #065f46;
            --bs-btn-active-color: #fff;
        }

        /* ---------- Form ---------- */
        .form-label {
            font-size: 0.86rem;
            font-weight: 600;
            color: #334155;
            margin-bottom: 0.35rem;
        }
        .form-control, .form-select {
            font-size: 0.93rem;
            color: #0f172a;
            border-color: #e2e8f0;
            border-radius: 0.6rem;
        }
        .form-control::placeholder { color: #94a3b8; }
        .form-control:focus, .form-select:focus {
            border-color: #10b981;
            box-shadow: 0 0 0 0.2rem rgba(16, 185, 129, 0.15);
        }
        .input-group-text {
            font-size: 0.93rem;
            color: #94a3b8;
            border-color: #e2e8f0;
            background: #f8fafc;
        }
        .form-check-input:checked {
            background-color: #047857;
            border-color: #047857;
        }

        /* ---------- Tabel ---------- */
        .table {
            color: #334155;
            --bs-table-striped-bg: #f8fafc;
            --bs-table-hover-bg: #f1f5f9;
        }
        .table > :not(caption) > * > * {
            background: transparent;
            padding: 0.75rem 0.85rem;
            vertical-align: middle;
        }
        .table thead th {
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #475569;
            font-weight: 700;
            border-bottom: 2px solid #e2e8f0;
        }
        .table tbody td { font-variant-numeric: tabular-nums; }
        .table-light { --bs-table-bg: #f8fafc; --bs-table-color: #475569; }
        code {
            background: #ecfdf5;
            color: #065f46;
            padding: 0.15em 0.45em;
            border-radius: 0.35rem;
            font-size: 0.82em;
            font-weight: 500;
        }

        /* ---------- Badge ---------- */
        .badge { font-weight: 600; letter-spacing: 0.02em; padding: 0.4em 0.7em; }

        /* ---------- Alert ---------- */
        .alert {
            border: 0;
            border-left: 4px solid;
            border-radius: 0.75rem;
            font-size: 0.92rem;
            font-weight: 500;
        }
        .alert-success { border-left-color: #10b981; background: #ecfdf5; color: #065f46; }
        .alert-danger  { border-left-color: #ef4444; background: #fef2f2; color: #991b1b; }
        .alert-warning { border-left-color: #f59e0b; background: #fffbeb; color: #92400e; }
        .alert-info    { border-left-color: #0ea5e9; background: #f0f9ff; color: #075985; }

        /* ---------- Pagination ---------- */
        .pagination .page-link {
            border-radius: 0.5rem;
            margin: 0 3px;
            font-size: 0.86rem;
            font-weight: 600;
            color: #334155;
            border-color: #e2e8f0;
        }
        .pagination .page-item.active .page-link {
            background: #047857;
            border-color: #047857;
            color: #fff;
        }
        .pagination .page-item.disabled .page-link { color: #cbd5e1; }

        /* ---------- Nav pills (tab laporan dsb.) ---------- */
        .nav-pills .nav-link {
            color: #475569;
            font-weight: 600;
            font-size: 0.88rem;
            border-radius: 0.6rem;
            padding: 0.5rem 0.95rem;
            display: inline-flex;
            align-items: center;
        }
        .nav-pills .nav-link:hover { background: #eef2f7; color: #022c22; }
        .nav-pills .nav-link.active {
            background: linear-gradient(135deg, var(--brand-700), var(--brand-500));
            color: #fff;
            box-shadow: 0 8px 16px -8px rgba(4, 120, 87, 0.5);
        }

        /* ---------- Card header section ---------- */
        .card-header {
            background: #f8fafc !important;
            border-bottom: 1px solid #eef2f7;
            font-weight: 700;
            color: #022c22;
            font-size: 0.93rem;
            padding: 0.9rem 1.25rem;
        }

        /* ---------- Form section label ---------- */
        .form-section {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #64748b;
            margin-bottom: 0.9rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .form-section::after {
            content: "";
            flex: 1;
            height: 1px;
            background: #e2e8f0;
        }

        /* ---------- Print (laporan & struk) ---------- */
        @media print {
            .sidebar, .topbar, .no-print, .pagination { display: none !important; }
            .main-content { margin-left: 0 !important; }
            .main-content > .p-4 { padding: 0 !important; animation: none !important; }
            body { background: #fff !important; font-size: 11pt; }
            .card {
                border: 1px solid #dee2e6 !important;
                box-shadow: none !important;
                break-inside: avoid;
            }
            .card-header { background: #f8f9fa !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .table thead th { background: #f1f5f9; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            h1, h2, h3 { color: #000 !important; }
        }

        /* ---------- Konten ---------- */
        .main-content > .p-4 { animation: pcFadeIn 0.3s ease; }
        @keyframes pcFadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
        @media (prefers-reduced-motion: reduce) {
            .main-content > .p-4 { animation: none; }
        }

        /* ---------- Sidebar ---------- */
        .sidebar {
            width: var(--sidebar-width);
            min-height: 100vh;
            background:
                radial-gradient(420px 260px at 90% 0%, rgba(16, 185, 129, 0.18), transparent 55%),
                linear-gradient(180deg, var(--brand-900) 0%, var(--brand-800) 100%);
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
            overflow-y: auto;
        }
        .sidebar .brand {
            padding: 1.3rem 1.5rem;
            color: #fff;
            font-size: 1.2rem;
            font-weight: 800;
            letter-spacing: -0.3px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        .sidebar .brand i {
            width: 38px; height: 38px;
            border-radius: 0.7rem;
            background: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.18);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.15rem;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.88);
            padding: 0.68rem 1.5rem;
            border-left: 3px solid transparent;
            font-size: 0.92rem;
            font-weight: 500;
            transition: all 0.18s;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: #fff;
            background: rgba(255, 255, 255, 0.10);
            border-left-color: var(--brand-400);
        }
        .sidebar .nav-link i {
            width: 1.5rem;
            text-align: center;
            margin-right: 0.5rem;
            opacity: 0.9;
        }
        .sidebar .text-uppercase {
            color: rgba(255, 255, 255, 0.55) !important;
            font-size: 0.68rem !important;
            font-weight: 700 !important;
            letter-spacing: 0.08em;
        }
        .sidebar::-webkit-scrollbar { width: 6px; }
        .sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.18); border-radius: 3px; }

        /* ---------- Topbar & area utama ---------- */
        .main-content {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
        }
        .topbar {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(8px);
            padding: 0.9rem 1.5rem;
            border-bottom: 1px solid #e2e8f0;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        @media (max-width: 991.98px) {
            .sidebar { margin-left: calc(-1 * var(--sidebar-width)); }
            .sidebar.show { margin-left: 0; }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>
    <nav class="sidebar" id="sidebar">
        <div class="brand">
            <i class="bi bi-capsule-pill"></i> PharmaCare
        </div>
        <?php $userRole = session()->get('userRole'); ?>
        <ul class="nav flex-column mt-2">
            <li class="nav-item">
                <a class="nav-link <?= uri_string() === 'dashboard' ? 'active' : '' ?>" href="<?= base_url('dashboard') ?>">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item mt-3">
                <div class="px-3 pb-1 text-uppercase small text-secondary">Manajemen Obat</div>
            </li>
            <?php if ($userRole === 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link <?= str_starts_with(uri_string(), 'categories') ? 'active' : '' ?>" href="<?= base_url('categories') ?>">
                        <i class="bi bi-tags"></i> Kategori Obat
                    </a>
                </li>
            <?php endif; ?>
            <?php if (in_array($userRole, ['admin', 'apoteker', 'gudang', 'dokter', 'ttk', 'kepala_farmasi'], true)): ?>
                <li class="nav-item">
                    <a class="nav-link <?= str_starts_with(uri_string(), 'drugs') ? 'active' : '' ?>" href="<?= base_url('drugs') ?>">
                        <i class="bi bi-capsule"></i> Data Obat
                    </a>
                </li>
            <?php endif; ?>
            <?php if (in_array($userRole, ['admin', 'apoteker', 'gudang', 'kepala_farmasi'], true)): ?>
                <li class="nav-item">
                    <a class="nav-link <?= str_starts_with(uri_string(), 'stock') ? 'active' : '' ?>" href="<?= base_url('stock') ?>">
                        <i class="bi bi-box-seam"></i> Stok Obat
                    </a>
                </li>
            <?php endif; ?>
            <?php if (in_array($userRole, ['admin', 'apoteker', 'gudang', 'kepala_farmasi'], true)): ?>
                <li class="nav-item mt-3">
                    <div class="px-3 pb-1 text-uppercase small text-secondary">Pembelian</div>
                </li>
                <?php if (in_array($userRole, ['admin', 'gudang', 'kepala_farmasi'], true)): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= str_starts_with(uri_string(), 'suppliers') ? 'active' : '' ?>" href="<?= base_url('suppliers') ?>">
                            <i class="bi bi-truck"></i> Supplier
                        </a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link <?= str_starts_with(uri_string(), 'purchases') ? 'active' : '' ?>" href="<?= base_url('purchases') ?>">
                        <i class="bi bi-cart3"></i> Pembelian Obat
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= str_starts_with(uri_string(), 'expiry') ? 'active' : '' ?>" href="<?= base_url('expiry') ?>">
                        <i class="bi bi-calendar-x"></i> Kedaluwarsa
                    </a>
                </li>
            <?php endif; ?>
            <?php if (in_array($userRole, ['admin', 'dokter', 'apoteker', 'ttk', 'pendaftaran'], true)): ?>
                <li class="nav-item mt-3">
                    <div class="px-3 pb-1 text-uppercase small text-secondary">Pelayanan</div>
                </li>
                <?php if (in_array($userRole, ['admin', 'pendaftaran', 'dokter', 'apoteker', 'ttk'], true)): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= str_starts_with(uri_string(), 'patients') ? 'active' : '' ?>" href="<?= base_url('patients') ?>">
                            <i class="bi bi-people"></i> Pasien
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (in_array($userRole, ['admin', 'dokter', 'apoteker', 'ttk'], true)): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= str_starts_with(uri_string(), 'prescriptions') ? 'active' : '' ?>" href="<?= base_url('prescriptions') ?>">
                            <i class="bi bi-file-earmark-medical"></i> Resep
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (in_array($userRole, ['admin', 'kasir', 'kepala_farmasi', 'manajemen'], true)): ?>
                <li class="nav-item mt-3">
                    <div class="px-3 pb-1 text-uppercase small text-secondary">Penjualan</div>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= str_starts_with(uri_string(), 'transactions') ? 'active' : '' ?>" href="<?= base_url('transactions') ?>">
                        <i class="bi bi-receipt-cutoff"></i> Transaksi
                    </a>
                </li>
            <?php endif; ?>
            <?php if (in_array($userRole, ['admin', 'apoteker', 'ttk', 'kasir'], true)): ?>
                <li class="nav-item mt-3">
                    <div class="px-3 pb-1 text-uppercase small text-secondary">Antrean</div>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= str_starts_with(uri_string(), 'queue') && !str_contains(uri_string(), 'display') ? 'active' : '' ?>" href="<?= base_url('queue') ?>">
                        <i class="bi bi-people-clock"></i> Pengambilan Obat
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('queue/display') ?>" target="_blank">
                        <i class="bi bi-tv"></i> Layar Monitor
                    </a>
                </li>
            <?php endif; ?>
            <?php if (in_array($userRole, ['admin', 'kepala_farmasi', 'manajemen'], true)): ?>
                <li class="nav-item mt-3">
                    <div class="px-3 pb-1 text-uppercase small text-secondary">Laporan</div>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= str_starts_with(uri_string(), 'reports') ? 'active' : '' ?>" href="<?= base_url('reports') ?>">
                        <i class="bi bi-graph-up"></i> Laporan Farmasi
                    </a>
                </li>
            <?php endif; ?>
            <?php if (in_array($userRole, ['admin', 'kepala_farmasi', 'manajemen'], true)): ?>
                <li class="nav-item mt-3">
                    <div class="px-3 pb-1 text-uppercase small text-secondary">Sistem</div>
                </li>
                <?php if ($userRole === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= str_starts_with(uri_string(), 'users') ? 'active' : '' ?>" href="<?= base_url('users') ?>">
                            <i class="bi bi-people-fill"></i> Pengguna
                        </a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link <?= str_starts_with(uri_string(), 'audit') ? 'active' : '' ?>" href="<?= base_url('audit') ?>">
                        <i class="bi bi-clock-history"></i> Riwayat Aktivitas
                    </a>
                </li>
            <?php endif; ?>
            <li class="nav-item mt-3">
                <div class="px-3 pb-1 text-uppercase small text-secondary">Akun</div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('logout') ?>" onclick="return confirm('Keluar dari aplikasi PharmaCare?')">
                    <i class="bi bi-box-arrow-left"></i> Logout
                </a>
            </li>
        </ul>
    </nav>

    <div class="main-content">
        <div class="topbar d-flex justify-content-between align-items-center">
            <button class="btn btn-outline-secondary d-lg-none" type="button" onclick="document.getElementById('sidebar').classList.toggle('show')">
                <i class="bi bi-list"></i>
            </button>
            <div class="ms-auto d-flex align-items-center gap-3">
                <div class="text-end">
                    <div class="fw-bold" style="font-size:.95rem"><?= esc($userName ?? '') ?></div>
                    <small class="text-uppercase fw-semibold" style="font-size:.68rem; letter-spacing:.06em; color:#64748b">
                        <?= str_replace('_', ' ', esc($userRole ?? '')) ?>
                    </small>
                </div>
                <a href="<?= base_url('logout') ?>" class="btn btn-outline-danger btn-sm"
                   onclick="return confirm('Keluar dari aplikasi PharmaCare?')" title="Keluar dari sistem">
                    <i class="bi bi-box-arrow-right me-1"></i> Logout
                </a>
            </div>
        </div>

        <div class="p-4">
            <?= $this->render('system/message') ?>
            <?= $this->renderSection('content') ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
