<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Login - PharmaCare') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --g-950: #022c22;
            --g-900: #064e3b;
            --g-700: #047857;
            --g-500: #10b981;
            --g-400: #34d399;
            --g-300: #6ee7b7;
        }
        * { font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', sans-serif; }
        body {
            min-height: 100vh;
            background:
                radial-gradient(900px 480px at 12% -8%, rgba(16, 185, 129, 0.14), transparent 55%),
                radial-gradient(760px 420px at 108% 108%, rgba(4, 120, 87, 0.12), transparent 50%),
                #0b1220;
        }

        .page { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 2rem 1rem; }
        .shell {
            width: 100%;
            max-width: 1000px;
            display: grid;
            grid-template-columns: 1.05fr 1fr;
            background: #fff;
            border-radius: 1.4rem;
            overflow: hidden;
            box-shadow:
                0 30px 80px -20px rgba(2, 44, 34, 0.55),
                0 12px 28px rgba(2, 44, 34, 0.25);
            opacity: 0;
            transform: translateY(16px) scale(.985);
            animation: shellIn .55s cubic-bezier(.22, .9, .3, 1) forwards;
        }
        @keyframes shellIn { to { opacity: 1; transform: none; } }
        @media (prefers-reduced-motion: reduce) { .shell { animation: none; opacity: 1; transform: none; } }
        @media (max-width: 920px) {
            .shell { grid-template-columns: 1fr; max-width: 440px; }
            .side-brand { display: none; }
        }

        /* Brand */
        .side-brand {
            position: relative;
            color: #fff;
            padding: 3.2rem 2.8rem;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background:
                radial-gradient(520px 320px at 85% 12%, rgba(52, 211, 153, 0.28), transparent 60%),
                linear-gradient(155deg, var(--g-950) 0%, var(--g-900) 52%, var(--g-700) 100%);
            isolation: isolate;
        }
        .side-brand::before {
            content: "";
            position: absolute; inset: 0; z-index: -1;
            background-image:
                linear-gradient(rgba(255,255,255,0.045) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.045) 1px, transparent 1px);
            background-size: 34px 34px;
            mask-image: radial-gradient(circle at 30% 20%, #000 20%, transparent 75%);
        }
        .pill {
            display: inline-flex; align-items: center; gap: .45rem;
            font-size: .7rem; font-weight: 600; letter-spacing: .09em; text-transform: uppercase;
            color: var(--g-300);
            background: rgba(16, 185, 129, 0.12);
            border: 1px solid rgba(110, 231, 183, 0.28);
            padding: .4rem .8rem;
            border-radius: 999px;
            width: fit-content;
        }
        .brand-logo {
            width: 58px; height: 58px;
            border-radius: 1.05rem;
            background: linear-gradient(140deg, rgba(255,255,255,0.16), rgba(255,255,255,0.05));
            border: 1px solid rgba(255,255,255,0.2);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.75rem;
            box-shadow: 0 14px 34px rgba(0,0,0,0.25);
            margin: 1.6rem 0 1.2rem;
        }
        .brand-h {
            font-size: clamp(1.9rem, 2.8vw, 2.35rem);
            font-weight: 800; letter-spacing: -0.6px;
            margin: 0 0 .4rem;
        }
        .brand-p { color: rgba(255,255,255,0.68); font-size: .95rem; margin: 0; }
        .checks { list-style: none; padding: 0; margin: 2.4rem 0 0; display: grid; gap: .9rem; }
        .checks li { display: flex; gap: .75rem; align-items: center; font-size: .92rem; font-weight: 500; color: rgba(255,255,255,0.88); }
        .checks .tick {
            width: 22px; height: 22px; border-radius: 50%;
            background: rgba(16, 185, 129, 0.18);
            border: 1px solid rgba(110, 231, 183, 0.4);
            color: var(--g-400);
            display: flex; align-items: center; justify-content: center;
            font-size: .72rem; flex: 0 0 auto;
        }

        /* Form */
        .side-form { padding: 3.2rem 3rem; display: flex; flex-direction: column; justify-content: center; }
        .form-head h1 { font-size: 1.55rem; font-weight: 800; letter-spacing: -0.5px; margin: 0 0 1.8rem; }

        .form-floating > .form-control { border: 1px solid #e2e8f0; background: #f8fafc; border-radius: .65rem; }
        .form-floating > .form-control:focus { border-color: var(--g-500); background: #fff; }
        .form-floating > label { color: #64748b; }
        .input-group .input-group-text {
            background: #f8fafc; border: 1px solid #e2e8f0; color: #94a3b8; border-radius: .65rem;
        }
        .input-group .form-control { border-radius: .65rem; }
        .btn-eye { background: #f8fafc; border: 1px solid #e2e8f0; color: #94a3b8; border-radius: .65rem; }
        .btn-eye:hover { color: var(--g-700); border-color: var(--g-300); background: #ecfdf5; }

        .btn-submit {
            border: none;
            font-weight: 600;
            background: linear-gradient(135deg, var(--g-700), var(--g-500));
            border-radius: .7rem;
            padding: .8rem 1rem;
            box-shadow: 0 12px 26px rgba(4, 120, 87, 0.32);
            transition: transform .15s ease, box-shadow .15s ease, filter .15s ease;
        }
        .btn-submit:hover { transform: translateY(-1px); filter: brightness(1.05); box-shadow: 0 16px 30px rgba(4, 120, 87, 0.4); }
        .btn-submit:active { transform: none; }
        .btn-submit[disabled] { opacity: .85; transform: none; filter: none; }
        .spinner-border-sm { width: .95rem; height: .95rem; }

        .side-note {
            margin-top: 1.5rem; padding-top: 1.1rem; border-top: 1px solid #f1f5f9;
            font-size: .78rem; color: #94a3b8;
            display: flex; align-items: center; justify-content: space-between; gap: .75rem; flex-wrap: wrap;
        }
        .secure {
            display: inline-flex; align-items: center; gap: .4rem;
            background: #ecfdf5; color: #047857; border: 1px solid #a7f3d0;
            font-weight: 600; font-size: .72rem;
            padding: .3rem .7rem; border-radius: 999px;
        }
    </style>
</head>
<body>
<div class="page">
    <main class="shell" role="main">

        <!-- Brand -->
        <aside class="side-brand">
            <span class="pill"><i class="bi bi-stars"></i> Sistem Informasi Farmasi</span>
            <div class="brand-logo"><i class="bi bi-capsule-pill"></i></div>
            <h2 class="brand-h">PharmaCare</h2>
            <p class="brand-p">Manajemen apotek &amp; farmasi terintegrasi.</p>

            <ul class="checks">
                <li><span class="tick"><i class="bi bi-check-lg"></i></span> Stok presisi dengan FEFO</li>
                <li><span class="tick"><i class="bi bi-check-lg"></i></span> Alur resep end-to-end</li>
                <li><span class="tick"><i class="bi bi-check-lg"></i></span> Laporan &amp; audit trail</li>
            </ul>
        </aside>

        <!-- Form -->
        <section class="side-form">
            <div class="form-head">
                <h1>Masuk</h1>
            </div>

            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show py-2 small" role="alert">
                    <i class="bi bi-check-circle me-1"></i><?= session()->getFlashdata('success') ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show py-2 small" role="alert">
                    <i class="bi bi-exclamation-triangle me-1"></i><?= session()->getFlashdata('error') ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php $errors = session()->get('errors'); ?>
            <?php if (is_array($errors) && $errors !== []): ?>
                <div class="alert alert-danger alert-dismissible fade show py-2 small" role="alert">
                    <ul class="mb-0 ps-3">
                        <?php foreach ($errors as $error): ?>
                            <li><?= esc($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form action="<?= base_url('login') ?>" method="post" id="loginForm" autocomplete="on">
                <?= csrf_field() ?>

                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="username" name="username"
                           placeholder="Username" value="<?= esc(old('username')) ?>"
                           autocomplete="username" required autofocus>
                    <label for="username"><i class="bi bi-person me-1"></i>Username</label>
                </div>

                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" class="form-control" id="password" name="password"
                           placeholder="Password" autocomplete="current-password" required>
                    <button class="btn btn-eye" type="button" id="togglePassword" aria-label="Tampilkan password">
                        <i class="bi bi-eye"></i>
                    </button>
                </div>

                <button type="submit" class="btn btn-submit btn-primary w-100" id="btnSubmit">
                    <span class="d-inline-flex align-items-center" id="btnIdle">
                        <i class="bi bi-box-arrow-in-right me-2"></i>Masuk
                    </span>
                    <span class="d-none align-items-center" id="btnLoading">
                        <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        Memverifikasi...
                    </span>
                </button>
            </form>

            <div class="side-note">
                <span class="secure"><i class="bi bi-shield-lock"></i> Sesi aman</span>
                <span>Lupa password? Hubungi admin.</span>
            </div>
        </section>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('togglePassword').addEventListener('click', function () {
        const input = document.getElementById('password');
        const icon = this.querySelector('i');
        const show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        icon.classList.toggle('bi-eye', !show);
        icon.classList.toggle('bi-eye-slash', show);
    });

    document.getElementById('loginForm').addEventListener('submit', function (e) {
        const btn = document.getElementById('btnSubmit');
        if (btn.disabled) { e.preventDefault(); return; }
        btn.disabled = true;
        document.getElementById('btnIdle').classList.replace('d-inline-flex', 'd-none');
        document.getElementById('btnLoading').classList.replace('d-none', 'd-inline-flex');
    });
</script>
</body>
</html>
