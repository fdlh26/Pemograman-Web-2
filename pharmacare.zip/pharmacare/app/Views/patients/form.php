<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-person-plus page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1"><?= $patient ? 'Edit' : 'Tambah' ?> Pasien</h1>
        <p class="text-muted mb-0"><?= $patient ? 'Perbarui data pasien' : 'Daftarkan pasien baru' ?></p>
    </div>
    <a href="<?= base_url('patients') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali
    </a>
</div>

<div class="card border-0 shadow-sm" style="max-width: 720px;">
    <div class="card-body p-4">
        <form action="<?= $patient ? base_url('patients/update/' . $patient['id']) : base_url('patients/store') ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-4">
                    <label for="rm_number" class="form-label">No. Rekam Medis <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="rm_number" name="rm_number" required maxlength="20"
                           value="<?= esc(old('rm_number', $rm)) ?>" <?= $patient ? '' : 'readonly' ?>>
                    <?php if (! $patient): ?>
                        <div class="form-text">Nomor otomatis, boleh diubah.</div>
                    <?php endif; ?>
                </div>
                <div class="col-md-8">
                    <label for="name" class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="name" name="name" required maxlength="150"
                           value="<?= esc(old('name', $patient['name'] ?? '')) ?>" placeholder="Nama pasien">
                </div>
                <div class="col-md-4">
                    <label class="form-label d-block">Jenis Kelamin <span class="text-danger">*</span></label>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="genderL" value="L"
                               <?= old('gender', $patient['gender'] ?? '') === 'L' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="genderL">Laki-laki</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="genderP" value="P"
                               <?= old('gender', $patient['gender'] ?? '') === 'P' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="genderP">Perempuan</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <label for="birth_date" class="form-label">Tanggal Lahir</label>
                    <input type="date" class="form-control" id="birth_date" name="birth_date"
                           value="<?= esc(old('birth_date', $patient['birth_date'] ?? '')) ?>">
                </div>
                <div class="col-md-4">
                    <label for="phone" class="form-label">Telepon</label>
                    <input type="text" class="form-control" id="phone" name="phone" maxlength="20"
                           value="<?= esc(old('phone', $patient['phone'] ?? '')) ?>" placeholder="08xxxxxxxxxx">
                </div>
                <div class="col-md-12">
                    <label for="address" class="form-label">Alamat</label>
                    <textarea class="form-control" id="address" name="address" rows="3"
                              placeholder="Alamat lengkap pasien (opsional)"><?= esc(old('address', $patient['address'] ?? '')) ?></textarea>
                </div>
            </div>
            <div class="mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save me-1"></i> Simpan
                </button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
