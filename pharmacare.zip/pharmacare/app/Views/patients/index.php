<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-people page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Data Pasien</h1>
        <p class="text-muted mb-0">Kelola data pasien</p>
    </div>
    <?php if (in_array(session()->get('userRole'), ['admin', 'pendaftaran'], true)): ?>
        <a href="<?= base_url('patients/create') ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Tambah
        </a>
    <?php endif; ?>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= base_url('patients') ?>" method="get" class="row g-2 mb-3">
            <div class="col-md-5">
                <input type="text" class="form-control" name="q" placeholder="Cari nama / no. RM / telepon..." value="<?= esc($search ?? '') ?>">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i></button>
                <?php if (! empty($search)): ?>
                    <a href="<?= base_url('patients') ?>" class="btn btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="50">No</th>
                        <th>No. RM</th>
                        <th>Nama</th>
                        <th class="text-center">JK</th>
                        <th>Tgl. Lahir</th>
                        <th>Telepon</th>
                        <th width="160">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($patients)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">Belum ada data pasien. Klik "Tambah" untuk mendaftarkan pasien baru.</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = ($pager->getCurrentPage('patients') - 1) * $pager->getPerPage('patients') + 1; ?>
                        <?php foreach ($patients as $patient): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><code><?= esc($patient['rm_number']) ?></code></td>
                                <td class="fw-semibold"><?= esc($patient['name']) ?></td>
                                <td class="text-center"><?= esc($patient['gender']) ?></td>
                                <td><?= $patient['birth_date'] ? date('d/m/Y', strtotime($patient['birth_date'])) : '-' ?></td>
                                <td><?= esc($patient['phone'] ?? '-') ?></td>
                                <td>
                                    <?php if (in_array(session()->get('userRole'), ['admin', 'pendaftaran'], true)): ?>
                                        <a href="<?= base_url('patients/edit/' . $patient['id']) ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-pencil" title="Edit"></i>
                                        </a>
                                        <form action="<?= base_url('patients/delete/' . $patient['id']) ?>" method="post" class="d-inline"
                                              onsubmit="return confirm('Hapus pasien ini? Data yang dihapus tidak dapat dikembalikan.')">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash" title="Hapus"></i></button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= $pager->links('patients') ?>
    </div>
</div>
<?= $this->endSection() ?>
