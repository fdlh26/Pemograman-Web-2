<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php
$activityLabels = [
    'login'        => ['Login', 'success'],
    'login_failed' => ['Login Gagal', 'danger'],
    'logout'       => ['Logout', 'secondary'],
    'create'       => ['Tambah Data', 'primary'],
    'update'       => ['Ubah Data', 'info'],
    'delete'       => ['Hapus Data', 'danger'],
    'verify'       => ['Verifikasi Resep', 'info'],
    'dispense'     => ['Siapkan Obat', 'primary'],
    'complete'     => ['Resep Selesai', 'success'],
    'cancel'       => ['Batalkan', 'warning'],
    'stock_in'     => ['Stok Masuk', 'success'],
    'stock_out'    => ['Stok Keluar', 'warning'],
    'adjustment'   => ['Penyesuaian Stok', 'secondary'],
    'pay'          => ['Pembayaran', 'success'],
    'print_labels' => ['Cetak Label', 'secondary'],
    'toggle_user'  => ['Toggle Pengguna', 'warning'],
];
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-clock-history page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Riwayat Aktivitas</h1>
        <p class="text-muted mb-0">Riwayat aktivitas pengguna & perubahan data — <?= date('d/m/Y', strtotime($filters['from'])) ?> s/d <?= date('d/m/Y', strtotime($filters['to'])) ?></p>
    </div>
    <button type="button" class="btn btn-outline-primary" onclick="window.print()">
        <i class="bi bi-printer me-1"></i> Cetak
    </button>
</div>

<div class="card border-0 shadow-sm mb-3 no-print">
    <div class="card-body">
        <form action="<?= base_url('audit') ?>" method="get" class="row g-2 align-items-end">
            <div class="col-md-2">
                <label class="form-label small mb-1">Dari</label>
                <input type="date" class="form-control form-control-sm" name="from" value="<?= esc($filters['from']) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small mb-1">Sampai</label>
                <input type="date" class="form-control form-control-sm" name="to" value="<?= esc($filters['to']) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small mb-1">Pengguna</label>
                <select class="form-select form-select-sm" name="user_id">
                    <option value="0">-- Semua --</option>
                    <?php foreach ($users as $u): ?>
                        <option value="<?= $u['id'] ?>" <?= $filters['user_id'] === (int) $u['id'] ? 'selected' : '' ?>>
                            <?= esc($u['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small mb-1">Aksi</label>
                <select class="form-select form-select-sm" name="action">
                    <option value="">-- Semua --</option>
                    <?php foreach ($actions as $a): ?>
                        <option value="<?= esc($a) ?>" <?= $filters['action'] === $a ? 'selected' : '' ?>><?= esc($a) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small mb-1">Cari Deskripsi</label>
                <input type="text" class="form-control form-control-sm" name="q" placeholder="Cari nama pengguna, aksi, atau data..." value="<?= esc($filters['q']) ?>">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-funnel me-1"></i> Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="130">Waktu</th>
                        <th>Pengguna</th>
                        <th>Aksi</th>
                        <th>Data</th>
                        <th>Deskripsi</th>
                        <th>IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">Tidak ada aktivitas pada periode ini.</td></tr>
                    <?php else: ?>
                        <?php foreach ($logs as $log): ?>
                            <?php [$label, $color] = $activityLabels[$log['action']] ?? [ucfirst(str_replace('_', ' ', $log['action'])), 'dark']; ?>
                            <tr>
                                <td class="small text-nowrap"><?= date('d/m/Y', strtotime($log['created_at'])) ?><br><span class="text-muted"><?= date('H:i:s', strtotime($log['created_at'])) ?></span></td>
                                <td class="small">
                                    <?= esc($log['user_name'] ?? '(sistem)') ?>
                                    <div class="text-muted"><?= esc($log['user_email'] ?? '') ?></div>
                                </td>
                                <td><span class="badge bg-<?= $color ?>"><?= $label ?></span></td>
                                <td class="small">
                                    <?php if (! empty($log['table_name'])): ?>
                                        <code><?= esc($log['table_name']) ?></code><?= $log['record_id'] ? ' #' . (int) $log['record_id'] : '' ?>
                                    <?php else: ?>-<?php endif; ?>
                                </td>
                                <td class="small"><?= esc($log['description'] ?? '-') ?></td>
                                <td class="small text-muted"><?= esc($log['ip_address'] ?? '-') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?= $pager->links('audit') ?>
    </div>
</div>

<style media="print">
    .no-print, .sidebar, .topbar { display: none !important; }
    .main-content { margin: 0 !important; padding: 0 !important; }
</style>
<?= $this->endSection() ?>
