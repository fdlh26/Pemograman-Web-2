<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-calendar-x page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Monitoring Kedaluwarsa</h1>
        <p class="text-muted mb-0">Batch obat mendekati atau melewati tanggal kedaluwarsa</p>
    </div>
    <a href="<?= base_url('stock') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali
    </a>
</div>

<div class="row g-2 mb-4">
    <div class="col-auto">
        <a href="<?= base_url('expiry') ?>" class="btn btn-outline-secondary <?= empty($status) ? 'active' : '' ?>">Semua (≤90 hari)</a>
    </div>
    <div class="col-auto">
        <a href="<?= base_url('expiry?status=expired') ?>" class="btn btn-outline-danger <?= ($status ?? '') === 'expired' ? 'active' : '' ?>">Kedaluwarsa</a>
    </div>
    <div class="col-auto">
        <a href="<?= base_url('expiry?status=critical') ?>" class="btn btn-outline-warning <?= ($status ?? '') === 'critical' ? 'active' : '' ?>">≤30 Hari</a>
    </div>
    <div class="col-auto">
        <a href="<?= base_url('expiry?status=warning') ?>" class="btn btn-outline-info <?= ($status ?? '') === 'warning' ? 'active' : '' ?>">31–90 Hari</a>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="50">No</th>
                        <th>Obat</th>
                        <th>No. Batch</th>
                        <th>Kedaluwarsa</th>
                        <th class="text-center">Sisa Hari</th>
                        <th class="text-end">Sisa Stok</th>
                        <th class="text-center">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($batches)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">Tidak ada batch pada kategori ini.</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = ($pager->getCurrentPage('batches') - 1) * $pager->getPerPage('batches') + 1; ?>
                        <?php foreach ($batches as $batch): ?>
                            <?php $statusBadge = $batchModel->getExpiryStatus($batch); ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td class="fw-semibold">
                                    <?= esc($batch['drug_name'] ?? '-') ?>
                                    <div class="small text-muted"><?= esc($batch['drug_code'] ?? '') ?></div>
                                </td>
                                <td><code><?= esc($batch['batch_number'] ?? '-') ?></code></td>
                                <td><?= $batch['expiry_date'] ? date('d/m/Y', strtotime($batch['expiry_date'])) : '-' ?></td>
                                <td class="text-center">
                                    <?php if ($batch['expiry_date']): ?>
                                        <?php $days = (int) floor((strtotime($batch['expiry_date']) - strtotime(date('Y-m-d'))) / 86400); ?>
                                        <?= $days >= 0 ? $days : abs($days) . ' hari lewat' ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td class="text-end"><?= number_format((float) $batch['remaining_qty'], 2) ?> <?= esc($batch['unit'] ?? '') ?></td>
                                <td class="text-center">
                                    <?php if ($statusBadge === 'expired'): ?>
                                        <span class="badge bg-danger">Kedaluwarsa</span>
                                    <?php elseif ($statusBadge === 'critical'): ?>
                                        <span class="badge bg-warning text-dark">≤30 Hari</span>
                                    <?php elseif ($statusBadge === 'warning'): ?>
                                        <span class="badge bg-info text-dark">31–90 Hari</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Aman</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= $pager->links('batches') ?>
    </div>
</div>
<?= $this->endSection() ?>
