<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php
$labelColor = match ($rx['status']) {
    'pending'   => ['Menunggu Verifikasi', 'secondary'],
    'verified'  => ['Terverifikasi', 'info'],
    'prepared'  => ['Obat Disiapkan', 'primary'],
    'completed' => ['Selesai', 'success'],
    'cancelled' => ['Dibatalkan', 'danger'],
    default     => ['-', 'secondary'],
};
[$label, $color] = $labelColor;
$userRole = session()->get('userRole');
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-clipboard2-pulse page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Detail Resep</h1>
        <p class="text-muted mb-0"><code><?= esc($rx['prescription_number']) ?></code> — <span class="badge bg-<?= $color ?>"><?= $label ?></span></p>
    </div>
    <div class="d-flex gap-2">
        <?php if ($rx['status'] === 'pending' && in_array($userRole, ['admin', 'apoteker'], true)): ?>
            <form action="<?= base_url('prescriptions/verify/' . $rx['id']) ?>" method="post" class="d-inline"
                  onsubmit="return confirm('Verifikasi resep ini? Stok obat akan diperiksa terlebih dahulu.')">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-info text-white">
                    <i class="bi bi-check2-circle me-1"></i> Verifikasi
                </button>
            </form>
        <?php endif; ?>
        <?php if ($rx['status'] === 'verified' && in_array($userRole, ['admin', 'apoteker', 'ttk'], true)): ?>
            <form action="<?= base_url('prescriptions/dispense/' . $rx['id']) ?>" method="post" class="d-inline"
                  onsubmit="return confirm('Siapkan obat untuk resep ini? Stok akan otomatis berkurang.')">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-bag-check me-1"></i> Siapkan Obat
                </button>
            </form>
        <?php endif; ?>
        <?php if ($rx['status'] === 'prepared' && in_array($userRole, ['admin', 'apoteker', 'ttk'], true)): ?>
            <form action="<?= base_url('prescriptions/complete/' . $rx['id']) ?>" method="post" class="d-inline"
                  onsubmit="return confirm('Tandai resep selesai? Pastikan obat sudah diserahkan ke pasien.')">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-success">
                    <i class="bi bi-check-circle me-1"></i> Selesai
                </button>
            </form>
        <?php endif; ?>
        <?php if (in_array($rx['status'], ['pending', 'verified'], true) && in_array($userRole, ['admin', 'apoteker', 'dokter'], true)): ?>
            <form action="<?= base_url('prescriptions/cancel/' . $rx['id']) ?>" method="post" class="d-inline"
                  onsubmit="return confirm('Batalkan resep ini? Resep tidak dapat diproses kembali.')">
                <?= csrf_field() ?>
                <input type="hidden" name="cancel_reason" value="">
                <button type="submit" class="btn btn-outline-danger">
                    <i class="bi bi-x-circle me-1"></i> Batalkan
                </button>
            </form>
        <?php endif; ?>
        <?php if (in_array($rx['status'], ['verified', 'prepared', 'completed'], true) && in_array($userRole, ['admin', 'apoteker', 'ttk'], true)): ?>
            <a href="<?= base_url('prescriptions/labels/' . $rx['id']) ?>" target="_blank" class="btn btn-outline-warning">
                <i class="bi bi-tags me-1"></i> Cetak Label
            </a>
        <?php endif; ?>
        <a href="<?= base_url('prescriptions') ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
</div>

<?php if ($rx['status'] === 'cancelled' && ! empty($rx['cancel_reason'])): ?>
    <div class="alert alert-danger">
        <strong>Alasan pembatalan:</strong> <?= esc($rx['cancel_reason']) ?>
    </div>
<?php endif; ?>

<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white fw-bold">Pasien</div>
            <div class="card-body">
                <div class="fw-bold"><?= esc($patient['name'] ?? '-') ?></div>
                <div class="text-muted small">RM: <?= esc($patient['rm_number'] ?? '-') ?></div>
                <div class="text-muted small">
                    <?= $patient['gender'] === 'L' ? 'Laki-laki' : 'Perempuan' ?>
                    <?php if (! empty($patient['birth_date'])): ?>
                        • Lahir: <?= date('d/m/Y', strtotime($patient['birth_date'])) ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white fw-bold">Dokter & Diagnosis</div>
            <div class="card-body">
                <div class="fw-bold">dr. <?= esc($doctor['name'] ?? '-') ?></div>
                <div class="text-muted small"><?= esc($rx['diagnosis'] ?? 'Tidak ada diagnosis') ?></div>
                <?php if (! empty($rx['doctor_note'])): ?>
                    <div class="small mt-1"><em><?= esc($rx['doctor_note']) ?></em></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white fw-bold">Riwayat Proses</div>
            <div class="card-body small">
                <div>Dibuat: <strong><?= date('d/m/Y H:i', strtotime($rx['created_at'])) ?></strong></div>
                <?php if ($rx['verified_at']): ?>
                    <div>Diverifikasi: <strong><?= esc($verifier['name'] ?? '-') ?></strong> (<?= date('d/m/Y H:i', strtotime($rx['verified_at'])) ?>)</div>
                <?php endif; ?>
                <?php if ($rx['prepared_at']): ?>
                    <div>Disiapkan: <strong><?= esc($preparer['name'] ?? '-') ?></strong> (<?= date('d/m/Y H:i', strtotime($rx['prepared_at'])) ?>)</div>
                <?php endif; ?>
                <?php if ($rx['completed_at']): ?>
                    <div>Selesai: <strong><?= date('d/m/Y H:i', strtotime($rx['completed_at'])) ?></strong></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-bold">Item Resep</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="50">No</th>
                        <th>Kode</th>
                        <th>Obat</th>
                        <th class="text-end">Jumlah</th>
                        <th>Aturan Pakai</th>
                        <th class="text-center">Stok Saat Ini</th>
                        <th>Catatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($items)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-3">Tidak ada item.</td></tr>
                    <?php else: ?>
                        <?php foreach ($items as $i => $item): ?>
                            <?php $insufficient = (float) $item['current_stock'] < (float) $item['quantity']; ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><code><?= esc($item['drug_code'] ?? '-') ?></code></td>
                                <td class="fw-semibold"><?= esc($item['drug_name'] ?? '-') ?></td>
                                <td class="text-end"><?= number_format((float) $item['quantity'], 2) ?> <?= esc($item['unit'] ?? '') ?></td>
                                <td><?= esc($item['dosage_instruction'] ?? '-') ?></td>
                                <td class="text-center">
                                    <?= number_format((float) $item['current_stock'], 2) ?>
                                    <?php if ($insufficient && in_array($rx['status'], ['pending', 'verified'], true)): ?>
                                        <span class="badge bg-danger ms-1">Kurang</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted"><?= esc($item['note'] ?? '-') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
