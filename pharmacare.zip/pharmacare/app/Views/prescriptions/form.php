<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-file-earmark-medical page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Buat Resep</h1>
        <p class="text-muted mb-0">Catat resep dari dokter</p>
    </div>
    <a href="<?= base_url('prescriptions') ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali
    </a>
</div>

<form action="<?= base_url('prescriptions/store') ?>" method="post" id="rxForm">
    <?= csrf_field() ?>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body p-4">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">No. Resep (otomatis)</label>
                    <input type="text" class="form-control" value="<?= esc($number) ?>" disabled>
                </div>
                <div class="col-md-4">
                    <label for="patient_id" class="form-label">Pasien <span class="text-danger">*</span></label>
                    <select class="form-select" id="patient_id" name="patient_id" required>
                        <option value="">-- Pilih Pasien --</option>
                        <?php foreach ($patients as $patient): ?>
                            <option value="<?= $patient['id'] ?>" <?= (int) old('patient_id') === (int) $patient['id'] ? 'selected' : '' ?>>
                                <?= esc($patient['name']) ?> (<?= esc($patient['rm_number']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="doctor_id" class="form-label">Dokter <span class="text-danger">*</span></label>
                    <select class="form-select" id="doctor_id" name="doctor_id" required>
                        <option value="">-- Pilih Dokter --</option>
                        <?php foreach ($doctors as $doctor): ?>
                            <option value="<?= $doctor['id'] ?>" <?= (int) old('doctor_id', session()->get('userId')) === (int) $doctor['id'] ? 'selected' : '' ?>>
                                dr. <?= esc($doctor['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-12">
                    <label for="diagnosis" class="form-label">Diagnosis / Keluhan</label>
                    <input type="text" class="form-control" id="diagnosis" name="diagnosis" maxlength="255"
                           value="<?= esc(old('diagnosis', '')) ?>" placeholder="Contoh: Demam, nyeri tubuh">
                </div>
                <div class="col-md-12">
                    <label for="doctor_note" class="form-label">Catatan Dokter</label>
                    <textarea class="form-control" id="doctor_note" name="doctor_note" rows="2"
                              placeholder="Catatan tambahan untuk apoteker (opsional)"><?= esc(old('doctor_note', '')) ?></textarea>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <span class="fw-bold">Item Resep</span>
            <button type="button" class="btn btn-sm btn-outline-primary" id="addItem">
                <i class="bi bi-plus-lg"></i> Tambah Obat
            </button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table align-middle" id="itemsTable">
                    <thead class="table-light">
                        <tr>
                            <th width="40">No</th>
                            <th style="min-width: 200px;">Obat <span class="text-danger">*</span></th>
                            <th width="100">Jumlah <span class="text-danger">*</span></th>
                            <th style="min-width: 180px;">Aturan Pakai</th>
                            <th style="min-width: 150px;">Catatan</th>
                            <th width="50"></th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary fw-semibold">
        <i class="bi bi-save me-1"></i> Simpan Resep
    </button>
</form>

<template id="rowTemplate">
    <tr>
        <td class="row-no"></td>
        <td>
            <select name="item_drug_id[]" class="form-select form-select-sm" required>
                <option value="">-- Pilih --</option>
                <?php foreach ($drugs as $drug): ?>
                    <option value="<?= $drug['id'] ?>">
                        <?= esc($drug['name']) ?> (<?= esc($drug['code']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </td>
        <td><input type="number" name="item_qty[]" class="form-control form-control-sm" min="0.01" step="0.01" required></td>
        <td><input type="text" name="item_dosage[]" class="form-control form-control-sm" maxlength="150" placeholder="3x1 sehari sesudah makan"></td>
        <td><input type="text" name="item_note[]" class="form-control form-control-sm" maxlength="255" placeholder="Opsional"></td>
        <td><button type="button" class="btn btn-sm btn-outline-danger remove-row"><i class="bi bi-x"></i></button></td>
    </tr>
</template>

<script>
const tbody = document.querySelector('#itemsTable tbody');
const template = document.getElementById('rowTemplate');

function renumber() {
    tbody.querySelectorAll('tr').forEach((tr, i) => {
        tr.querySelector('.row-no').textContent = i + 1;
    });
}

function addRow() {
    tbody.appendChild(template.content.cloneNode(true));
    renumber();
}

document.getElementById('addItem').addEventListener('click', addRow);

tbody.addEventListener('click', (e) => {
    const btn = e.target.closest('.remove-row');
    if (btn) {
        btn.closest('tr').remove();
        renumber();
    }
});

document.getElementById('rxForm').addEventListener('submit', (e) => {
    if (tbody.querySelectorAll('tr').length === 0) {
        e.preventDefault();
        alert('Minimal harus ada satu item resep.');
    }
});

addRow();
</script>
<?= $this->endSection() ?>
