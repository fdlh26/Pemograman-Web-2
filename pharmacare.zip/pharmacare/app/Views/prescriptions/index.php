<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-head">
        <i class="bi bi-file-earmark-medical page-icon" aria-hidden="true"></i>
        <h1 class="h3 fw-bold mb-1">Pelayanan Resep</h1>
        <p class="text-muted mb-0">Alur resep: dokter → verifikasi → penyiapan → selesai</p>
    </div>
    <?php if (in_array(session()->get('userRole'), ['admin', 'dokter'], true)): ?>
        <a href="<?= base_url('prescriptions/create') ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Buat Resep
        </a>
    <?php endif; ?>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= base_url('prescriptions') ?>" method="get" class="row g-2 mb-3">
            <div class="col-md-3">
                <select class="form-select" name="status">
                    <option value="">Semua Status</option>
                    <option value="pending" <?= ($status ?? '') === 'pending' ? 'selected' : '' ?>>Menunggu Verifikasi</option>
                    <option value="verified" <?= ($status ?? '') === 'verified' ? 'selected' : '' ?>>Terverifikasi</option>
                    <option value="prepared" <?= ($status ?? '') === 'prepared' ? 'selected' : '' ?>>Obat Disiapkan</option>
                    <option value="completed" <?= ($status ?? '') === 'completed' ? 'selected' : '' ?>>Selesai</option>
                    <option value="cancelled" <?= ($status ?? '') === 'cancelled' ? 'selected' : '' ?>>Dibatalkan</option>
                </select>
            </div>
            <div class="col-md-4">
                <input type="text" class="form-control" name="q" placeholder="Cari no. resep / nama pasien / no. RM..." value="<?= esc($search ?? '') ?>">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-funnel"></i> Filter</button>
                <?php if (! empty($search) || ! empty($status)): ?>
                    <a href="<?= base_url('prescriptions') ?>" class="btn btn-outline-secondary">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th width="50">No</th>
                        <th>No. Resep</th>
                        <th>Tanggal</th>
                        <th>Pasien</th>
                        <th>Dokter</th>
                        <th class="text-center">Status</th>
                        <th width="90">Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($prescriptions)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">Belum ada data resep. Klik "Buat Resep" untuk mendaftarkan resep baru.</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = ($pager->getCurrentPage('prescriptions') - 1) * $pager->getPerPage('prescriptions') + 1; ?>
                        <?php foreach ($prescriptions as $rx): ?>
                            <?php $labelColor = match ($rx['status']) {
                                'pending' => ['Menunggu Verifikasi', 'secondary'],
                                'verified' => ['Terverifikasi', 'info'],
                                'prepared' => ['Obat Disiapkan', 'primary'],
                                'completed' => ['Selesai', 'success'],
                                'cancelled' => ['Dibatalkan', 'danger'],
                                default => ['-', 'secondary'],
                            }; [$label, $color] = $labelColor; ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><code><?= esc($rx['prescription_number']) ?></code></td>
                                <td><?= date('d/m/Y H:i', strtotime($rx['created_at'])) ?></td>
                                <td class="fw-semibold">
                                    <?= esc($rx['patient_name'] ?? '-') ?>
                                    <div class="small text-muted"><?= esc($rx['rm_number'] ?? '') ?></div>
                                </td>
                                <td><?= esc($rx['doctor_name'] ?? '-') ?></td>
                                <td class="text-center"><span class="badge bg-<?= $color ?>"><?= $label ?></span></td>
                                <td>
                                    <a href="<?= base_url('prescriptions/' . $rx['id']) ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye" title="Lihat detail"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= $pager->links('prescriptions') ?>
    </div>
</div>
<?= $this->endSection() ?>
