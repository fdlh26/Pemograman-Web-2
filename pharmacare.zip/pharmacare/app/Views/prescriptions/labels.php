<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body { background: #f1f3f6; font-family: 'Segoe UI', system-ui, sans-serif; }
        .toolbar {
            position: sticky;
            top: 0;
            z-index: 10;
            background: #fff;
            border-bottom: 1px solid #dee2e6;
            padding: 0.75rem 1.25rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .label-grid {
            display: grid;
            grid-template-columns: repeat(2, 76mm);
            gap: 4mm;
            justify-content: center;
            padding: 8mm 0;
        }
        .rx-label {
            width: 76mm;
            min-height: 50mm;
            background: #fff;
            border: 1px dashed #999;
            border-radius: 2mm;
            padding: 3mm;
            font-size: 10pt;
            line-height: 1.35;
            color: #000;
            display: flex;
            flex-direction: column;
        }
        .rx-label .brand {
            text-align: center;
            border-bottom: 1.5px solid #000;
            padding-bottom: 1.5mm;
            margin-bottom: 2mm;
        }
        .rx-label .brand .pharmacy { font-weight: 700; font-size: 12pt; letter-spacing: 1px; }
        .rx-label .brand .addr { font-size: 8pt; }
        .rx-label .pat .name { font-weight: 700; font-size: 11pt; }
        .rx-label .meta { font-size: 8.5pt; color: #333; }
        .rx-label .drug {
            flex: 1;
            margin: 2mm 0;
            padding: 2mm;
            background: #fafafa;
            border: 1px solid #ccc;
            border-radius: 1.5mm;
        }
        .rx-label .drug .dname { font-weight: 700; font-size: 12pt; }
        .rx-label .drug .ddos { font-size: 9.5pt; font-style: italic; }
        .rx-label .drug .dqty { font-size: 10pt; }
        .rx-label .usage { font-size: 9.5pt; border-top: 1px dotted #666; padding-top: 1.5mm; }
        .rx-label .usage .sig { font-weight: 700; }
        .rx-label .foot { font-size: 8pt; color: #444; display: flex; justify-content: space-between; margin-top: auto; padding-top: 1.5mm; }
        .rx-label .qr-note { font-size: 7.5pt; color: #777; text-align: center; }
        @media print {
            body { background: #fff; }
            .toolbar { display: none !important; }
            .label-grid { gap: 3mm; padding: 0; }
            .rx-label { border-color: #bbb; page-break-inside: avoid; }
            @page { size: A4; margin: 8mm; }
        }
    </style>
</head>
<body>
    <div class="toolbar">
        <div>
            <i class="bi bi-tags me-2"></i>
            <strong>Label Obat</strong>
            <span class="text-muted ms-2"><?= esc($rx['prescription_number']) ?> — <?= count($items) ?> stiker</span>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= base_url('prescriptions/' . $rx['id']) ?>" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>
            <button type="button" class="btn btn-primary btn-sm" onclick="window.print()">
                <i class="bi bi-printer"></i> Cetak
            </button>
        </div>
    </div>

    <div class="label-grid">
        <?php foreach ($items as $item): ?>
            <div class="rx-label">
                <div class="brand">
                    <div class="pharmacy">PHARMACARE</div>
                    <div class="addr">Apotek / Instalasi Farmasi</div>
                </div>

                <div class="pat">
                    <div class="name"><?= esc($patient['name'] ?? '-') ?></div>
                    <div class="meta">
                        RM: <strong><?= esc($patient['rm_number'] ?? '-') ?></strong>
                        <?php if (! empty($patient['date_of_birth'])): ?> &middot; Lahir <?= date('d/m/Y', strtotime($patient['date_of_birth'])) ?><?php endif; ?>
                    </div>
                </div>

                <div class="meta mt-1">
                    Resep: <strong><?= esc($rx['prescription_number']) ?></strong> &middot; <?= date('d/m/Y', strtotime($rx['created_at'])) ?><br>
                    Dokter: <?= esc($doctor['name'] ?? '-') ?>
                    <?php if (! empty($queue)): ?>
                        <br>Antrean: <strong><?= esc($queue['queue_number']) ?></strong>
                    <?php endif; ?>
                </div>

                <div class="drug">
                    <div class="dname"><?= esc($item['drug_name']) ?></div>
                    <?php if (! empty($item['dosage'])): ?>
                        <div class="ddos"><?= esc($item['dosage']) ?></div>
                    <?php endif; ?>
                    <div class="dqty">Jumlah: <strong><?= rtrim(rtrim(number_format((float) $item['quantity'], 2, '.', ''), '0'), '.') ?> <?= esc($item['unit']) ?></strong></div>
                </div>

                <div class="usage">
                    <span class="sig">Aturan pakai:</span>
                    <?php if (! empty($item['dosage_instruction'])): ?>
                        <?= esc($item['dosage_instruction']) ?>
                    <?php else: ?>
                        Sesuai anjuran dokter
                    <?php endif; ?>
                    <?php if (! empty($item['note'])): ?>
                        <br><span class="text-muted"><?= esc($item['note']) ?></span>
                    <?php endif; ?>
                </div>

                <div class="foot">
                    <span>Apoteker: <?= esc($verifier['name'] ?? '_______________') ?></span>
                    <span><?= esc(ucfirst(str_replace('_', ' ', $printer))) ?></span>
                </div>
                <div class="qr-note">Simpan di tempat kering, jauh dari jangkauan anak.</div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
