<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php
$role   = session()->get('userRole');
$fmt    = static fn ($v): string => number_format((float) $v, 0, ',', '.');
$num    = static fn ($v): string => rtrim(rtrim(number_format((float) $v, 2, '.', ''), '0'), '.');
$hour   = (int) date('G');
$greet  = $hour < 11 ? 'Selamat pagi' : ($hour < 15 ? 'Selamat siang' : ($hour < 18 ? 'Selamat sore' : 'Selamat malam'));
$statusMap = [
    'pending'   => ['Menunggu', 'secondary'],
    'paid'      => ['Lunas', 'success'],
    'cancelled' => ['Batal', 'danger'],
];
?>
<style>
    .dash-kpi {
        border: 1px solid #eef2f7;
        border-radius: 1rem;
        background: #fff;
        position: relative;
        overflow: hidden;
        transition: transform .15s ease, box-shadow .15s ease;
    }
    .dash-kpi:hover { transform: translateY(-2px); box-shadow: 0 14px 30px -12px rgba(2, 44, 34, 0.18); }
    .dash-kpi::after {
        content: "";
        position: absolute;
        top: 0; right: 0;
        width: 92px; height: 92px;
        border-radius: 0 0 0 92px;
        opacity: .55;
    }
    .dash-kpi.k-primary::after { background: radial-gradient(circle at top right, rgba(16,185,129,.35), transparent 70%); }
    .dash-kpi.k-info::after    { background: radial-gradient(circle at top right, rgba(34,211,238,.35), transparent 70%); }
    .dash-kpi.k-success::after { background: radial-gradient(circle at top right, rgba(34,197,94,.35), transparent 70%); }
    .dash-kpi.k-danger::after  { background: radial-gradient(circle at top right, rgba(239,68,68,.32), transparent 70%); }
    .dash-kpi.k-warning::after { background: radial-gradient(circle at top right, rgba(245,158,11,.32), transparent 70%); }
    .dash-kpi.k-secondary::after { background: radial-gradient(circle at top right, rgba(100,116,139,.28), transparent 70%); }
    .dash-kpi .k-icon {
        width: 46px; height: 46px;
        border-radius: .8rem;
        display: flex; align-items: center; justify-content: center;
        font-size: 1.25rem;
        flex: 0 0 auto;
    }
    .dash-kpi .k-label {
        font-size: 0.78rem;
        color: #475569;
        font-weight: 600;
        letter-spacing: 0.01em;
    }
    .dash-kpi .k-value {
        font-size: 1.8rem;
        font-weight: 800;
        letter-spacing: -0.03em;
        color: #022c22;
        line-height: 1.15;
        font-variant-numeric: tabular-nums;
    }
    .dash-kpi .k-sub { font-size: 0.78rem; color: #64748b; font-weight: 500; }
    .panel { border: 1px solid #eef2f7; border-radius: 1rem; background: #fff; }
    .panel-head {
        display: flex; align-items: center; justify-content: space-between;
        padding: 1rem 1.25rem .75rem;
    }
    .panel-head h2 { font-size: 1rem; font-weight: 700; margin: 0; color: #022c22; }
    .panel-body { padding: 0 1.25rem 1.1rem; }
    .panel table { margin: 0; }
    .panel thead th {
        font-size: 0.72rem;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        color: #475569;
        font-weight: 700;
        border-bottom: 2px solid #e2e8f0;
        padding-top: .35rem;
    }
    .panel tbody td {
        padding: .6rem .4rem;
        font-size: .88rem;
        color: #1e293b;
        border-color: #f1f5f9;
        font-variant-numeric: tabular-nums;
    }
    .quick-btn {
        border: 1px solid #e2e8f0; background: #fff; color: #334155;
        font-size: .82rem; font-weight: 600;
        border-radius: .65rem; padding: .45rem .85rem;
        display: inline-flex; align-items: center; gap: .4rem;
        text-decoration: none;
        transition: all .15s ease;
    }
    .quick-btn:hover { border-color: #a7f3d0; background: #ecfdf5; color: #047857; }
    .empty-state { text-align: center; color: #64748b; padding: 1.6rem 1rem; font-size: 0.88rem; font-weight: 500; }
    .empty-state i { display: block; font-size: 1.6rem; margin-bottom: .4rem; opacity: .6; }
</style>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <div class="page-head">
        <i class="bi bi-speedometer2 page-icon" aria-hidden="true"></i>
        <h1 class="h4 fw-bold mb-0" style="letter-spacing:-0.02em"><?= $greet ?>, <?= esc($userName ?? '') ?></h1>
        <p class="mb-0" style="font-size:.92rem; color:#475569; font-weight:500">Ringkasan operasional hari ini &middot; <?= date('d/m/Y', strtotime(date('Y-m-d'))) ?></p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <?php if (in_array($role, ['admin', 'apoteker', 'ttk', 'kasir'], true)): ?>
            <a href="<?= base_url('queue') ?>" class="quick-btn"><i class="bi bi-people-clock"></i> Antrean</a>
        <?php endif; ?>
        <?php if (in_array($role, ['admin', 'dokter', 'apoteker', 'ttk'], true)): ?>
            <a href="<?= base_url('prescriptions') ?>" class="quick-btn"><i class="bi bi-file-earmark-medical"></i> Resep</a>
        <?php endif; ?>
        <?php if (in_array($role, ['admin', 'kasir'], true)): ?>
            <a href="<?= base_url('transactions/create') ?>" class="quick-btn"><i class="bi bi-plus-lg"></i> Transaksi</a>
        <?php endif; ?>
        <?php if (in_array($role, ['admin', 'kepala_farmasi', 'manajemen'], true)): ?>
            <a href="<?= base_url('reports') ?>" class="quick-btn"><i class="bi bi-graph-up"></i> Laporan</a>
        <?php endif; ?>
    </div>
</div>

<!-- KPI -->
<div class="row g-3 mb-3">
    <div class="col-sm-6 col-xl-3">
        <div class="dash-kpi k-primary p-3 h-100">
            <div class="d-flex align-items-center gap-3">
                <div class="k-icon bg-primary bg-opacity-10 text-primary"><i class="bi bi-capsule"></i></div>
                <div>
                    <div class="k-label">Obat Aktif</div>
                    <div class="k-value"><?= $fmt($totalDrugs) ?></div>
                    <div class="k-sub">jenis obat terdaftar</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="dash-kpi k-success p-3 h-100">
            <div class="d-flex align-items-center gap-3">
                <div class="k-icon bg-success bg-opacity-10 text-success"><i class="bi bi-receipt"></i></div>
                <div>
                    <div class="k-label">Penjualan Hari Ini</div>
                    <div class="k-value"><?= $fmt($trxCount) ?></div>
                    <div class="k-sub fw-semibold text-success">Rp <?= $fmt($trxRevenue) ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="dash-kpi k-info p-3 h-100">
            <div class="d-flex align-items-center gap-3">
                <div class="k-icon bg-info bg-opacity-10 text-info"><i class="bi bi-hourglass-split"></i></div>
                <div>
                    <div class="k-label">Antrean Aktif</div>
                    <div class="k-value"><?= (int) $queueActive ?></div>
                    <div class="k-sub"><?= (int) $queueDoneToday ?> selesai hari ini</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="dash-kpi k-danger p-3 h-100">
            <div class="d-flex align-items-center gap-3">
                <div class="k-icon bg-danger bg-opacity-10 text-danger"><i class="bi bi-exclamation-octagon"></i></div>
                <div>
                    <div class="k-label">Stok Menipis</div>
                    <div class="k-value"><?= $fmt($lowStockCount) ?></div>
                    <div class="k-sub">di bawah stok minimum</div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-sm-6 col-xl-3">
        <div class="dash-kpi k-info p-3 h-100">
            <div class="d-flex align-items-center gap-3">
                <div class="k-icon bg-secondary bg-opacity-10 text-secondary"><i class="bi bi-file-earmark-medical"></i></div>
                <div>
                    <div class="k-label">Resep Masuk</div>
                    <div class="k-value"><?= $fmt($rxToday) ?></div>
                    <div class="k-sub">hari ini</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="dash-kpi k-warning p-3 h-100">
            <div class="d-flex align-items-center gap-3">
                <div class="k-icon bg-warning bg-opacity-10 text-warning"><i class="bi bi-calendar-x"></i></div>
                <div>
                    <div class="k-label">Kedaluwarsa</div>
                    <div class="k-value"><?= $fmt($expiringCount) ?></div>
                    <div class="k-sub">≤30 hari &middot; <?= $fmt($expiredCount) ?> kadaluarsa</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-6">
        <div class="panel h-100">
            <div class="panel-head">
                <h2><i class="bi bi-receipt-cutoff text-success me-1"></i>Transaksi Terbaru</h2>
                <?php if (in_array($role, ['admin', 'kasir', 'kepala_farmasi', 'manajemen'], true)): ?>
                    <a href="<?= base_url('transactions') ?>" class="small text-decoration-none fw-semibold" style="color:#047857">Lihat semua</a>
                <?php endif; ?>
            </div>
            <div class="panel-body">
                <?php if (empty($recentTransactions)): ?>
                    <div class="empty-state"><i class="bi bi-receipt"></i>Belum ada transaksi hari ini.</div>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr><th>No.</th><th>Tipe</th><th>Pasien</th><th>Status</th><th class="text-end">Total</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentTransactions as $trx): ?>
                                <?php [$sl, $sc] = $statusMap[$trx['status']] ?? ['-', 'secondary']; ?>
                                <tr>
                                    <td><code class="small"><?= esc($trx['transaction_number']) ?></code></td>
                                    <td><?= $trx['type'] === 'otc' ? 'OTC' : 'Resep' ?></td>
                                    <td><?= esc($trx['patient_name'] ?? '-') ?></td>
                                    <td><span class="badge bg-<?= $sc ?>"><?= $sl ?></span></td>
                                    <td class="text-end fw-semibold">Rp <?= $fmt($trx['grand_total']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-6">
        <div class="panel h-100">
            <div class="panel-head">
                <h2><i class="bi bi-exclamation-triangle text-warning me-1"></i>Stok Hampir Habis</h2>
                <a href="<?= base_url('drugs') ?>" class="small text-decoration-none fw-semibold" style="color:#047857">Semua obat</a>
            </div>
            <div class="panel-body">
                <?php if (empty($lowStockList)): ?>
                    <div class="empty-state"><i class="bi bi-check2-circle"></i>Semua stok di atas minimum.</div>
                <?php else: ?>
                    <table class="table">
                        <thead><tr><th>Obat</th><th class="text-end">Stok / Minimum</th></tr></thead>
                        <tbody>
                            <?php foreach ($lowStockList as $d): ?>
                                <tr>
                                    <td><?= esc($d['name']) ?></td>
                                    <td class="text-end">
                                        <span class="fw-bold text-danger"><?= $num($d['current_stock']) ?></span>
                                        <span class="text-muted">/ <?= $num($d['min_stock']) ?> <?= esc($d['unit']) ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="panel h-100">
            <div class="panel-head">
                <h2><i class="bi bi-calendar-event text-danger me-1"></i>Mendekati Kedaluwarsa</h2>
                <a href="<?= base_url('expiry') ?>" class="small text-decoration-none fw-semibold" style="color:#047857">Semua batch</a>
            </div>
            <div class="panel-body">
                <?php if (empty($expiringList)): ?>
                    <div class="empty-state"><i class="bi bi-check2-circle"></i>Tidak ada batch mendekati kedaluwarsa.</div>
                <?php else: ?>
                    <table class="table">
                        <thead><tr><th>Obat</th><th>Batch</th><th>Kedaluwarsa</th><th class="text-end">Sisa</th></tr></thead>
                        <tbody>
                            <?php foreach ($expiringList as $b): ?>
                                <tr>
                                    <td><?= esc($b['drug_name']) ?></td>
                                    <td><code class="small"><?= esc($b['batch_number'] ?? '-') ?></code></td>
                                    <td class="<?= $b['expiry_date'] < date('Y-m-d') ? 'text-danger fw-bold' : 'text-warning' ?>">
                                        <?= date('d/m/Y', strtotime($b['expiry_date'])) ?>
                                    </td>
                                    <td class="text-end"><?= $num($b['remaining_qty']) ?> <?= esc($b['unit']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
