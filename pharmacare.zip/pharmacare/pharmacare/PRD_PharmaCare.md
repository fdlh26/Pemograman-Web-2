# PRODUCT REQUIREMENTS DOCUMENT (PRD)
## PharmaCare – Aplikasi Manajemen Apotek/Farmasi

### 1. Informasi Produk

- **Nama Aplikasi:** PharmaCare
- **Jenis Aplikasi:** Sistem Informasi Manajemen Apotek/Farmasi
- **Basis:** Website
- **Database:** MySQL
- **Framework:** CodeIgniter 4
- **Keamanan:** Login berbasis hak akses, enkripsi data, dan audit trail.

### 2. Deskripsi Produk

PharmaCare adalah aplikasi berbasis website yang dirancang untuk membantu pengelolaan apotek dan instalasi farmasi pada fasilitas pelayanan kesehatan (fasyankes). Aplikasi ini mengintegrasikan pengelolaan data obat, persediaan, resep, pembelian, transaksi, antrean pengambilan obat, pencetakan stiker obat, dan laporan farmasi dalam satu sistem.

### 3. Latar Belakang dan Masalah

Pengelolaan apotek/farmasi masih menghadapi beberapa kendala, antara lain:

1. Pengelolaan stok obat yang belum optimal.
2. Pencatatan resep dan transaksi yang belum terintegrasi.
3. Kesulitan memantau tanggal kedaluwarsa obat.
4. Pengelolaan pembelian dan data supplier yang kurang efektif.
5. Proses antrean pengambilan obat yang belum terorganisasi dengan baik.
6. Pencatatan dan pembuatan laporan farmasi yang membutuhkan waktu lama.
7. Kesulitan memantau aktivitas pengguna dan perubahan data.

### 4. Tujuan Produk

1. Mengintegrasikan pengelolaan apotek/farmasi dalam satu sistem.
2. Meningkatkan ketepatan pencatatan stok dan transaksi obat.
3. Mempermudah pemantauan obat yang hampir habis dan mendekati kedaluwarsa.
4. Mempercepat pelayanan resep dan pengambilan obat.
5. Mempermudah pembuatan laporan farmasi.
6. Meningkatkan keamanan data dan pengawasan aktivitas pengguna.

### 5. Pengguna Sistem

| Pengguna | Hak Akses dan Tanggung Jawab |
|---|---|
| Admin | Mengelola konfigurasi, akun, dan hak akses sistem. |
| Apoteker | Memverifikasi resep, memeriksa obat, dan melakukan validasi pelayanan farmasi sesuai kewenangan. |
| Tenaga Teknis Kefarmasian (TTK) | Membantu penyiapan obat, pencatatan, dan pelayanan sesuai kewenangan. |
| Dokter | Membuat dan mengelola resep pasien. |
| Petugas Gudang Farmasi | Mengelola stok, penerimaan, pengeluaran, dan distribusi obat. |
| Petugas Pendaftaran | Mengelola data pasien dan administrasi pendaftaran. |
| Kasir | Mengelola pembayaran dan transaksi pasien. |
| Kepala Instalasi Farmasi | Memantau operasional, persediaan, dan laporan farmasi. |
| Manajemen Klinik | Memantau kinerja layanan dan laporan untuk pengambilan keputusan. |

### 6. Ruang Lingkup Sistem

PharmaCare mencakup pengelolaan:

- Data obat dan kategori obat.
- Stok masuk, stok keluar, dan persediaan obat.
- Tanggal kedaluwarsa dan nomor batch obat.
- Data supplier dan pembelian obat.
- Data pasien dan pelayanan resep.
- Penjualan serta transaksi pembayaran.
- Antrean dan pemanggilan pengambilan obat.
- Pencetakan stiker atau label obat.
- Laporan farmasi dan dashboard.
- Pengguna, hak akses, serta riwayat aktivitas.

### 7. Fitur Utama

#### 7.1 Login dan Hak Akses
Mengatur autentikasi pengguna dan membatasi akses berdasarkan peran masing-masing.

#### 7.2 Manajemen Data Obat
Mengelola nama obat, kode obat, kategori, satuan, harga, dosis, dan informasi obat lainnya.

#### 7.3 Manajemen Stok Obat
Mencatat stok masuk, stok keluar, penyesuaian stok, dan ketersediaan obat secara terstruktur.

#### 7.4 Monitoring Kedaluwarsa
Memantau tanggal kedaluwarsa dan nomor batch serta memberikan peringatan untuk obat yang mendekati atau telah melewati tanggal kedaluwarsa.

#### 7.5 Manajemen Supplier
Mencatat dan mengelola informasi pemasok obat.

#### 7.6 Pembelian Obat
Mencatat pesanan pembelian, penerimaan obat, jumlah, harga, batch, dan tanggal kedaluwarsa.

#### 7.7 Pelayanan Resep
Mencatat resep dari dokter, memeriksa ketersediaan obat, dan mendukung proses verifikasi serta penyiapan obat oleh petugas berwenang.

#### 7.8 Penjualan dan Transaksi
Mengelola rincian transaksi, total pembayaran, metode pembayaran, dan bukti transaksi.

#### 7.9 Antrean Pengambilan Obat Pintar
Menghasilkan nomor antrean pengambilan obat dan menampilkan status antrean, seperti menunggu, diproses, siap diambil, dipanggil, dan selesai.

#### 7.10 Pemanggilan Antrean
Menampilkan nomor antrean pada layar monitor dan mendukung pemanggilan melalui pengeras suara apabila perangkat tersedia.

#### 7.11 Print Stiker/Label Obat
Mencetak label obat yang memuat identitas pasien sesuai kebutuhan, nama obat, dosis, aturan pakai, dan informasi relevan lainnya berdasarkan resep yang telah diverifikasi.

#### 7.12 Laporan Farmasi
Menghasilkan laporan persediaan, pembelian, penjualan, penggunaan obat, obat kedaluwarsa, dan riwayat transaksi.

#### 7.13 Dashboard
Menampilkan ringkasan stok obat, transaksi, antrean pengambilan obat, obat hampir habis, dan obat mendekati kedaluwarsa.

#### 7.14 Manajemen Pengguna
Mengelola akun pengguna, status akun, peran, dan hak akses.

#### 7.15 Riwayat Aktivitas (Audit Trail)
Mencatat aktivitas penting, termasuk pengguna, waktu, jenis aktivitas, dan perubahan data yang relevan.

### 8. Kebutuhan Fungsional

Sistem harus mampu:

1. Melakukan login dan memvalidasi hak akses pengguna.
2. Menyimpan, mengubah, mencari, dan menampilkan data obat.
3. Mencatat pergerakan stok berdasarkan transaksi.
4. Memantau batch dan tanggal kedaluwarsa obat.
5. Mencatat data supplier dan pembelian.
6. Mencatat serta memproses resep sesuai alur pelayanan.
7. Mengelola transaksi dan pembayaran.
8. Menghasilkan serta memperbarui nomor antrean pengambilan obat.
9. Menampilkan dan memanggil nomor antrean.
10. Mencetak stiker obat dan bukti transaksi.
11. Menyediakan laporan berdasarkan periode dan kategori.
12. Menampilkan ringkasan operasional melalui dashboard.
13. Menyimpan riwayat aktivitas pengguna.
14. Membatasi tindakan pengguna sesuai kewenangannya.

### 9. Kebutuhan Nonfungsional

- **Keamanan:** Sistem menggunakan autentikasi, kontrol akses berbasis peran, dan pengamanan data.
- **Kinerja:** Halaman dan transaksi harus diproses secara efisien.
- **Kemudahan Penggunaan:** Antarmuka mudah dipahami dan responsif pada desktop maupun perangkat mobile.
- **Keandalan:** Data transaksi dan perubahan stok harus konsisten.
- **Pemeliharaan:** Struktur aplikasi menggunakan CodeIgniter 4 dengan kode yang terorganisir.
- **Pencadangan:** Data perlu dicadangkan secara berkala dan dapat dipulihkan ketika terjadi gangguan.
- **Auditabilitas:** Aktivitas penting tercatat dan hanya dapat diakses oleh pihak berwenang.

### 10. Teknologi yang Digunakan

| Komponen | Teknologi |
|---|---|
| Frontend | HTML, CSS, JavaScript, Bootstrap |
| Backend | PHP dengan CodeIgniter 4 |
| Database | MySQL |
| Arsitektur | Model-View-Controller (MVC) |
| Server | Web server yang mendukung PHP dan MySQL |
| Cetak | Printer biasa atau printer label sesuai kebutuhan |
| Antrean | Layar monitor dan perangkat audio jika tersedia |

### 11. Keamanan Sistem

1. Autentikasi login untuk seluruh pengguna.
2. Pembatasan akses berdasarkan peran dan kewenangan.
3. Penyimpanan kata sandi menggunakan hashing yang aman.
4. Enkripsi data sensitif saat diperlukan.
5. Penggunaan validasi input dan perlindungan terhadap serangan web.
6. Pencatatan audit trail untuk aktivitas penting.
7. Pengelolaan sesi pengguna secara aman.
8. Pencadangan dan pemulihan data secara berkala.

### 12. Alur Utama Sistem

1. Pengguna masuk ke sistem sesuai akun dan hak akses.
2. Dokter membuat resep pasien.
3. Apoteker atau petugas kefarmasian yang berwenang memverifikasi resep.
4. Petugas menyiapkan obat dan mencatat pengeluaran stok.
5. Sistem menghasilkan nomor antrean pengambilan obat.
6. Petugas mencetak stiker obat dan memanggil antrean ketika obat siap.
7. Pasien mengambil obat sesuai prosedur pelayanan.
8. Sistem memperbarui status antrean dan menyimpan riwayat transaksi.
9. Kepala instalasi farmasi dan manajemen melihat laporan sesuai hak akses.

### 13. Indikator Keberhasilan

- Data stok obat tercatat secara konsisten.
- Pemantauan obat hampir habis dan kedaluwarsa tersedia.
- Pencatatan resep dan transaksi terintegrasi.
- Nomor antrean dan status pengambilan obat dapat dipantau.
- Stiker obat dapat dicetak berdasarkan data resep.
- Laporan farmasi dapat dihasilkan berdasarkan periode.
- Hak akses dan riwayat aktivitas berfungsi sesuai ketentuan.

### 14. Batasan Sistem

- Sistem berfokus pada manajemen apotek/farmasi dan pelayanan obat.
- Integrasi dengan SIMRS, RME, BPJS, atau sistem eksternal lainnya dilakukan jika dibutuhkan dan tersedia akses integrasinya.
- Pemanggilan suara memerlukan dukungan perangkat dan konfigurasi.
- Pencetakan label memerlukan printer yang sesuai.
- Keputusan klinis dan validasi resep tetap menjadi tanggung jawab tenaga kesehatan yang berwenang.

### 15. Pengembangan Lanjutan

Pengembangan berikutnya dapat mencakup integrasi dengan Rekam Medis Elektronik (RME), sistem informasi klinik, pelaporan elektronik, notifikasi stok otomatis, serta analisis kebutuhan dan penggunaan obat.

### 16. Penutup

PharmaCare dirancang sebagai sistem informasi manajemen apotek/farmasi yang terintegrasi untuk meningkatkan efisiensi pengelolaan obat, ketepatan pencatatan stok, mutu pelayanan resep, keteraturan antrean pengambilan obat, dan ketersediaan laporan yang mendukung pengambilan keputusan di fasilitas pelayanan kesehatan.
